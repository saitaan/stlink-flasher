package com.tech.stlinkflasher

object WiringDiagramManager {

    enum class DiagramVersion {
        V16_3_3_STANDARD,
        V16_4_OPTICAL_SAFETY,
        V16_5_HARDWARE_TIMER
    }

    fun getWiringDiagramText(version: DiagramVersion): String {
        val isSafety = (version != DiagramVersion.V16_3_3_STANDARD)
        val sb = StringBuilder()

        sb.append("=======================================================================\n")
        sb.append("⚡ NIPON ZIPPER CNC - MASTER INDUSTRIAL WIRING MAP (${if (isSafety) "V16.4.0 / V16.5.0 SAFETY" else "V16.3.3 STANDARD"})\n")
        sb.append("=======================================================================\n\n")

        sb.append("🎨 MASTER WIRE COLOR CODING GUIDE:\n")
        sb.append("-----------------------------------------------------------------------\n")
        sb.append("🔴 Red (Heavy 18 AWG)   : +24V DC Main Bus (SMPS -> Driver VCC, L7805 IN)\n")
        sb.append("🔴 Red (Thin 22 AWG)    : +5V Regulated (L7805 OUT -> Driver PUL+/DIR+, LCD)\n")
        sb.append("🔴 Red (Thin 24 AWG)    : +3.3V Logic (STM32 Pin 18 -> Shifter LV, PC817)\n")
        sb.append("⚫ Black (Heavy 18 AWG) : Branch 1: Driver Power GND Return (24V SMPS -)\n")
        sb.append("⚫ Black (Thin 22 AWG)  : Branch 2: 5V Logic GND (L7805 GND, LCD GND)\n")
        sb.append("🟢 Green/Black (22 AWG) : Branch 3: Clean MCU GND (STM32 GND, PC817 Pin 3)\n")
        sb.append("🔵 Blue/Shield (22 AWG) : Branch 4: Sensor 24V GND (Prox Sensor Blue Wire)\n")
        sb.append("🟡 Yellow               : PA0 - Cam Proximity Trigger (from PC817 Pin 4)\n")
        sb.append("🟠 Orange               : PA1 - Step Pulse PUL- (STM32 -> Shifter CH3 -> Driver)\n")
        sb.append("🔵 Blue                 : PA2 - Direction DIR- (STM32 -> Shifter CH4 -> Driver)\n")
        if (isSafety) {
            sb.append("🟤 Brown                : PA3 - Tape Run-Out Guard (from PC817 Ch 1 Pin 4)\n")
            sb.append("🟣 Violet               : PB0 - Coil Jam Fiber Guard (from PC817 Ch 2 Pin 4)\n")
            sb.append("⚪ White                : PB1 - Main Motor Stop Relay (to 5V Opto-Relay IN)\n")
        }
        sb.append("🟢 Green / ⚪ White     : PB6 (SCL) / PB7 (SDA) - 400kHz Fast I2C to 16x2 LCD\n")
        sb.append("⚪ Gray                 : PB12 (UP), PB13 (DOWN), PB14 (MODE) Buttons to GND\n\n")

        sb.append("🗺️ REALISTIC COMPONENT-TO-COMPONENT CONNECTIONS:\n")
        sb.append("-----------------------------------------------------------------------\n")
        sb.append("1. [STM32F103C8T6 BLUE PILL HEADERS]\n")
        sb.append("   • Pin 18 (3.3V) ───────(Red)────────► Level Shifter LV / 3V3 Pin\n")
        sb.append("   • Pin 19/20 (GND) ────(Black)───────► Branch 3 (Clean MCU Star GND)\n")
        sb.append("   • PA0 (Yellow)   ◄────────────────── From PC817 Pin 4 (Cam ISR Trigger)\n")
        sb.append("   • PA1 (Orange)   ──────(Orange)─────► Shifter CH3 (LV) ──► Driver PUL-\n")
        sb.append("   • PA2 (Blue)     ──────(Blue)───────► Shifter CH4 (LV) ──► Driver DIR-\n")
        if (isSafety) {
            sb.append("   • PA3 (Brown)    ◄────────────────── From PC817 Ch 1 Pin 4 (Tape Guard)\n")
            sb.append("   • PB0 (Violet)   ◄────────────────── From PC817 Ch 2 Pin 4 (Coil Guard)\n")
            sb.append("   • PB1 (White)    ──────(White)──────► 5V Relay IN (Trips NC Motor Loop)\n")
        }
        sb.append("   • PB6 (Green)    ──────(Green)──────► Shifter CH1 (LV) ──► 16x2 LCD SCL\n")
        sb.append("   • PB7 (White)    ──────(White)──────► Shifter CH2 (LV) ──► 16x2 LCD SDA\n")
        sb.append("   • PB12 (UP)      ──────(Gray)───────► UP Button Leg 1 (Leg 2 to Clean GND)\n")
        sb.append("   • PB13 (DOWN)    ──────(Gray)───────► DOWN Button Leg 1 (Leg 2 to Clean GND)\n")
        sb.append("   • PB14 (MODE)    ──────(Gray)───────► MODE Button Leg 1 (Leg 2 to Clean GND)\n\n")

        sb.append("2. [4-CHANNEL BSS138 LOGIC LEVEL CONVERTER]\n")
        sb.append("   • LV Side: LV to 3.3V (Red), LV-GND to Clean MCU GND (Black)\n")
        sb.append("   • HV Side: HV to +5V Rail (Red), HV-GND to 5V Logic GND (Branch 2 Black)\n")
        sb.append("   • CH1: SCL (PB6 LV ──► LCD SCL HV)\n")
        sb.append("   • CH2: SDA (PB7 LV ──► LCD SDA HV)\n")
        sb.append("   • CH3: PUL- (PA1 LV ──► Driver PUL- HV) [Sinks 12.9mA active-LOW]\n")
        sb.append("   • CH4: DIR- (PA2 LV ──► Driver DIR- HV) [Sinks 12.9mA active-LOW]\n\n")

        sb.append("3. [LEADSHINE DM542 / DM556 STEPPER DRIVER]\n")
        sb.append("   • Signal Terminals:\n")
        sb.append("     - PUL+ ◄── Tied to +5V Regulated Rail (Red Common Anode)\n")
        sb.append("     - DIR+ ◄── Tied to +5V Regulated Rail (Red Common Anode)\n")
        sb.append("     - PUL- ◄── Shifter CH3 HV (Orange Wire)\n")
        sb.append("     - DIR- ◄── Shifter CH4 HV (Blue Wire)\n")
        sb.append("     - ENA+ / ENA- : Leave Unconnected (Driver enabled by default)\n")
        sb.append("   • Power Terminals:\n")
        sb.append("     - VCC  ◄── +24V Main Power Bus (Heavy 18 AWG Red)\n")
        sb.append("     - GND  ──► Branch 1 Power Return GND (Heavy 18 AWG Black)\n")
        sb.append("   • Motor Phase Terminals:\n")
        sb.append("     - A+ / A- ──► NEMA 23 Phase A (Red / Green Wires 18 AWG)\n")
        sb.append("     - B+ / B- ──► NEMA 23 Phase B (Yellow / Blue Wires 18 AWG)\n\n")

        sb.append("4. [PROXIMITY SENSOR & PC817 OPTICAL ISOLATION]\n")
        sb.append("   • 24V Field Side:\n")
        sb.append("     - Sensor Brown Wire ──► +24V Main Power Bus\n")
        sb.append("     - Sensor Blue Wire  ──► Branch 4 (Sensor 24V GND - Isolated)\n")
        sb.append("     - Sensor Black Wire ──► PC817 Pin 2 (Cathode)\n")
        sb.append("     - PC817 Pin 1 (Anode) ──► +24V Bus via 2.2kΩ (1/2W, 1%) Resistor\n")
        sb.append("   • Clean MCU Side:\n")
        sb.append("     - PC817 Pin 3 (Emitter)   ──► Branch 3 (Clean MCU GND) [Zero 24V Noise!]\n")
        sb.append("     - PC817 Pin 4 (Collector) ──► STM32 PA0 with 3.3kΩ pull-up to 3.3V\n\n")

        sb.append("5. [CENTRAL SINGLE-POINT STAR GROUNDING SCHEME]\n")
        sb.append("   All grounds radiate independently from the 24V SMPS Negative Terminal:\n")
        sb.append("   • Branch 1 (Power GND)   : Driver Power Return (Heavy 18 AWG)\n")
        sb.append("   • Branch 2 (5V Logic GND): L7805 GND, LCD GND, Shifter HV-GND (22 AWG)\n")
        sb.append("   • Branch 3 (MCU Clean GND): STM32 GND, Buttons Common, Shifter LV-GND, PC817 Pin 3\n")
        sb.append("   • Branch 4 (Sensor GND)  : Proximity Sensor Blue Wire & Cable Shield\n")
        sb.append("=======================================================================\n")

        return sb.toString()
    }

    fun getTroubleshootingManualText(): String {
        return """
            🛠️ 5-POINT FIELD TROUBLESHOOTER & OPERATION GUIDE

            1. KEYPAD LOCK & UNLOCK:
               • Default state is LOCKED [L].
               • Double-click MODE button (PB14) within 350ms to toggle to UNLOCKED [U].
               • Auto-relocks automatically after 30 seconds of inactivity.
               • RUNNING-STATE INTERLOCK: Hidden menu and reset are completely blocked while machine is running (RPM > 0).

            2. SIZE SWITCHING (#5, #8, #10):
               • While UNLOCKED and machine is stopped (RPM = 0), single-click MODE to cycle:
                 - SIZE #5  (2.50mm pitch - 113.18 steps)
                 - SIZE #8  (3.00mm pitch - 135.81 steps)
                 - SIZE #10 (4.00mm pitch - 181.08 steps)

            3. STEP GEAR PULSE TUNING:
               • While UNLOCKED, hold MODE for 2 to 4 seconds to cycle tuning gear:
                 0.01 pulse -> 0.10 pulse -> 1.00 pulse -> 10.0 pulse -> 100 pulse.
               • Use UP (PB12) and DOWN (PB13) to fine-tune pulses on main screen.

            4. QUICK EEPROM SAVE:
               • While UNLOCKED, hold MODE for 4 to 10 seconds.
               • LCD flashes "SAVED & LOCKED! / EEPROM SYNC OK".

            5. HIDDEN CALIBRATION MENU (Hold MODE > 10s):
               • Option 1: Driver Res (Default: 6400 steps)
               • Option 2: Roller Dia (Default: 45.0 mm)
               • Option 3: Max RPM (Default: 3000 RPM)
               • Option 4: Feed Angle (Default: 160 deg)
               • Option 5: Safety Margin (Default: 10%)
               • Option 6: Sensor Guard (BYPASS [OFF] / ACTIVE [ON])
               • Option 7: Engine Mode (HW-TIMER [AUTO] / DDA-LOOP [DDA])
               • Option 8: Info / Diag (5-point troubleshooter)
               • Option 9: Save & Sync (Commit to memory)
               • Option 10: Cancel / Exit (Discard uncommitted tweaks)

            6. 5-POINT FIELD TROUBLESHOOTING RESOLUTIONS:
               • Issue 1: Motor Stall?
                 -> Increase Feed Angle (>150 deg) or decrease Driver Res (<=6400) / Max RPM.
               • Issue 2: Pitch Error?
                 -> Measure roller diameter with vernier caliper. Tune Dia in Option 2 or pulse gear.
               • Issue 3: Sensor Noise / False RPM?
                 -> Clean cam metal surface. Check PC817 Pin 3 is connected to Clean MCU GND (Branch 3).
               • Issue 4: Stepper Motor Hot?
                 -> Set Driver DIP switch SW4 to HALF-CURRENT. Check current is set to 2.8A - 3.0A.
               • Issue 5: Teeth Drift over long runs?
                 -> Tighten zipper tape guide rail tensioner. Check roller urethane/rubber grip.
        """.trimIndent()
    }
}
