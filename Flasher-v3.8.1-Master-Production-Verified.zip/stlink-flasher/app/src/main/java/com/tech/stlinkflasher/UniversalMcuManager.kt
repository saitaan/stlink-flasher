package com.tech.stlinkflasher

enum class McuPlatform(
    val id: String,
    val displayName: String,
    val defaultProgrammer: String,
    val defaultBaudOrSpeed: String,
    val flashBaseAddress: Long,
    val maxFlashBytes: Long
) {
    STM32(
        id = "stm32",
        displayName = "STM32 (ARM Cortex-M)",
        defaultProgrammer = "ST-Link V2 (SWD)",
        defaultBaudOrSpeed = "1.8 MHz",
        flashBaseAddress = 0x08000000L,
        maxFlashBytes = 128 * 1024L
    ),
    ESP32(
        id = "esp32",
        displayName = "ESP32 (Xtensa / RISC-V)",
        defaultProgrammer = "USB-UART (esptool)",
        defaultBaudOrSpeed = "921600 baud",
        flashBaseAddress = 0x00010000L,
        maxFlashBytes = 4 * 1024 * 1024L
    ),
    ARDUINO(
        id = "arduino",
        displayName = "Arduino AVR (ATmega328P)",
        defaultProgrammer = "USB-UART (Optiboot)",
        defaultBaudOrSpeed = "115200 baud",
        flashBaseAddress = 0x00000000L,
        maxFlashBytes = 32 * 1024L
    )
}

object UniversalMcuManager {
    private var currentPlatform: McuPlatform = McuPlatform.STM32

    fun setPlatform(platform: McuPlatform) {
        currentPlatform = platform
    }

    fun getPlatform(): McuPlatform = currentPlatform

    fun getSupportedPlatforms(): Array<McuPlatform> = McuPlatform.values()

    fun validateBinaryForPlatform(bytes: ByteArray, platform: McuPlatform): Pair<Boolean, String> {
        if (bytes.size > platform.maxFlashBytes) {
            return Pair(false, "Binary size (${bytes.size / 1024} KB) exceeds ${platform.displayName} maximum flash limit (${platform.maxFlashBytes / 1024} KB)!")
        }
        return Pair(true, "Binary valid for ${platform.displayName}")
    }
}
