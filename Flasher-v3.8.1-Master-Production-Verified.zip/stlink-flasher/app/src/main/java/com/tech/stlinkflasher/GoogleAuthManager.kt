package com.tech.stlinkflasher

import android.content.Context
import android.content.SharedPreferences

object GoogleAuthManager {

    private const val PREFS_NAME = "GoogleAuthPrefs"
    private const val KEY_USER_EMAIL = "google_user_email"
    private const val KEY_IS_PRO = "is_pro_tier"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isProAccount(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_IS_PRO, true)
    }

    fun getUserEmail(context: Context): String {
        return getPrefs(context).getString(KEY_USER_EMAIL, "rajesh.shah.301197@gmail.com") ?: "rajesh.shah.301197@gmail.com"
    }

    fun setUserAccount(context: Context, email: String, isPro: Boolean) {
        getPrefs(context).edit()
            .putString(KEY_USER_EMAIL, email)
            .putBoolean(KEY_IS_PRO, isPro)
            .apply()
    }
}
