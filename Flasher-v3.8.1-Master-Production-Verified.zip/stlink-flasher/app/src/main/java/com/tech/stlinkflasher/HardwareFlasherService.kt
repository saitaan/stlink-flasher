package com.tech.stlinkflasher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class HardwareFlasherService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private var heartbeatJob: Job? = null

    companion object {
        const val CHANNEL_ID = "flasher_hardware_service_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_FLASHING = "com.tech.stlinkflasher.action.START_FLASHING"
        const val ACTION_UPDATE_PROGRESS = "com.tech.stlinkflasher.action.UPDATE_PROGRESS"
        const val ACTION_STOP_SERVICE = "com.tech.stlinkflasher.action.STOP_SERVICE"

        const val EXTRA_PROGRESS_PERCENT = "extra_progress_percent"
        const val EXTRA_STATUS_MESSAGE = "extra_status_message"

        fun startFlashing(context: Context, statusMsg: String) {
            val intent = Intent(context, HardwareFlasherService::class.java).apply {
                action = ACTION_START_FLASHING
                putExtra(EXTRA_STATUS_MESSAGE, statusMsg)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun updateProgress(context: Context, percent: Int, statusMsg: String) {
            val intent = Intent(context, HardwareFlasherService::class.java).apply {
                action = ACTION_UPDATE_PROGRESS
                putExtra(EXTRA_PROGRESS_PERCENT, percent)
                putExtra(EXTRA_STATUS_MESSAGE, statusMsg)
            }
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, HardwareFlasherService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        startOtgKeepAliveHeartbeat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE_PROGRESS -> {
                val progress = intent.getIntExtra(EXTRA_PROGRESS_PERCENT, -1)
                val msg = intent.getStringExtra(EXTRA_STATUS_MESSAGE) ?: "Flashing in progress..."
                val notification = buildNotification(msg, progress)
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIFICATION_ID, notification)
            }
            else -> {
                val msg = intent?.getStringExtra(EXTRA_STATUS_MESSAGE) ?: "⚡ Hardware Flasher Online (Anti-Kill Active)"
                val notification = buildNotification(msg, -1)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val fgsType = if (Build.VERSION.SDK_INT >= 34) {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    } else {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                    }
                    startForeground(NOTIFICATION_ID, notification, fgsType)
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_STICKY
    }

    private fun buildNotification(message: String, progress: Int): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Flasher Pro - MCU Anti-Corruption Shield")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (progress in 0..100) {
            builder.setProgress(100, progress, false)
        } else if (progress == -1) {
            builder.setProgress(0, 0, false)
        }

        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hardware Flasher Anti-Kill Service",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Keeps USB hardware connection and flash write active without background interruption."
                setShowBadge(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Flasher:AntiKillWakeLock").apply {
            setReferenceCounted(false)
            acquire(120 * 60 * 1000L)
        }
    }

    private fun startOtgKeepAliveHeartbeat() {
        heartbeatJob = serviceScope.launch {
            while (isActive) {
                delay(45_000L)
                wakeLock?.let {
                    if (!it.isHeld) it.acquire(120 * 60 * 1000L)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        heartbeatJob?.cancel()
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
