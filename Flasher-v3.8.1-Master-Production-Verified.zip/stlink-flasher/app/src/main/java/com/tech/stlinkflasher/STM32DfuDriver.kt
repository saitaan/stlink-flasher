package com.tech.stlinkflasher

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbInterface

class STM32DfuDriver(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val logCallback: (String) -> Unit
) {
    private val DFU_DNLOAD = 1
    private val DFU_GETSTATUS = 3
    private val DFU_CLRSTATUS = 4

    private val REQ_TYPE_DFU_OUT = 0x21 // Host to Device, Class, Interface
    private val REQ_TYPE_DFU_IN = 0xA1  // Device to Host, Class, Interface

    private fun getStatus(): ByteArray {
        val status = ByteArray(6)
        val res = connection.controlTransfer(REQ_TYPE_DFU_IN, DFU_GETSTATUS, 0, usbInterface.id, status, 6, 2000)
        if (res < 0) throw Exception("DFU_GETSTATUS Failed: $res")
        return status
    }

    private fun clearStatus() {
        connection.controlTransfer(REQ_TYPE_DFU_OUT, DFU_CLRSTATUS, 0, usbInterface.id, ByteArray(0), 0, 1000)
    }

    fun flashDfu(binaryData: ByteArray, onProgress: (Int) -> Unit) {
        logCallback(">> Initializing Direct USB DFU Session (Interface: ${usbInterface.id})...")
        clearStatus()
        val initialStatus = getStatus()
        logCallback(">> DFU State: ${initialStatus[4]}, Status: ${initialStatus[0]}")

        val blockSize = 1024
        val totalBlocks = (binaryData.size + blockSize - 1) / blockSize
        logCallback(">> Streaming ${binaryData.size} bytes in $totalBlocks blocks via USB DFU...")

        for (block in 0 until totalBlocks) {
            val offset = block * blockSize
            val length = (binaryData.size - offset).coerceAtMost(blockSize)
            val chunk = ByteArray(length)
            System.arraycopy(binaryData, offset, chunk, 0, length)

            // DFU_DNLOAD wValue: block + 2 for Maple DFU
            val wValue = block + 2
            val res = connection.controlTransfer(REQ_TYPE_DFU_OUT, DFU_DNLOAD, wValue, usbInterface.id, chunk, length, 5000)
            if (res < 0) throw Exception("DFU Download Block $block Failed: $res")

            Thread.sleep(8)
            getStatus()

            val progress = ((block + 1) * 100) / totalBlocks
            onProgress(progress)
        }

        // Finalize DFU (Zero-length packet to trigger Manifestation & execution)
        logCallback(">> Manifesting firmware & launching application...")
        try {
            connection.controlTransfer(REQ_TYPE_DFU_OUT, DFU_DNLOAD, 0, usbInterface.id, ByteArray(0), 0, 1000)
            getStatus()
        } catch (_: Exception) {}

        logCallback(">> Direct USB Flashing completed! STM32 is now running.")
    }
}
