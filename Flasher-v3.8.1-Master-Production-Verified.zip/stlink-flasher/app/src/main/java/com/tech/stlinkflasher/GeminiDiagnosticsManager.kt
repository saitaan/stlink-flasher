package com.tech.stlinkflasher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.regex.Pattern

data class AutoFixAction(
    val type: String,
    val address: Long = 0L,
    val value: Long = 0L,
    val durationMs: Long = 100L,
    val comment: String = ""
)

data class GeminiDiagnosticResult(
    val fullReport: String,
    val canAutoFix: Boolean,
    val fixTitle: String,
    val fixDescription: String,
    val actions: List<AutoFixAction>
)

object GeminiDiagnosticsManager {

    private const val GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

    suspend fun analyzeTelemetryAndBugs(
        apiKey: String,
        telemetryLogs: String,
        registers: Map<String, Long>?,
        boardStatus: String,
        isPro: Boolean = true,
        onLog: (String) -> Unit
    ): GeminiDiagnosticResult = withContext(Dispatchers.IO) {
        try {
            val selectedModel = if (isPro) "gemini-1.5-pro" else "gemini-1.5-flash"
            if (isPro) {
                onLog("👑 [Google Pro Active] Engaging Gemini 1.5 Pro Deep Reasoning Engine...")
            } else {
                onLog("⚡ [Standard Tier] Engaging Gemini 1.5 Flash Engine...")
            }

            val registersFormatted = StringBuilder()
            if (registers != null && registers.isNotEmpty()) {
                registers.forEach { (reg, value) ->
                    val hexVal = "0x" + value.toString(16).padStart(8, '0').uppercase()
                    registersFormatted.append("  • $reg = $hexVal ($value)
")
                }
            } else {
                registersFormatted.append("  [Register dump not available / board in DFU mode]
")
            }

            val systemPrompt = """
                You are an elite Embedded Systems, ARM Cortex-M3 (STM32F103 Blue Pill), Hardware Debugger (ST-Link V2 SWD), and Industrial Automation Firmware Specialist.
                The user is operating a high-speed zipper machinery controller / STM32 tension controller with dancer arm feedback.

                Analyze the provided hardware status, ARM Cortex-M3 core registers (PC, LR, SP, xPSR, R0-R3), and real-time telemetry/serial logs.

                Diagnostic Rules:
                1. Inspect PC (Program Counter): Check if PC is stuck in infinite loop (e.g. 0x0800xxxx), HardFault handler (e.g. 0x080001xx), or Default_Handler.
                2. Inspect LR (Link Register): Check for EXC_RETURN values (0xFFFFFFF9, 0xFFFFFFFD, 0xFFFFFFF1) indicating interrupt/fault state.
                3. Inspect SP (Stack Pointer): Check if SP is within valid SRAM range (0x20000000 to 0x20005000) or corrupt/overflowed.
                4. Inspect Telemetry: Check for sensor anomalies (AS5600 angle / ADC dancer position out of range), Tape Break fault, Coil jam, RPM stalls, or PWM duty saturation.

                REQUIRED RESPONSE STRUCTURE:
                First, provide a structured Markdown report:
                1. 🚨 Status Summary (Healthy / Warning / Critical Stall)
                2. 🔍 Core Register & State Inspection
                3. ⚡ Telemetry & Machine Health Analysis
                4. 🛠️ Suggested Fix Explanation

                Second, at the VERY END of your response, output a strict JSON block wrapped in  that our automated SWD driver can execute if the user chooses Auto-Fix:
                
                If hardware cannot be auto-fixed via SWD, set "can_auto_fix": false and "actions": [].
            """.trimIndent()

            val userMessage = """
                Hardware & Board Status:
                $boardStatus

                ARM Cortex-M3 Core Registers (via SWD):
                $registersFormatted

                Recent Telemetry & Firmware Serial Logs:
                ${if (telemetryLogs.isNotBlank()) telemetryLogs else "[No recent telemetry logs]"}
            """.trimIndent()

            val jsonPayload = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    put("role", "user")
                    val partsArray = JSONArray().apply {
                        put(JSONObject().put("text", "$systemPrompt

$userMessage"))
                    }
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.2)
                    put("maxOutputTokens", 1500)
                }
                put("generationConfig", genConfig)
            }

            val modelUrl = "https://generativelanguage.googleapis.com/v1beta/models/$selectedModel:generateContent?key=${apiKey.trim()}"
            val requestUrl = URL(modelUrl)
            val connection = (requestUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                doOutput = true
                doInput = true
                connectTimeout = 15000
                readTimeout = 35000
            }

            OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                writer.write(jsonPayload.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val responseText = connection.inputStream.bufferedReader().use(BufferedReader::readText)
                val responseJson = JSONObject(responseText)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val rawText = parts.getJSONObject(0).optString("text", "")
                        return@withContext parseDiagnosticResponse(rawText)
                    }
                }
                return@withContext GeminiDiagnosticResult(
                    fullReport = "⚠️ Gemini response received but no candidate text generated.",
                    canAutoFix = false,
                    fixTitle = "No actions",
                    fixDescription = "",
                    actions = emptyList()
                )
            } else {
                val errorStream = connection.errorStream?.bufferedReader()?.use(BufferedReader::readText) ?: "No error body"
                onLog("❌ HTTP $responseCode Error: $errorStream")
                return@withContext GeminiDiagnosticResult(
                    fullReport = "❌ Gemini API Error (HTTP $responseCode):
$errorStream

Please verify that your Gemini API Key is valid and has Generative Language API enabled.",
                    canAutoFix = false,
                    fixTitle = "API Error",
                    fixDescription = "",
                    actions = emptyList()
                )
            }
        } catch (e: Exception) {
            onLog("❌ Exception: ${e.message}")
            return@withContext GeminiDiagnosticResult(
                fullReport = "❌ Failed to connect to Gemini API: ${e.localizedMessage ?: e.message}",
                canAutoFix = false,
                fixTitle = "Connection Failed",
                fixDescription = "",
                actions = emptyList()
            )
        }
    }

    private fun parseDiagnosticResponse(rawText: String): GeminiDiagnosticResult {
        var reportText = rawText
        var canAutoFix = false
        var fixTitle = "Suggested Fix"
        var fixDescription = ""
        val actions = mutableListOf<AutoFixAction>()

        try {
            val jsonPattern = Pattern.compile("", Pattern.DOTALL)
            val matcher = jsonPattern.matcher(rawText)
            if (matcher.find()) {
                val jsonString = matcher.group(1)
                reportText = rawText.substring(0, matcher.start()).trim()
                if (jsonString != null) {
                    val jsonObj = JSONObject(jsonString)
                    canAutoFix = jsonObj.optBoolean("can_auto_fix", false)
                    fixTitle = jsonObj.optString("fix_title", "Automatic SWD Fix")
                    fixDescription = jsonObj.optString("fix_description", "")

                    val actionsArray = jsonObj.optJSONArray("actions")
                    if (actionsArray != null) {
                        for (i in 0 until actionsArray.length()) {
                            val actObj = actionsArray.getJSONObject(i)
                            val type = actObj.optString("type", "").uppercase()
                            val addrStr = actObj.optString("address", "0")
                            val valStr = actObj.optString("value", "0")
                            val duration = actObj.optLong("duration_ms", 100L)
                            val comment = actObj.optString("comment", "")

                            val addr = parseHexOrDec(addrStr)
                            val value = parseHexOrDec(valStr)

                            if (type.isNotEmpty()) {
                                actions.add(AutoFixAction(type, addr, value, duration, comment))
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        return GeminiDiagnosticResult(
            fullReport = reportText,
            canAutoFix = canAutoFix && actions.isNotEmpty(),
            fixTitle = fixTitle,
            fixDescription = fixDescription,
            actions = actions
        )
    }

    private fun parseHexOrDec(str: String): Long {
        val s = str.trim()
        return try {
            if (s.startsWith("0x", ignoreCase = true)) {
                java.lang.Long.parseUnsignedLong(s.substring(2), 16)
            } else {
                java.lang.Long.parseLong(s)
            }
        } catch (_: Exception) {
            0L
        }
    }
}
