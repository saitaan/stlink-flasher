package com.tech.stlinkflasher

import java.nio.ByteBuffer
import java.nio.ByteOrder

object HardwareSafetyInterlock {

    private var isFlashingInProgress: Boolean = false

    fun setFlashingActive(active: Boolean) {
        isFlashingInProgress = active
    }

    fun isFlashingActive(): Boolean = isFlashingInProgress

    fun canSafelyFlashMachine(currentRpm: Int, stepsRemaining: Int): Pair<Boolean, String> {
        if (currentRpm > 0) {
            return Pair(false, "SAFETY INTERLOCK ENGAGED: Machine main shaft is rotating ($currentRpm RPM). Flashing blocked to prevent mechanical crash!")
        }
        if (stepsRemaining > 0) {
            return Pair(false, "SAFETY INTERLOCK ENGAGED: Stepper motor is actively stepping ($stepsRemaining steps remaining). Flashing blocked!")
        }
        return Pair(true, "Machine stationary. Safe to flash.")
    }

    fun verifyArmVectorTable(binary: ByteArray): Pair<Boolean, String> {
        if (binary.size < 8) {
            return Pair(false, "Binary too small (${binary.size} bytes). Minimum 8 bytes required for ARM vector table.")
        }

        val buffer = ByteBuffer.wrap(binary).order(ByteOrder.LITTLE_ENDIAN)
        val initialSp = buffer.int.toLong() and 0xFFFFFFFFL
        val resetHandler = buffer.int.toLong() and 0xFFFFFFFFL

        val isSpValid = initialSp in 0x20000000L..0x20005000L
        val isPcValid = resetHandler in 0x08000000L..0x08020000L && (resetHandler % 2L != 0L)

        if (!isSpValid) {
            return Pair(false, "CORRUPT BINARY DETECTED: Initial Stack Pointer (0x%08X) is outside STM32 20KB SRAM range (0x20000000 - 0x20005000). Flashing aborted!".format(initialSp))
        }

        if (!isPcValid) {
            return Pair(false, "CORRUPT BINARY DETECTED: Reset Vector PC (0x%08X) is outside Flash ROM range or missing Thumb bit. Flashing aborted!".format(resetHandler))
        }

        return Pair(true, "Vector Table Verified: SP=0x%08X (Valid SRAM), PC=0x%08X (Valid Thumb Code)".format(initialSp, resetHandler))
    }
}
