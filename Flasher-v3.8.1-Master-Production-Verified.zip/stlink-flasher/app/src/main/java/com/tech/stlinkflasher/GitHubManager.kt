package com.tech.stlinkflasher

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GitHubManager {

    fun getOrCreateRepo(
        token: String,
        owner: String,
        repo: String,
        onLog: (String) -> Unit
    ): Boolean {
        try {
            val checkUrl = URL("https://api.github.com/repos/$owner/$repo")
            val conn = checkUrl.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            val code = conn.responseCode

            if (code == 200) {
                onLog("📦 Repository '$owner/$repo' found and accessible.")
                return true
            }

            if (code == 404) {
                onLog("📦 Repository '$repo' not found. Auto-creating repository via GitHub API...")
                val createUrl = URL("https://api.github.com/user/repos")
                val postConn = createUrl.openConnection() as HttpURLConnection
                postConn.requestMethod = "POST"
                postConn.setRequestProperty("Authorization", "Bearer $token")
                postConn.setRequestProperty("Accept", "application/vnd.github+json")
                postConn.setRequestProperty("Content-Type", "application/json")
                postConn.doOutput = true

                val payload = JSONObject().apply {
                    put("name", repo)
                    put("description", "Automated STM32 Firmware Repository created by Flasher Mobile Suite")
                    put("private", false)
                    put("auto_init", true)
                }

                postConn.outputStream.use { it.write(payload.toString().toByteArray()) }
                val createCode = postConn.responseCode
                if (createCode == 201) {
                    onLog("✅ Repository '$owner/$repo' created successfully!")
                    return true
                } else {
                    val err = postConn.errorStream?.bufferedReader()?.use { it.readText() }
                    onLog("❌ Failed to create repo (HTTP $createCode): $err")
                    return false
                }
            }

            onLog("⚠️ Unexpected GitHub API response code: $code")
            return false
        } catch (e: Exception) {
            onLog("❌ GitHub Manager Error: ${e.message}")
            return false
        }
    }

    fun commitOrUpdateFile(
        token: String,
        owner: String,
        repo: String,
        path: String,
        contentBytes: ByteArray,
        commitMessage: String,
        onLog: (String) -> Unit
    ): Boolean {
        try {
            var currentSha: String? = null
            val getUrl = URL("https://api.github.com/repos/$owner/$repo/contents/$path")
            val getConn = getUrl.openConnection() as HttpURLConnection
            getConn.requestMethod = "GET"
            getConn.setRequestProperty("Authorization", "Bearer $token")
            getConn.setRequestProperty("Accept", "application/vnd.github+json")

            if (getConn.responseCode == 200) {
                val resp = getConn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(resp)
                currentSha = json.optString("sha")
            }

            val putConn = getUrl.openConnection() as HttpURLConnection
            putConn.requestMethod = "PUT"
            putConn.setRequestProperty("Authorization", "Bearer $token")
            putConn.setRequestProperty("Accept", "application/vnd.github+json")
            putConn.setRequestProperty("Content-Type", "application/json")
            putConn.doOutput = true

            val b64 = Base64.encodeToString(contentBytes, Base64.NO_WRAP)
            val body = JSONObject().apply {
                put("message", commitMessage)
                put("content", b64)
                if (currentSha != null) {
                    put("sha", currentSha)
                }
            }

            putConn.outputStream.use { it.write(body.toString().toByteArray()) }
            val putCode = putConn.responseCode
            return putCode == 200 || putCode == 201
        } catch (e: Exception) {
            onLog("❌ Commit Error ($path): ${e.message}")
            return false
        }
    }
}
