package com.tech.stlinkflasher

object OfflineDiagnosticsEngine {

    fun diagnose(
        currentRpm: Int,
        pulseWidthUs: Int,
        activeSizeNum: Int,
        tapeFault: Boolean,
        coilFault: Boolean
    ): String {
        val sb = StringBuilder()
        sb.append("📋 [OFFLINE HEURISTIC DIAGNOSTICS REPORT]\n")
        sb.append("--------------------------------------------------\n")
        sb.append("• Machine Speed  : $currentRpm RPM\n")
        sb.append("• Active Size    : Size #$activeSizeNum\n")
        sb.append("• Pulse Width    : $pulseWidthUs µs\n")
        sb.append("• Tape Sensor PA3: ${if (tapeFault) "FAULT (EMPTY/SNAP)" else "OK"}\n")
        sb.append("• Coil Sensor PB0: ${if (coilFault) "FAULT (JAM/EMPTY)" else "OK"}\n")
        sb.append("--------------------------------------------------\n")

        var issueFound = false

        if (tapeFault) {
            issueFound = true
            sb.append("🚨 ISSUE 1: Fabric Tape Run-Out Detected (PA3 = HIGH)!\n")
            sb.append("👉 Action: Main motor clutch is tripped. Reload zipper tape and check PC817 Opto 1 wiring.\n\n")
        }

        if (coilFault) {
            issueFound = true
            sb.append("🚨 ISSUE 2: Coil Breakage / Jam Detected (PB0 = HIGH)!\n")
            sb.append("👉 Action: Inspect tooth guide dies for coil jam. Clean fiber-optic lens.\n\n")
        }

        if (pulseWidthUs in 1..5) {
            issueFound = true
            sb.append("⚠️ ISSUE 3: Pulse Width is in Strain Zone (${pulseWidthUs} µs < 6 µs)!\n")
            sb.append("👉 Action: Stepper driver optical optocoupler may lag. In Hidden Menu, reduce Driver Res or increase Feed Angle.\n\n")
        }

        if (currentRpm > 3200) {
            issueFound = true
            sb.append("⚠️ ISSUE 4: Machine RPM ($currentRpm) exceeds rated maximum (3000 RPM)!\n")
            sb.append("👉 Action: Reduce main sewing motor inverter/clutch speed to prevent step loss.\n\n")
        }

        if (!issueFound) {
            sb.append("✅ SYSTEM HEALTH: OPTIMAL\n")
            sb.append("All timing parameters, sensor lines, and synchronization loops are healthy.\n")
        }

        return sb.toString()
    }
}
