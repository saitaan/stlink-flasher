package com.tech.stlinkflasher

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * FaultBlackboxManager
 * Automated Industrial Fault & Error Blackbox Recorder.
 * Records unexpected trips (overcurrent, step loss, sensor disconnects, SWD stalls)
 * with microsecond precision, operational telemetry, and automatic persistence.
 */
class FaultBlackboxManager private constructor(private val context: Context) {

    data class FaultRecord(
        val timestamp: Long,
        val formattedTime: String,
        val category: String,
        val message: String,
        val rpm: Int,
        val tensionVolts: Float,
        val resolved: Boolean = false
    )

    private val logFile = File(context.filesDir, "blackbox_faults.json")
    private val faultList = mutableListOf<FaultRecord>()

    init {
        loadFaults()
    }

    @Synchronized
    private fun loadFaults() {
        faultList.clear()
        if (logFile.exists()) {
            try {
                val jsonStr = logFile.readText()
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    faultList.add(
                        FaultRecord(
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            formattedTime = obj.optString("time", ""),
                            category = obj.optString("category", "SYSTEM"),
                            message = obj.optString("message", ""),
                            rpm = obj.optInt("rpm", 0),
                            tensionVolts = obj.optDouble("tension", 0.0).toFloat(),
                            resolved = obj.optBoolean("resolved", false)
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @Synchronized
    private fun saveFaults() {
        try {
            val arr = JSONArray()
            for (f in faultList) {
                val obj = JSONObject().apply {
                    put("timestamp", f.timestamp)
                    put("time", f.formattedTime)
                    put("category", f.category)
                    put("message", f.message)
                    put("rpm", f.rpm)
                    put("tension", f.tensionVolts)
                    put("resolved", f.resolved)
                }
                arr.put(obj)
            }
            logFile.writeText(arr.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Synchronized
    fun recordFault(category: String, message: String, rpm: Int = 0, tensionV: Float = 0f) {
        val now = System.currentTimeMillis()
        val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(now))
        val record = FaultRecord(
            timestamp = now,
            formattedTime = timeStr,
            category = category,
            message = message,
            rpm = rpm,
            tensionVolts = tensionV
        )
        faultList.add(0, record)
        if (faultList.size > 200) {
            faultList.removeAt(faultList.size - 1)
        }
        saveFaults()
    }

    @Synchronized
    fun getFaultCount(): Int = faultList.size

    @Synchronized
    fun getRecentFaultsFormatted(limit: Int = 10): String {
        if (faultList.isEmpty()) {
            return "✅ [BLACKBOX STATUS: NORMAL]\nNo critical hardware faults recorded. System operational."
        }
        val sb = StringBuilder()
        sb.append("⚠️ [BLACKBOX FAULT LOG - RECENT ENTRIES]\n")
        val subset = faultList.take(limit)
        for ((idx, f) in subset.withIndex()) {
            sb.append("\n#${idx + 1} [${f.formattedTime}] [${f.category}]\n")
            sb.append("   • Fault: ${f.message}\n")
            sb.append("   • Telemetry at Trip: ${f.rpm} RPM | Dancer Tension: ${String.format(Locale.US, "%.2f", f.tensionVolts)}V\n")
        }
        return sb.toString().trim()
    }

    @Synchronized
    fun exportToDownloads(): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadDir.exists()) downloadDir.mkdirs()
        val exportFile = File(downloadDir, "Blackbox_Fault_Audit_${timestamp}.txt")
        val content = StringBuilder()
        content.append("=====================================================\n")
        content.append("FLASHER INDUSTRIAL AUTOMATED FAULT BLACKBOX AUDIT\n")
        content.append("Lead Engineer: Rajesh Shah | Nipon Zipper Industries\n")
        content.append("Generated on: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
        content.append("Total Recorded Faults: ${faultList.size}\n")
        content.append("=====================================================\n\n")

        for ((idx, f) in faultList.withIndex()) {
            content.append("[ENTRY #${idx + 1}]\n")
            content.append("Timestamp: ${f.formattedTime}\n")
            content.append("Category : ${f.category}\n")
            content.append("Fault    : ${f.message}\n")
            content.append("Telemetry: ${f.rpm} RPM | Dancer: ${f.tensionVolts}V\n")
            content.append("-----------------------------------------------------\n")
        }

        FileOutputStream(exportFile).use { it.write(content.toString().toByteArray()) }
        return exportFile
    }

    @Synchronized
    fun clearFaults() {
        faultList.clear()
        if (logFile.exists()) logFile.delete()
    }

    companion object {
        @Volatile
        private var instance: FaultBlackboxManager? = null

        fun getInstance(context: Context): FaultBlackboxManager {
            return instance ?: synchronized(this) {
                instance ?: FaultBlackboxManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
