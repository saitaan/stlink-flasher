package com.tech.stlinkflasher

import android.content.Context
import android.hardware.usb.UsbDevice
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AutomationManager private constructor(private val context: Context) {

    interface AutomationListener {
        fun onAutomationStatusChanged(isAutoPilot: Boolean)
        fun onAutomationLog(message: String)
        fun onAutomationProgress(percent: Int, currentBytes: Int, totalBytes: Int)
        fun onAutomationSuccess(coreId: Long, bytesProgrammed: Int)
        fun onAutomationFailed(error: String)
    }

    private val listeners = mutableListOf<AutomationListener>()
    private val settings = SettingsManager.getInstance(context)
    private var isBusy = false

    fun addListener(listener: AutomationListener) {
        synchronized(listeners) {
            if (!listeners.contains(listener)) listeners.add(listener)
        }
    }

    fun removeListener(listener: AutomationListener) {
        synchronized(listeners) { listeners.remove(listener) }
    }

    fun isAutoPilot(): Boolean {
        return settings.operationMode == SettingsManager.OperationMode.AUTOMATED_AUTO_PILOT
    }

    fun setAutoPilot(enabled: Boolean) {
        settings.operationMode = if (enabled) {
            SettingsManager.OperationMode.AUTOMATED_AUTO_PILOT
        } else {
            SettingsManager.OperationMode.MANUAL
        }
        notifyStatus(enabled)
    }

    private fun notifyStatus(isAuto: Boolean) {
        synchronized(listeners) {
            listeners.forEach { it.onAutomationStatusChanged(isAuto) }
        }
    }

    fun log(msg: String) {
        synchronized(listeners) {
            listeners.forEach { it.onAutomationLog(msg) }
        }
    }

    private fun notifyProgress(percent: Int, cur: Int, tot: Int) {
        synchronized(listeners) {
            listeners.forEach { it.onAutomationProgress(percent, cur, tot) }
        }
    }

    private fun notifySuccess(coreId: Long, bytes: Int) {
        synchronized(listeners) {
            listeners.forEach { it.onAutomationSuccess(coreId, bytes) }
        }
    }

    private fun notifyFailed(err: String) {
        synchronized(listeners) {
            listeners.forEach { it.onAutomationFailed(err) }
        }
    }

    fun triggerHapticFeedback(success: Boolean) {
        if (!settings.hapticFeedback) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val vib = vm?.defaultVibrator
                if (success) {
                    vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 100, 80, 200), -1))
                } else {
                    vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 100, 300), -1))
                }
            } else {
                @Suppress("DEPRECATION")
                val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (success) {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(longArrayOf(0, 100, 80, 200), -1)
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(longArrayOf(0, 300, 100, 300), -1)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onUsbDeviceAttached(
        device: UsbDevice,
        driverProvider: () -> STLinkV2Driver?,
        productionFirmwareProvider: () -> ByteArray?
    ) {
        if (!isAutoPilot()) {
            log("ℹ️ [MANUAL MODE] USB device attached: ${device.deviceName}. Awaiting operator action.")
            return
        }

        if (isBusy) {
            log("⚠️ Auto-Pilot already in progress. Ignoring duplicate trigger.")
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            isBusy = true
            try {
                log("🚀 [AUTO-PILOT ACTIVE] ST-Link USB insertion detected! Starting hands-free sequence...")
                delay(400)

                val driver = driverProvider()
                if (driver == null) {
                    log("❌ Auto-Pilot error: ST-Link driver initialization failed.")
                    triggerHapticFeedback(false)
                    notifyFailed("ST-Link driver unavailable")
                    return@launch
                }

                log("🔍 Auto-Pilot: Entering SWD mode & probing Cortex-M3 Core...")
                val coreId = driver.initSession()
                if (coreId == 0L) {
                    log("❌ Auto-Pilot: Failed to read Core ID. Check SWD pins (PA13/PA14) & 3.3V.")
                    triggerHapticFeedback(false)
                    notifyFailed("SWD Probe Failed")
                    return@launch
                }
                log("✅ Auto-Pilot: Target Found! Core ID = 0x${coreId.toString(16).uppercase()}")

                driver.haltCore()
                log("⏸️ Auto-Pilot: Target halted cleanly.")

                val firmwareBytes = productionFirmwareProvider()
                if (firmwareBytes == null || firmwareBytes.isEmpty()) {
                    log("❌ Auto-Pilot error: Production firmware binary not loaded.")
                    triggerHapticFeedback(false)
                    notifyFailed("Firmware asset missing")
                    return@launch
                }
                log("📦 Auto-Pilot: Firmware ready (${firmwareBytes.size} bytes). Target: 0x08000000.")

                log("🧹 Auto-Pilot: Performing STM32 Flash Mass Erase...")
                driver.unlockFlash()
                driver.eraseFlash()

                log("⚡ Auto-Pilot: Flashing ${firmwareBytes.size} bytes...")
                driver.flashBinary(0x08000000L, firmwareBytes) { pct ->
                    val cur = (pct * firmwareBytes.size) / 100
                    notifyProgress(pct, cur, firmwareBytes.size)
                }

                if (settings.autoVerifyAfterFlash) {
                    log("🔍 Auto-Pilot: Verifying flash memory checksum...")
                    val readBack = driver.readFlash(0x08000000L, firmwareBytes.size) { pct ->
                        notifyProgress(pct, (pct * firmwareBytes.size) / 100, firmwareBytes.size)
                    }
                    if (!readBack.contentEquals(firmwareBytes)) {
                        log("❌ Auto-Pilot: Flash verification mismatch! Firmware corrupted.")
                        triggerHapticFeedback(false)
                        notifyFailed("Verification Failed")
                        return@launch
                    }
                    log("✅ Auto-Pilot: Flash Verification Passed (100% Match)!")
                }

                if (settings.autoResetAfterFlash) {
                    log("🔄 Auto-Pilot: Issuing Target System Reset...")
                    driver.resetTarget()
                    log("✨ Auto-Pilot: STM32 Booted into Production Firmware V16.5.0!")
                }

                settings.totalShiftCuts += 100
                settings.totalShiftMeters += 0.25f

                triggerHapticFeedback(true)
                notifySuccess(coreId, firmwareBytes.size)
                log("🎉 [AUTO-PILOT COMPLETE] Board programmed & verified hands-free! Ready for next unit.")

            } catch (e: Exception) {
                log("❌ Auto-Pilot Exception: ${e.message}")
                triggerHapticFeedback(false)
                notifyFailed(e.message ?: "Unknown error")
            } finally {
                isBusy = false
            }
        }
    }

    companion object {
        @Volatile
        private var instance: AutomationManager? = null

        fun getInstance(context: Context): AutomationManager {
            return instance ?: synchronized(this) {
                instance ?: AutomationManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
