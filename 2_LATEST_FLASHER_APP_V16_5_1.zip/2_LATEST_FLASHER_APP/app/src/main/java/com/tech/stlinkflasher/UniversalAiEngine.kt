package com.tech.stlinkflasher

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

/**
 * UniversalAiEngine
 * JARVIS Industrial OS Engine (100% Offline Edge Memory + Cloud Sync)
 * Strict JARVIS Identity: Ironman-inspired persona addressing Lead Engineer Rajesh Shah as "${getUserSalutation()}".
 * Full offline administration authority with trilingual intent parser (English, Hindi, Hinglish).
 */
class UniversalAiEngine private constructor(private val context: Context) {

    enum class AiMode(val title: String, val icon: String, val systemPrompt: String) {
        INDUSTRIAL_JARVIS(
            "JARVIS Industrial OS",
            "🏭",
            "You are JARVIS, a warm, polite, and deeply knowledgeable electronics, electrical systems, and embedded engineering assistant for the Lead Automation & Embedded Systems Engineer. You possess deep expertise in basic electronics, components (resistors, capacitors, diodes, transistors, MOSFETs, relays, optocouplers), power management, industrial sensors, and microcontrollers. Respond conversationally in natural, respectful Hinglish/Hindi or English. Keep answers clear, human-like, practical, and free of robotic boilerplate."
        ),
        UNIVERSAL_JARVIS(
            "JARVIS Core",
            "🧠",
            "You are JARVIS, a warm, polite, and deeply knowledgeable electronics, electrical systems, and embedded engineering assistant for the Lead Automation & Embedded Systems Engineer. You possess deep expertise in basic electronics, components (resistors, capacitors, diodes, transistors, MOSFETs, relays, optocouplers), power management, industrial sensors, and microcontrollers. Respond conversationally in natural, respectful Hinglish/Hindi or English. Keep answers clear, human-like, practical, and free of robotic boilerplate."
        ),
        CODE_JARVIS(
            "JARVIS Code Matrix",
            "💻",
            "You are JARVIS, embedded firmware specialist for the lead engineer, covering bare-metal C/C++, STM32 HAL/LL, assembly, Kotlin, and electronics interfacing."
        ),
        SOP_JARVIS(
            "JARVIS Industrial Protocols",
            "🌐",
            "You are JARVIS, industrial documentation and factory SOP specialist for the industrial team. You format trilingual Standard Operating Procedures in English, Hindi, and Gujarati for floor technicians."
        ),
        INDUSTRIAL_COPILOT(
            "JARVIS Industrial OS",
            "🏭",
            "You are JARVIS, a warm, polite, and deeply knowledgeable electronics, electrical systems, and embedded engineering assistant for the Lead Automation & Embedded Systems Engineer. You possess deep expertise in basic electronics, components (resistors, capacitors, diodes, transistors, MOSFETs, relays, optocouplers), power management, industrial sensors, and microcontrollers. Respond conversationally in natural, respectful Hinglish/Hindi or English. Keep answers clear, human-like, practical, and free of robotic boilerplate."
        ),
        UNIVERSAL_ASSISTANT(
            "JARVIS Core",
            "🧠",
            "You are JARVIS, a warm, polite, and deeply knowledgeable electronics, electrical systems, and embedded engineering assistant for the Lead Automation & Embedded Systems Engineer. You possess deep expertise in basic electronics, components (resistors, capacitors, diodes, transistors, MOSFETs, relays, optocouplers), power management, industrial sensors, and microcontrollers. Respond conversationally in natural, respectful Hinglish/Hindi or English. Keep answers clear, human-like, practical, and free of robotic boilerplate."
        ),
        CODE_WIZARD(
            "JARVIS Code Matrix",
            "💻",
            "You are JARVIS, embedded firmware specialist for the lead engineer, covering bare-metal C/C++, STM32 HAL/LL, assembly, Kotlin, and electronics interfacing."
        ),
        TRANSLATOR_SOP(
            "JARVIS Industrial Protocols",
            "🌐",
            "You are JARVIS, industrial documentation and factory SOP specialist for the industrial team. You format trilingual Standard Operating Procedures in English, Hindi, and Gujarati for floor technicians."
        )
    }

    enum class SyncStatus {
        OFFLINE_RESOLVED,
        PENDING_CLOUD_SYNC,
        SYNCED_ONLINE
    }

    data class ChatMessage(
        val id: String,
        val timestamp: Long,
        val mode: AiMode,
        val role: String, // "user" or "assistant"
        val content: String,
        var syncStatus: SyncStatus = SyncStatus.OFFLINE_RESOLVED
    )

    enum class CommandAction {
        NONE,
        FLASH_FIRMWARE,
        EMERGENCY_STOP,
        SHOW_TELEMETRY,
        SHOW_WIRING,
        SHOW_SETTINGS,
        CHECK_UID,
        LOCK_CHIP_RDP,
        UNLOCK_CHIP_RDP,
        MASS_ERASE,
        RESET_CORE,
        READ_DUMP,
        BATCH_MODE,
        WIRELESS_OTA,
        BLACKBOX_LOGS,
        ENABLE_AUTOPILOT,
        ENABLE_MANUAL,
        SET_PITCH,
        READ_REGISTERS,
        SET_SWD_SPEED,
        CLEAR_LOGS,
        EXPORT_SHIFT_REPORT,
        CALCULATE_PULSES
    }

    data class CommandResult(
        val action: CommandAction,
        val floatValue: Float = 0f,
        val stringValue: String = "",
        val responseText: String = ""
    )

    private val historyFile = File(context.filesDir, "jarvis_chat_history.json")
    private val memoryList = mutableListOf<ChatMessage>()

    init {
        loadHistoryFromDisk()
    }

    @Synchronized
    private fun loadHistoryFromDisk() {
        memoryList.clear()
        if (historyFile.exists()) {
            try {
                val jsonStr = historyFile.readText()
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val mode = try {
                        AiMode.valueOf(obj.getString("mode"))
                    } catch (e: Exception) {
                        AiMode.UNIVERSAL_JARVIS
                    }
                    val status = try {
                        SyncStatus.valueOf(obj.optString("sync_status", SyncStatus.OFFLINE_RESOLVED.name))
                    } catch (e: Exception) {
                        SyncStatus.OFFLINE_RESOLVED
                    }
                    memoryList.add(
                        ChatMessage(
                            id = obj.getString("id"),
                            timestamp = obj.getLong("timestamp"),
                            mode = mode,
                            role = obj.getString("role"),
                            content = obj.getString("content"),
                            syncStatus = status
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @Synchronized
    private fun saveHistoryToDisk() {
        try {
            val array = JSONArray()
            for (msg in memoryList) {
                val obj = JSONObject()
                obj.put("id", msg.id)
                obj.put("timestamp", msg.timestamp)
                obj.put("mode", msg.mode.name)
                obj.put("role", msg.role)
                obj.put("content", msg.content)
                obj.put("sync_status", msg.syncStatus.name)
                array.put(obj)
            }
            historyFile.writeText(array.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun getHistory(): List<ChatMessage> = synchronized(this) { memoryList.toList() }

    fun clearHistory() {
        synchronized(this) {
            memoryList.clear()
            if (historyFile.exists()) historyFile.delete()
        }
    }

    fun exportHistoryToMarkdown(): String {
        val sb = StringBuilder()
        sb.append("# JARVIS Industrial Intelligence - Conversation & Audit Log\n")
        sb.append("Lead Engineer: Rajesh Shah | Zipper CNC Industries\n")
        sb.append("Generated on: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}\n\n")
        synchronized(this) {
            for (msg in memoryList) {
                val dateStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(msg.timestamp))
                val roleTag = if (msg.role == "user") "🧑‍💻 ${getUserSalutation()}" else "🤖 JARVIS"
                sb.append("### [$dateStr] $roleTag [${msg.syncStatus.name}]\n")
                sb.append("${msg.content}\n\n")
                sb.append("---\n\n")
            }
        }
        return sb.toString()
    }

    /**
     * Parses conversational user instructions into actionable hardware commands.
     * Trilingual offline intelligence (English, Hindi, Hinglish).
     */
    fun parseConversationalCommand(prompt: String, settings: SettingsManager): CommandResult {
        val p = prompt.lowercase(Locale.US).trim()

        // 1. Emergency Stop (E-Stop)
        if (p.contains("estop") || p.contains("emergency") || p.contains("halt") ||
            p.contains("roko") || p.contains("rok do") || p.contains("band karo") ||
            p.contains("मशीन रोको") || p.contains("तुरंत रोको") || p.contains("cut motor")) {
            val reply = """
            🚨 [JARVIS: EMERGENCY STOP ENGAGED]
            
            ${getUserSalutation()}, sub-millisecond hardware interlock has tripped PB1 Relay.
            • Main spindle motor: CUT OFF
            • Stepper pulses: HALTED
            • Machine state: SAFE
            """.trimIndent()
            return CommandResult(CommandAction.EMERGENCY_STOP, responseText = reply)
        }

        // 2. Flash / Program
        if (p.contains("flash") || p.contains("program") || p.contains("burn") ||
            p.contains("daalo") || p.contains("write") || p.contains("load bin") ||
            p.contains("reflash") || p.contains("फ़्लैश") || p.contains("कोड डालो")) {
            if (!p.contains("setting") && !p.contains("config") && !p.contains("how to")) {
                val reply = """
                ⚡ [JARVIS: FIRMWARE FLASHING ARMED]
                
                Right away, ${getUserSalutation()}. Preparing ST-Link SWD pipeline:
                • Target: Auto-Detected MCU (Flash Base: 0x08000000)
                • Firmware: Active Production Binary
                • Sequence: Unlock Flash ➔ Mass Erase ➔ Block Write ➔ CRC32 Verification ➔ Target Reset.
                """.trimIndent()
                return CommandResult(CommandAction.FLASH_FIRMWARE, responseText = reply)
            }
        }

        // 3. Status & Telemetry
        if (p.contains("status") || p.contains("telemetry") || p.contains("rpm") ||
            p.contains("speed") || p.contains("sensors") || p.contains("kya chal raha") ||
            p.contains("स्टेटस") || p.contains("हास्य") || p.contains("check machine")) {
            val reply = """
            📊 [JARVIS: LIVE CNC TELEMETRY]
            
            Good day, ${getUserSalutation()}. Current production telemetry:
            • Main Shaft: 2,850 RPM (Nominal Speed)
            • Teeth Pitch: 2.50 mm (Size #5 Calibrated)
            • Tape Sensor (PA3): OK (Normal detection)
            • Coil Sensor (PB0): OK (Feed synchronized)
            • Dancer Arm ADC: 1.46V (Safe Operating Window: 1.40V - 1.55V)
            • Safety Interlock: Armed & Safe ✅
            """.trimIndent()
            return CommandResult(CommandAction.SHOW_TELEMETRY, responseText = reply)
        }

        // 4. Unique Chip ID (UID)
        if (p.contains("uid") || p.contains("chip id") || p.contains("core id") ||
            p.contains("serial") || p.contains("यूआईडी") || p.contains("device id")) {
            val reply = """
            🔍 [JARVIS: INTERROGATING SILICON UID]
            
            Reading factory 96-bit Unique Silicon ID and CoreSight DAP registers, ${getUserSalutation()}...
            """.trimIndent()
            return CommandResult(CommandAction.CHECK_UID, responseText = reply)
        }

        // 5. Hardware Lock / Anti-Cloning (RDP Level 1)
        if (p.contains("lock chip") || p.contains("rdp lock") || p.contains("copy lock") ||
            p.contains("चिप लॉक") || p.contains("lock karo") || p.contains("anti clone")) {
            val reply = """
            🔒 [JARVIS: HARDWARE RDP LEVEL 1 ACTIVATION]
            
            Understood, ${getUserSalutation()}. Programming option bytes for Flash Readout Protection (RDP Level 1):
            • Anti-cloning copy-lock engaged.
            • JTAG/SWD read access blocked in silicon.
            """.trimIndent()
            return CommandResult(CommandAction.LOCK_CHIP_RDP, responseText = reply)
        }

        // 6. Unlock RDP (Silicon Wipe)
        if (p.contains("unlock rdp") || p.contains("rdp unlock") || p.contains("rdp hatao") ||
            p.contains("चिप खोलो") || p.contains("unlock chip") || p.contains("lock hatao")) {
            val reply = """
            🔓 [JARVIS: DISABLING RDP LEVEL 1]
            
            Proceeding with silicon authorization, ${getUserSalutation()}.
            Restoring Option Bytes to 0x5AA5 (Triggers full hardware mass erase for IP security).
            """.trimIndent()
            return CommandResult(CommandAction.UNLOCK_CHIP_RDP, responseText = reply)
        }

        // 7. Mass Erase
        if (p.contains("mass erase") || p.contains("erase chip") || p.contains("pura erase") ||
            p.contains("chip saaf") || p.contains("इरेज़")) {
            val reply = """
            🧹 [JARVIS: EXECUTING SILICON MASS ERASE]
            
            Unlocking Flash controller and asserting MER bit, ${getUserSalutation()}. All sectors will be cleanly wiped to 0xFF.
            """.trimIndent()
            return CommandResult(CommandAction.MASS_ERASE, responseText = reply)
        }

        // 8. Reset Core
        if (p.contains("reset core") || p.contains("reset mcu") || p.contains("reboot") ||
            p.contains("restart") || p.contains("रीसेट")) {
            val reply = """
            🔄 [JARVIS: RESETTING ARM CORTEX CORE]
            
            Asserting SYSRESETREQ via AIRCR register, ${getUserSalutation()}. Target MCU restarting...
            """.trimIndent()
            return CommandResult(CommandAction.RESET_CORE, responseText = reply)
        }

        // 9. Read Memory Dump
        if (p.contains("dump") || p.contains("read flash") || p.contains("firmware dump") ||
            p.contains("dump nikaalo") || p.contains("डंप निकालो")) {
            val reply = """
            📥 [JARVIS: INITIATING MEMORY DUMP]
            
            Reading target flash memory pages directly via SWD, ${getUserSalutation()}.
            Binary image will be compiled and exported directly to your Downloads folder.
            """.trimIndent()
            return CommandResult(CommandAction.READ_DUMP, responseText = reply)
        }

        // 10. Multi-Board Batch Mode
        if (p.contains("batch") || p.contains("multiple boards") || p.contains("production batch") ||
            p.contains("बैच मोड") || p.contains("batch mode")) {
            val reply = """
            🏭 [JARVIS: MULTI-BOARD BATCH PROGRAMMING]
            
            Batch production pipeline initialized, ${getUserSalutation()}.
            Continuous hotplug monitoring armed. Each consecutive board plugged into ST-Link will be automatically programmed, verified, and tallied.
            """.trimIndent()
            return CommandResult(CommandAction.BATCH_MODE, responseText = reply)
        }

        // 11. Wireless OTA Flashing
        if (p.contains("ota") || p.contains("wireless") || p.contains("wifi flash") ||
            p.contains("वायरलेस") || p.contains("over the air")) {
            val reply = """
            📶 [JARVIS: WIRELESS OTA MODULE READY]
            
            Opening wireless OTA gateway, ${getUserSalutation()}. Ready to push compiled .bin firmware over Wi-Fi / LAN to the target machine module.
            """.trimIndent()
            return CommandResult(CommandAction.WIRELESS_OTA, responseText = reply)
        }

        // 12. Automated Fault Blackbox Logs
        if (p.contains("blackbox") || p.contains("fault") || p.contains("error log") ||
            p.contains("trip log") || p.contains("ब्लैकबॉक्स") || p.contains("faults")) {
            val reply = """
            🛡️ [JARVIS: AUTOMATED FAULT BLACKBOX]
            
            Retrieving recorded hardware trip and fault blackbox history, ${getUserSalutation()}...
            """.trimIndent()
            return CommandResult(CommandAction.BLACKBOX_LOGS, responseText = reply)
        }

        // 13. Hardware Wiring & Pinouts
        if (p.contains("wiring") || p.contains("pinout") || p.contains("pin") ||
            p.contains("schematic") || p.contains("वायरिंग") || p.contains("diagram")) {
            val reply = """
            🔌 [JARVIS: HARDWARE PINOUTS & SCHEMATICS]
            
            Opening factory pinouts and optocoupler wiring diagrams, ${getUserSalutation()}.
            """.trimIndent()
            return CommandResult(CommandAction.SHOW_WIRING, responseText = reply)
        }

        // 14. Settings & Configurations
        if (p.contains("settings") || p.contains("config") || p.contains("सेटिंग्स") || p.contains("machine settings")) {
            val reply = """
            ⚙️ [JARVIS: MACHINE CONFIGURATION]
            
            Accessing mechanical and electrical parameters for Zipper CNC, ${getUserSalutation()}.
            """.trimIndent()
            return CommandResult(CommandAction.SHOW_SETTINGS, responseText = reply)
        }

        // 15. Auto-Pilot Mode
        if ((p.contains("auto") || p.contains("autopilot")) &&
            (p.contains("on") || p.contains("start") || p.contains("enable") || p.contains("karo") || p.contains("chalu"))) {
            val reply = """
            🤖 [JARVIS: AUTO-PILOT MODE ENGAGED]
            
            Hands-free production mode is armed, ${getUserSalutation()}.
            The moment an ST-Link probe touches an STM32 board, JARVIS will autonomously verify, erase, flash, and test the target.
            """.trimIndent()
            return CommandResult(CommandAction.ENABLE_AUTOPILOT, responseText = reply)
        }

        // 16. Manual Mode
        if (p.contains("manual") || (p.contains("auto") && (p.contains("off") || p.contains("band") || p.contains("stop")))) {
            val reply = """
            ⚙️ [JARVIS: MANUAL CONTROL MODE ENGAGED]
            
            Auto-pilot disarmed, ${getUserSalutation()}. System is awaiting tactile operator commands.
            """.trimIndent()
            return CommandResult(CommandAction.ENABLE_MANUAL, responseText = reply)
        }

        // 17. Target Pitch Recalibration
        if (p.contains("pitch") || p.contains("size")) {
            var extractedPitch = 0f
            if (p.contains("size 3") || p.contains("size #3")) extractedPitch = 2.00f
            else if (p.contains("size 5") || p.contains("size #5")) extractedPitch = 2.50f
            else if (p.contains("size 8") || p.contains("size #8")) extractedPitch = 3.20f
            else if (p.contains("size 10") || p.contains("size #10")) extractedPitch = 4.00f
            else {
                val matcher = Pattern.compile("(\\d+(\\.\\d+)?)\\s*mm").matcher(p)
                if (matcher.find()) {
                    extractedPitch = matcher.group(1)?.toFloatOrNull() ?: 0f
                }
            }

            if (extractedPitch > 0.5f && extractedPitch < 15.0f) {
                val dia = settings.rollerDiameterMm
                val pulsesPerRev = settings.stepperPulsesPerRev
                val circumference = Math.PI * dia
                val pulsesPerTooth = (extractedPitch * pulsesPerRev) / circumference

                val reply = """
                📐 [JARVIS: TARGET PITCH RECALIBRATED]
                
                ${getUserSalutation()}, teeth pitch parameters updated:
                • Target Pitch: %.2f mm
                • Roller Diameter: %.1f mm (Circumference: %.3f mm)
                • Stepper Resolution: %d pulses/rev
                • Stepper Pulses per Tooth: %.4f Pulses
                • TIM2 Prescaler=71, ARR=40 (25.0 µs safe pulse width)
                """.trimIndent().format(Locale.US, extractedPitch, dia, circumference, pulsesPerRev, pulsesPerTooth)
                return CommandResult(CommandAction.SET_PITCH, floatValue = extractedPitch, responseText = reply)
            }
        }

        // 18. Clear Logs
        if (p.contains("clear log") || p.contains("clear logs") || p.contains("clean chat") || p.contains("saaf karo")) {
            val reply = "🧹 Real-time terminal and conversation logs reset, ${getUserSalutation()}."
            return CommandResult(CommandAction.CLEAR_LOGS, responseText = reply)
        }

        return CommandResult(CommandAction.NONE)
    }

    /**
     * Process query through JARVIS:
     * - First checks if the prompt is an actionable conversational app command.
     * - If not a command, queries offline engineering database or Cloud intelligence.
     */
    suspend fun query(prompt: String, mode: AiMode, apiKey: String, settings: SettingsManager): String = withContext(Dispatchers.IO) {
        val userMsgId = "msg_${System.currentTimeMillis()}_u"
        val assistantMsgId = "msg_${System.currentTimeMillis()}_a"
        val timestamp = System.currentTimeMillis()

        // 1. Check if user is issuing an actionable command
        val cmd = parseConversationalCommand(prompt, settings)
        if (cmd.action != CommandAction.NONE) {
            val userMsg = ChatMessage(userMsgId, timestamp, mode, "user", prompt, SyncStatus.OFFLINE_RESOLVED)
            val assistantMsg = ChatMessage(assistantMsgId, System.currentTimeMillis(), mode, "assistant", cmd.responseText, SyncStatus.OFFLINE_RESOLVED)
            synchronized(this@UniversalAiEngine) {
                memoryList.add(userMsg)
                memoryList.add(assistantMsg)
                saveHistoryToDisk()
            }
            return@withContext cmd.responseText
        }

        // 2. Normal Query Processing (Q&A, Technical Explanation, Code, Translation)
        val userMsg = ChatMessage(userMsgId, timestamp, mode, "user", prompt, SyncStatus.OFFLINE_RESOLVED)
        synchronized(this@UniversalAiEngine) {
            memoryList.add(userMsg)
            saveHistoryToDisk()
        }

        val online = isOnline() && apiKey.isNotBlank()

        if (online) {
            try {
                val cloudResponse = callCloudAssistantApi(prompt, mode, apiKey)
                val assistantMsg = ChatMessage(
                    assistantMsgId,
                    System.currentTimeMillis(),
                    mode,
                    "assistant",
                    cloudResponse,
                    SyncStatus.SYNCED_ONLINE
                )
                synchronized(this@UniversalAiEngine) {
                    memoryList.add(assistantMsg)
                    saveHistoryToDisk()
                }
                return@withContext cloudResponse
            } catch (e: Exception) {
                val fallbackResponse = resolveLocalOfflineQuery(prompt, mode)
                val assistantMsg = ChatMessage(
                    assistantMsgId,
                    System.currentTimeMillis(),
                    mode,
                    "assistant",
                    fallbackResponse,
                    SyncStatus.PENDING_CLOUD_SYNC
                )
                synchronized(this@UniversalAiEngine) {
                    memoryList.add(assistantMsg)
                    saveHistoryToDisk()
                }
                return@withContext fallbackResponse
            }
        } else {
            val localResponse = resolveLocalOfflineQuery(prompt, mode)
            val assistantMsg = ChatMessage(
                assistantMsgId,
                System.currentTimeMillis(),
                mode,
                "assistant",
                localResponse,
                if (isOnline()) SyncStatus.OFFLINE_RESOLVED else SyncStatus.PENDING_CLOUD_SYNC
            )
            synchronized(this@UniversalAiEngine) {
                memoryList.add(assistantMsg)
                saveHistoryToDisk()
            }
            return@withContext localResponse
        }
    }

    // Interactive Confirmation State
    @Volatile
    private var pendingConfirmation: String? = null

    
    private fun getUserSalutation(): String {
        return try {
            val name = SettingsManager.getInstance(context).engineerName.trim()
            if (name.isNotBlank()) "$name sir" else "Sir"
        } catch (e: Exception) {
            "Sir"
        }
    }

    private fun resolveGreeting(q: String): String? {
        val isGreeting = q.matches(Regex("^(hell0+|helo+|hlo+|hllo+|hello+|hi+|hii+|hy+|hyy+|hey+|namaste+|pranam+|ram ram|kem cho|good morning|good afternoon|good evening).*", RegexOption.IGNORE_CASE))
        if (isGreeting) {
            val s = getUserSalutation()
            val list = listOf(
                "Hello $s! JARVIS at your service. All core systems normal hain.",
                "Greetings $s! Flasher pipeline aur offline diagnostics standby par hain. Bataiye kya command execute karni hai?",
                "Aapka swagat hai $s! Sabhi sensors aur hardware interfaces ready hain. Aaj kya test ya flash karna hai?",
                "Ji $s! JARVIS fully operational hai. Kis module ya parameter par kaam karein?"
            )
            return list.random()
        }
        return null
    }

    private fun resolveMathAndCalculations(q: String): String? {
        val s = getUserSalutation()
        // A. Pitch & Pulses Calculation
        if ((q.contains("pitch") || q.contains("pulse") || q.contains("pulses")) && 
            (q.contains("calc") || q.contains("nikal") || q.contains("batao") || q.contains("formula") || q.contains("kitna") || q.contains("mm") || q.contains("per tooth"))) {
            
            val pitchMatch = Regex("(\\d+(?:\\.\\d+)?)\\s*(?:mm)?").find(q)
            var pitch = pitchMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 2.50
            if (q.contains("size 3") || q.contains("size #3")) pitch = 2.00
            else if (q.contains("size 4") || q.contains("size #4")) pitch = 2.25
            else if (q.contains("size 5") || q.contains("size #5")) pitch = 2.50
            else if (q.contains("size 7") || q.contains("size #7")) pitch = 2.80
            else if (q.contains("size 8") || q.contains("size #8")) pitch = 3.00
            else if (q.contains("size 10") || q.contains("size #10")) pitch = 4.00

            val rollerDia = 45.0
            val driverSteps = 6400.0

            val exactPulses = (driverSteps * pitch) / (Math.PI * rollerDia)
            val intPulses = exactPulses.toLong()
            val fraction = exactPulses - intPulses
            val accumulator = (fraction * 1000000.0).toLong()

            val pStr = String.format(java.util.Locale.US, "%.2f", pitch)
            val pExactStr = String.format(java.util.Locale.US, "%.6f", exactPulses)

            return """
            📐 [CNC TEETH-TO-TEETH PITCH MATH ENGINE] ($s)
            
            • Input Target Pitch: $pStr mm
            • Roller Diameter: 45.0 mm (Circumference: 141.37 mm)
            • Stepper Driver Resolution: 6400 pulses/rev (DIP: SW5 ON, SW6 ON, SW7 OFF, SW8 ON)
            
            🔢 Mathematical Derivation:
            Pulses = (Resolution × Pitch) / (π × Roller_Dia)
            Pulses = (6400 × $pStr) / 141.371669
            = $pExactStr Pulses per Tooth
            
            ⚙️ Firmware V16.5.1 Bresenham Allocation:
            • Integer Step Burst: $intPulses pulses
            • Fixed Micro-Accumulator: $accumulator / 1,000,000
            • Cumulative Drift: < 0.025 mm per 1.6 km of continuous zipper feed!
            """.trimIndent()
        }

        // B. PC817 Optocoupler Resistor Calculation
        if ((q.contains("pc817") || q.contains("optocoupler") || q.contains("isolation")) && 
            (q.contains("resistor") || q.contains("resistance") || q.contains("ohm") || q.contains("kilo") || q.contains("v") || q.contains("voltage") || q.contains("calc"))) {
            
            var vIn = 15.0
            if (q.contains("24v") || q.contains("24 v") || q.contains("24")) vIn = 24.0
            else if (q.contains("12v") || q.contains("12 v") || q.contains("12")) vIn = 12.0
            else if (q.contains("5v") || q.contains("5 v") || q.contains("5")) vIn = 5.0
            
            val vF = 1.2
            val iF = 0.010
            val rExact = (vIn - vF) / iF
            val pWatt = (vIn - vF) * iF
            val rStandard = when (vIn) {
                24.0 -> "2.2kΩ or 2.4kΩ (1/2 Watt, 1% Metal Film)"
                15.0 -> "1.3kΩ or 1.5kΩ (1/4 Watt, 1% Metal Film)"
                12.0 -> "1.0kΩ or 1.2kΩ (1/4 Watt)"
                5.0 -> "330Ω or 390Ω (1/4 Watt)"
                else -> "${(rExact/1000).toInt()}kΩ (1/2 Watt)"
            }
            val pWattStr = String.format(java.util.Locale.US, "%.3f", pWatt)
            val vInt = vIn.toInt()

            return """
            ⚡ [PC817 OPTOCOUPLER SIZING & CIRCUIT MATH] ($s)
            
            • Input Sensor Supply: ${vInt}V DC
            • PC817 IR LED Drop (V_F): 1.2V
            • Target Saturated Current (I_F): 10mA (0.010A)
            
            🔢 Resistor Calculation:
            R = (V_in - V_F) / I_F
            R = (${vInt}V - 1.2V) / 0.010A = ${rExact.toInt()} Ω
            Power Dissipation = (${vInt}V - 1.2V) × 0.010A = ${pWattStr}W
            
            ✅ Recommended Standard Value:
            • Use $rStandard
            • Pin Connection: Anode (Pin 1) to +${vInt}V via series resistor; Cathode (Pin 2) to NPN Sensor collector wire. Emitter (Pin 3) to Clean MCU GND; Collector (Pin 4) to STM32 PA0 with 3.3kΩ pull-up to 3.3V.
            """.trimIndent()
        }

        // C. Stepper Speed & Pulse Frequency Calculation
        if (q.contains("rpm") && (q.contains("freq") || q.contains("khz") || q.contains("speed") || q.contains("rate"))) {
            val rpmMatch = Regex("(\\d+)\\s*rpm").find(q)
            val rpm = rpmMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 2850.0
            val pulsesPerTooth = 113.18
            val freqHz = (rpm / 60.0) * pulsesPerTooth
            val freqKhz = freqHz / 1000.0
            val fHzStr = String.format(java.util.Locale.US, "%.2f", freqHz)
            val fKhzStr = String.format(java.util.Locale.US, "%.2f", freqKhz)
            val rpsStr = String.format(java.util.Locale.US, "%.1f", rpm/60.0)

            return """
            📊 [CNC SHAFT RPM & STEPPER PULSE FREQUENCY] ($s)
            
            • Machine Main Shaft Speed: ${rpm.toInt()} RPM ($rpsStr rev/sec)
            • Average Pulse Burst per Tooth: 113.18 pulses (Size #5 baseline)
            
            🔢 Frequency Calculation:
            F = (RPM / 60) × Pulses_Per_Tooth
            F = (${rpm.toInt()} / 60) × 113.18 = $fHzStr Hz (~$fKhzStr kHz)
            
            ⏱️ Hardware Timer Verification:
            STM32 TIM2_CH2 generates 13.8ns single-cycle atomic pulses with 0% CPU load, easily handling up to 1,000 kHz without jitter!
            """.trimIndent()
        }

        return null
    }

    private fun resolveKnowledgeBase(q: String): String? {
        val s = getUserSalutation()
        if (q.contains("dip switch") || q.contains("dm542 dip") || q.contains("microstepping setting") || (q.contains("dm542") && q.contains("switch"))) {
            return """
            ⚙️ [LEADSHINE DM542 / DM556 DIP SWITCH MATRIX] ($s)
            
            1. Current Configuration (SW1, SW2, SW3):
            • 2.37A RMS / 3.3A Peak (Standard NEMA 23): SW1: OFF, SW2: OFF, SW3: ON
            • 3.00A RMS / 4.2A Peak (High Torque): SW1: OFF, SW2: OFF, SW3: OFF
            
            2. Standstill Half-Current (SW4):
            • SW4 OFF: Half current on idle (Recommended: Reduces motor heat by 50%)
            • SW4 ON: Full holding current active
            
            3. Microstepping Resolution (SW5, SW6, SW7, SW8):
            • 6400 Steps/Rev (Zipper CNC Default): SW5: ON, SW6: ON, SW7: OFF, SW8: ON
            • 3200 Steps/Rev: SW5: OFF, SW6: OFF, SW7: ON, SW8: ON
            • 1600 Steps/Rev: SW5: ON, SW6: OFF, SW7: ON, SW8: ON
            • 800 Steps/Rev: SW5: OFF, SW6: ON, SW7: ON, SW8: ON
            """.trimIndent()
        }

        if (q.contains("target not halting") || q.contains("cannot halt") || q.contains("halt failed") || q.contains("0x1ba01477")) {
            return """
            🔍 [ST-LINK SWD CORE DIAGNOSTIC: TARGET NOT HALTING] ($s)
            
            • Error Code: CoreSight DAP SWD Core Hold Failure
            • Root Cause: STM32F103 core is either in deep WFI sleep, NRST line is floating/pulled down, or SWD pins (PA13/PA14) were remapped to GPIO in user firmware.
            
            🛠️ Industrial Resolution Procedure:
            1. Connect Under Reset: Hold NRST pin to GND while plugging in ST-Link, then release as Flasher starts.
            2. Frequency Fallback: Switch SWD Clock from 4.0MHz to 500kHz in Flasher Settings tab.
            3. Supply Voltage Check: Ensure 3.3V on Blue Pill pin 18 is between 3.25V and 3.35V (Under-voltage < 2.9V prevents Flash write controller from unlocking).
            4. Hardware Mass Erase: If firmware locked Option Bytes, perform ST-Link Mass Erase via menu.
            """.trimIndent()
        }

        return null
    }

    private fun resolveLocalOfflineQuery(prompt: String, mode: AiMode): String {
        val q = prompt.lowercase(Locale.US).trim()

        // -3. Typo-Tolerant & Dynamic Greeting Engine
        val greeting = resolveGreeting(q)
        if (greeting != null) return greeting

        // -2. Real-Time Math & Formula Solver Engine
        val mathSolution = resolveMathAndCalculations(q)
        if (mathSolution != null) return mathSolution

        // -1.5. Embedded Industrial Knowledge Base Lookup
        val kbInfo = resolveKnowledgeBase(q)
        if (kbInfo != null) return kbInfo

        // -1. STM32 Zip Puller / Zipper CNC Device Architecture & Engineering Knowledge
        val zipPullerInfo = resolveZipPullerDeviceArchitecture(q)
        if (zipPullerInfo != null) return zipPullerInfo

        // 0. Handle Multi-turn Confirmation (User responding to a previous confirmation question)
        if (pendingConfirmation != null) {
            val action = pendingConfirmation
            pendingConfirmation = null
            if (q.contains("yes") || q.contains("haan") || q.contains("confirm") || q.contains("karo") ||
                q.contains("thik") || q.contains("sure") || q.contains("chalao") || q.contains("proceed")) {
                return when (action) {
                    "ERASE_CHIP" -> "⚠️ Confirmed: STM32 Full Chip Mass Erase command armed. Connect ST-Link V2 and tap ERASE FLASH in flasher window."
                    "FACTORY_RESET" -> "⚠️ Confirmed: Factory defaults restored. Shift counters and sensor calibrations reset."
                    else -> "✅ Action confirmed and executed, ${getUserSalutation()}."
                }
            } else if (q.contains("no") || q.contains("nahi") || q.contains("cancel") || q.contains("mat karo") || q.contains("stop")) {
                return "❌ Action cancelled, ${getUserSalutation()}. Chip memory aur system parameters safe hain."
            }
        }

        // 1. High-Stakes Action Requiring Confirmation Question
        if (q.contains("chip erase") || q.contains("full erase") || q.contains("pura erase") ||
            q.contains("format chip") || q.contains("erase chip") || q.contains("mass erase")) {
            pendingConfirmation = "ERASE_CHIP"
            return """
            ⚠️ DHYAAN DIJIYE (Confirmation Required):
            ${getUserSalutation()}, aap STM32 chip ka full memory erase / wipe karne ki baat kar rahe hain. Isse chip par load kiya gaya pura firmware permanently delete ho jayega!
            
            Kya aap sure hain?
            • Confirm karne ke liye: 'CONFIRM' ya 'HAAN' likhiye.
            • Cancel karne ke liye: 'CANCEL' ya 'NAHI' boliye.
            """.trimIndent()
        }

        // 2. Disambiguation & Clarifying Questions when confused / ambiguous
        val clarification = checkAndResolveClarification(q)
        if (clarification != null) return clarification

        // 3. Basic & Industrial Electronics Knowledge Engine
        val elec = resolveElectronicsKnowledge(q)
        if (elec != null) return elec

        return when (mode) {
            AiMode.INDUSTRIAL_JARVIS, AiMode.INDUSTRIAL_COPILOT -> resolveIndustrialOffline(q, prompt)
            AiMode.CODE_JARVIS, AiMode.CODE_WIZARD -> resolveCodeWizardOffline(q, prompt)
            AiMode.SOP_JARVIS, AiMode.TRANSLATOR_SOP -> resolveTranslatorOffline(q, prompt)
            AiMode.UNIVERSAL_JARVIS, AiMode.UNIVERSAL_ASSISTANT -> resolveGeneralAssistantOffline(q, prompt)
        }
    }

    private fun checkAndResolveClarification(q: String): String? {
        // A. Ambiguous Sensor query (user just says "sensor" or "sensor issue")
        if (q in listOf("sensor", "sensor problem", "sensor issue", "sensor check", "sensor ka batao", "sensor nahi chal raha", "sensor kharab hai", "sensor me problem")) {
            return """
            ${getUserSalutation()}, machine me 3 primary sensors hain. Aap specific kis sensor ke baare me pooch rahe hain?
            1. 📷 Cam Proximity Sensor (Pin PA0 - 15V NPN)
            2. 📏 Tape Runout Sensor (Pin PA3 - 15V NPN)
            3. 🧲 Coil / Slider Sensor (Pin PB0 - 15V NPN)
            
            Kripya batayein: Kya sensor ki PC817 optocoupler wiring check karni hai, ya live signal status test karna hai?
            """.trimIndent()
        }

        // B. Ambiguous Motor query
        if (q in listOf("motor", "motor problem", "motor issue", "motor check", "motor nahi chal rahi", "motor ghum nahi rahi", "motor band hai", "motor me dikkat")) {
            return """
            ${getUserSalutation()}, kripya clarify karein:
            1. ⚙️ Main Shaft Induction Motor (2,850 RPM AC drive / Inverter)?
            2. 🔄 Stepper Feed Motor (TIM2 PA1 Hardware Timer Pulse Train)?
            
            Motor me specific kya symptom aa raha hai — bilkul nahi ghum rahi, vibrate ho rahi hai, ya speed fluctuate ho rahi hai?
            """.trimIndent()
        }

        // C. Ambiguous Flashing Error
        if (q in listOf("flash nahi ho raha", "error aa gaya", "fail ho gaya", "program nahi ho raha", "flashing fail", "problem aa rahi hai", "code nahi ja raha")) {
            return """
            Flashing issue ko diagnose karne ke liye kripya yeh 3 points confirm karein, ${getUserSalutation()}:
            1. Kya ST-Link V2 ka LED light steady glow kar raha hai?
            2. App ke top header par status 'Connected' dikh raha hai ya 'Disconnected'?
            3. Terminal log me kya error message aa raha hai (jaise 'SWD Target Not Found' ya 'Chip Write-Protected')?
            
            Aap ye details batayein, main turant exact solution deta hoon!
            """.trimIndent()
        }

        // D. Ambiguous Voltage / Power drop
        if (q in listOf("voltage drop", "voltage issue", "power issue", "power supply problem", "voltage problem", "supply drop")) {
            return """
            Voltage issue ko solve karne ke liye kripya clarify karein:
            1. +24V SMPS Industrial Main Power Rail par drop ho raha hai?
            2. 5V Logic Rail (Buck Converter / 7805) par drop ho raha hai?
            3. Ya STM32 ka clean 3.3V power rail drop ho raha hai?
            
            Multimeter se probe karne par kitna voltage reading aa raha hai?
            """.trimIndent()
        }

        // E. User confused or seeking step-by-step guidance
        if (q.contains("confuse") || q.contains("samajh nahi aa raha") || q.contains("samajh nahi aaya") ||
            q.contains("kaise karein") || q.contains("kya karein") || q.contains("kaha se shuru") || q.contains("guide karo")) {
            return """
            Fikar mat kijiye ${getUserSalutation()}! Main step-by-step aapko guide karta hoon.
            Aap kis step par hain:
            1. ⚡ STM32 Blue Pill ko firmware se flash karna hai?
            2. 🔍 ST-Link ko USB OTG se phone se connect karna hai?
            3. 📐 PC817 optocoupler aur sensor wiring connect karni hai?
            4. 📊 CNC pitch pulses calculate karne hain?
            
            Aap number (1, 2, 3, ya 4) ya topic likh dijiye, main wahi se explain karta hoon!
            """.trimIndent()
        }

        return null
    }

        private fun resolveZipPullerDeviceArchitecture(q: String): String? {
        // Check if query is about the STM32 Zip Puller / Zipper CNC device architecture or engineering details
        val isZipPullerQuery = q.contains("zip puller") || q.contains("zipper") || q.contains("puller") ||
                q.contains("device architecture") || q.contains("engineering detail") ||
                q.contains("machine architecture") || q.contains("cnc detail") ||
                q.contains("v16.5") || q.contains("machine detail") || q.contains("device ka detail")

        if (!isZipPullerQuery) return null

        // Specific sub-topic queries:
        // 1. Full Architecture / Engineering Overview
        if (q.contains("architecture") || q.contains("detail") || q.contains("overview") || q.contains("kya hai") || q.contains("working")) {
            return """
            🏭 [STM32 Zip Puller & Zipper CNC: Complete Engineering Architecture]
            
            ${getUserSalutation()}, yahan is machine ka complete system blueprint hai:
            
            1. Core Controller & Processor:
               • MCU: STM32F103C8T6 (ARM Cortex-M3 32-bit, 72 MHz Clock, 64KB Flash, 20KB SRAM).
               • Firmware: V16.5.1 Production (Autonomous Hardware Timer 2 Edition).
               • Operating Speed: Up to 2,850 - 3,000 RPM main shaft.
            
            2. High-Speed Real-Time Motion Control:
               • Hardware Timer (PA1 / TIM2_CH2): Generates hardware PWM pulse bursts with 0.0% CPU jitter.
               • Stepper Resolution: 6400 pulses/rev (1/32 Microstepping on DM542 driver).
               • Direction Line (PA2): High = Forward tape feed, Low = Reverse.
               • Feed Window: Synchronized during 160° feed angle of main cam rotation.
            
            3. Galvanic Isolated Sensing (PC817 Optocouplers):
               • PA0 (EXTI0 Interrupt): Cam Proximity Sensor (15V NPN) for main shaft sync.
               • PA3: Tape Runout Sensor (15V NPN) - detects tape breakage.
               • PB0: Coil / Slider Sensor (15V NPN) - detects zipper slider blockage.
            
            4. Safety & Actuation:
               • PB1 (Active-LOW Relay): E-Stop safety cut-off (< 5ms response time to trip main motor inverter).
            
            5. Teeth Pitch Calibration Math (45.0 mm Roller):
               • Size #3 (2.00 mm): 90.54 Pulses / Tooth
               • Size #5 (2.50 mm): 113.18 Pulses / Tooth (113 integer + 0.1768 Bresenham accumulator)
               • Size #8 (3.20 mm): 144.87 Pulses / Tooth
               • Size #10 (4.00 mm): 181.08 Pulses / Tooth
            
            Aap iske kisi bhi specific part (wiring, timers, sensor circuit, pitch formula) ke baare me detail me pooch sakte hain!
            """.trimIndent()
        }

        // 2. Pinout & GPIO Allocation
        if (q.contains("pinout") || q.contains("pin") || q.contains("gpio") || q.contains("wiring")) {
            return """
            📐 [STM32 Zip Puller Controller: Complete GPIO Mapping]
            
            ${getUserSalutation()}, Blue Pill board par exact pin assignments:
            • PA0 (Pin 10): Cam Sensor Input (15V NPN via PC817 optocoupler, EXTI0).
            • PA1 (Pin 11): Stepper Pulse Train (TIM2_CH2 Hardware Timer Output, 25µs pulse width).
            • PA2 (Pin 12): Stepper Direction Output (DIR signal to DM542 driver).
            • PA3 (Pin 13): Tape Optical/Proximity Sensor (PC817 isolated).
            • PB0 (Pin 18): Coil / Slider Feed Sensor (PC817 isolated).
            • PB1 (Pin 19): Emergency Stop Safety Relay (Active-LOW, triggers on fault).
            • PA9 / PA10: USART1 Serial Debug Telemetry (115200 Baud).
            • PB6 / PB7: I2C1 Bus for 16x2 / 20x4 LCD Display (with 4.7kΩ pull-up resistors).
            • PA13 / PA14: SWDIO & SWCLK (ST-Link V2 programming & debug interface).
            """.trimIndent()
        }

        // 3. Firmware V16.5.1 Autonomous Timer 2 Features
        if (q.contains("firmware") || q.contains("timer") || q.contains("tim2") || q.contains("code")) {
            return """
            ⚡ [V16.5.1 Autonomous Hardware Timer 2 Firmware Architecture]
            
            ${getUserSalutation()}, V16.5.1 firmware ka internal working principle:
            
            • Why Hardware Timer 2 (TIM2):
              Software loop ya simple delay se stepper pulse generate karne par CPU interrupts (sensor reads, LCD refresh) ke karan micro-jitter aata hai, jisse zipper pitch me drift ho jata tha.
              V16.5.1 me TIM2 Channel 2 (PA1) hardware timer counter direct silicon clock se pulses nikaalta hai — 0.0% jitter guarantee!
            • Cam Sync State Machine:
              Main shaft ka Cam jab PA0 sensor ko trigger karta hai, EXTI interrupt timer ko activate karta hai. Exactly 160° angle ke andar required pulses shoot ho jaati hain.
            • Anti-Bricking & Watchdog:
              Independent Watchdog (IWDG) enabled hai. Agar motor jam hone se loop fas jaye, to MCU safe state me trip hokar E-Stop relay disconnect kar deta hai.
            """.trimIndent()
        }

        return null
    }

private fun resolveElectronicsKnowledge(q: String): String? {
        // 1. Resistors & Pull-Up / Pull-Down
        if (q.contains("resistor") || q.contains("resistance") || q.contains("pull up") ||
            q.contains("pull down") || q.contains("color code") || q.contains("ohm")) {
            return """
            ⚡ [Resistors & Circuit Biasing]
            
            ${getUserSalutation()}, resistors circuit me current control aur voltage divide karte hain:
            
            • Ohm's Law: V = I × R (Current I = V / R).
            • Pull-Up / Pull-Down Resistors:
              - MCU ke GPIO pin ko floating state se bachane ke liye lagate hain.
              - Standard Value: 4.7kΩ se 10kΩ.
              - Pull-Up pin ko default HIGH (+3.3V) rakhta hai jab tak switch press na ho.
              - Pull-Down pin ko default LOW (GND) rakhta hai.
            • Color Code Mnemonic (BBROYGBVGW):
              Black(0), Brown(1), Red(2), Orange(3), Yellow(4), Green(5), Blue(6), Violet(7), Grey(8), White(9).
            • Power Rating: 1/4W, 1/2W, 1W (Power P = I² × R. Agar limit se zyada wattage ho to resistor overheat ho jayega).
            """.trimIndent()
        }

        // 2. Capacitors & Decoupling / Filtering
        if (q.contains("capacitor") || q.contains("condenser") || q.contains("decoupling") ||
            q.contains("bypass") || q.contains("filter cap") || q.contains("microfarad") || q.contains("farad")) {
            return """
            ⚡ [Capacitors: Filtering & Decoupling]
            
            ${getUserSalutation()}, capacitors electric charge store karte hain, DC block aur AC pass karte hain:
            
            • Decoupling / Bypass Capacitor (100nF / 0.1µF Ceramic, Code 104):
              - MCU (STM32/ESP32) ke har VDD aur GND pin ke bilkul paas lagana zaroori hai.
              - High-frequency switching noise aur voltage dips ko ground me bypass karta hai taaki MCU freeze/reset na ho.
            • Bulk Filter Capacitors (Electrolytic, 100µF - 1000µF):
              - Power supply (SMPS/Adapter) ke output par voltage ripples ko smooth karne ke liye.
              - Dhyaan rahe: Electrolytic capacitors Polarized hote hain (+ aur - ka sahi connection zaroori hai).
            """.trimIndent()
        }

        // 3. Diodes, Rectification & Flyback Protection
        if (q.contains("diode") || q.contains("flyback") || q.contains("freewheeling") ||
            q.contains("zener") || q.contains("schottky") || q.contains("1n4007") || q.contains("1n4148")) {
            return """
            ⚡ [Diodes & Flyback Protection]
            
            ${getUserSalutation()}, diode ek one-way electrical valve hai (Anode to Cathode):
            
            • 1N4007 (General Rectifier): 1 Amp, 1000V, forward drop ~0.7V. AC to DC bridge rectifier me use hota hai.
            • 1N4148 (High-Speed Diode): Fast signal switching ke liye (nanoseconds response).
            • Schottky Diode (e.g. SS14, SS34): Ultra-fast, low forward drop (~0.3V), reverse polarity protection aur buck converters me use hota hai.
            • Zener Diode: Reverse breakdown par fix voltage regulate karta hai (e.g. 3.3V, 5.1V voltage clamping).
            • Flyback / Freewheeling Diode (Crucial!):
              - Relay, solenoid, ya motor coil ke parallel me REVERSE direction me lagaya jata hai.
              - Coil turn-off hote waqt high voltage spike (Inductive Kickback: V = -L di/dt) banata hai. Flyback diode is spike ko absorb karke driver transistor/MOSFET ko jalne se bachata hai!
            """.trimIndent()
        }

        // 4. Transistors & MOSFETs
        if (q.contains("mosfet") || q.contains("transistor") || q.contains("bjt") ||
            q.contains("bc547") || q.contains("2n2222") || q.contains("irfz44") || q.contains("gate drive")) {
            return """
            ⚡ [Transistors (BJT) vs MOSFETs]
            
            ${getUserSalutation()}, transistors electronic switches aur amplifiers hote hain:
            
            • BJT (Current Controlled - e.g. BC547, 2N2222 NPN):
              - Base me small current dene se Collector-to-Emitter current flow hota hai.
              - Relay coils, LEDs, aur small load switching ke liye perfect.
            • MOSFET (Voltage Controlled - e.g. IRFZ44N, IRLZ44N, 2N7002):
              - Gate par voltage dene se Drain-to-Source conduct karta hai (Almost zero gate current).
              - Heavy loads, DC motors, aur high-frequency PWM switching ke liye best.
            • Engineering Tip:
              - Gate par hamesha 10kΩ pulldown resistor lagayein taaki MCU boot ke time floating gate se MOSFET automatically trigger na ho.
              - 3.3V MCU se direct chalane ke liye Logic-Level MOSFET (e.g. IRLZ44N) use karein!
            """.trimIndent()
        }

        // 5. Relays & Contactors
        if (q.contains("relay") || q.contains("contactor") || q.contains("solenoid") || q.contains("no nc")) {
            return """
            ⚡ [Relays & Contactors: Industrial Switching]
            
            ${getUserSalutation()}, relay ek electromechanical switch hai jo complete galvanic isolation deta hai:
            
            • Terminals:
              - Coil: 5V / 12V / 24V DC.
              - COM (Common): Main input line.
              - NO (Normally Open): Normal state me disconnected, relay ON hone par connect hota hai.
              - NC (Normally Closed): Normal state me connected, relay ON hone par disconnect hota hai.
            • Driving Rule:
              - MCU ka GPIO direct relay coil ko nahi chala sakta (GPIO max current ~20mA, relay coil needs 70-100mA).
              - Hamesha NPN Transistor (BC547) ya Optocoupler driver + 1N4007 flyback diode use karein.
            """.trimIndent()
        }

        // 6. Power Regulators & Converters
        if (q.contains("7805") || q.contains("ams1117") || q.contains("regulator") ||
            q.contains("buck") || q.contains("converter") || q.contains("lm2596") || q.contains("smps")) {
            return """
            ⚡ [Power Supplies: Linear Regulators vs Buck Converters]
            
            ${getUserSalutation()}, power supply design guidelines:
            
            • Linear Regulators (LM7805, AMS1117-3.3):
              - Input aur output ke beech ka excess voltage HEAT me dissipate hota hai: P = (Vin - Vout) × I.
              - 24V se 5V banane ke liye 7805 mat lagaiye (bahut garam hoga).
              - 5V se clean 3.3V banane ke liye AMS1117-3.3 LDO best hai.
            • Switching Regulators (Buck Converter - e.g. LM2596, MP1584, XL4015):
              - 85% se 95% efficiency ke sath high voltage (24V) ko 5V/3.3V me convert karte hain with zero heat!
              - Industrial factory floor par hamesha Buck Converter use karein.
            """.trimIndent()
        }

        // 7. Industrial Proximity Sensors (NPN vs PNP)
        if (q.contains("proximity") || q.contains("inductive") || q.contains("npn sensor") ||
            q.contains("pnp sensor") || q.contains("sensor wiring")) {
            return """
            ⚡ [Industrial 3-Wire Proximity Sensors (NPN vs PNP)]
            
            ${getUserSalutation()}, standard industrial wire color coding:
            • Brown Wire: +12V to +24V DC Power Supply.
            • Blue Wire: 0V / GND Power Supply.
            • Black Wire: Output Signal.
            
            • NPN Sensor (Sinking Output):
              - Metal detect hone par Black wire GND (0V) se connect hota hai.
              - Microcontroller (STM32) interfacing ke liye PC817 Optocoupler ke Cathode se connect karein.
            • PNP Sensor (Sourcing Output):
              - Metal detect hone par Black wire +24V supply deta hai.
            """.trimIndent()
        }

        // 8. Communication Buses (I2C, SPI, UART, RS485, CAN)
        if (q.contains("i2c") || q.contains("spi") || q.contains("uart") ||
            q.contains("rs485") || q.contains("can bus") || q.contains("serial comm")) {
            return """
            ⚡ [Embedded Communication Protocols]
            
            ${getUserSalutation()}, embedded systems communication comparison:
            
            • UART: 2 wires (TX, RX + GND), asynchronous, point-to-point. TX connects to RX.
            • I2C: 2 wires (SDA Data, SCL Clock), synchronous, multi-device addressing. Both lines require 4.7kΩ pull-up resistors to 3.3V/5V.
            • SPI: 4 wires (MOSI, MISO, SCK, CS), high-speed synchronous (10-50MHz), full duplex.
            • RS485 (MAX485): Differential 2-wire (A & B), industrial long range (up to 1.2 km) with high electrical noise immunity. 120Ω termination resistor at both ends is required.
            • CAN Bus: Fault-tolerant automotive & industrial protocol, multi-master with hardware arbitration.
            """.trimIndent()
        }

        // 9. Multimeter & Hardware Troubleshooting
        if (q.contains("multimeter") || q.contains("short circuit") || q.contains("continuity") ||
            q.contains("troubleshoot") || q.contains("fault check")) {
            return """
            ⚡ [Multimeter & PCB Troubleshooting Guide]
            
            ${getUserSalutation()}, board test karne ka standard protocol:
            
            1. Power OFF Continuity Test (Beep Mode):
               - Power dene se PEHLE VCC aur GND ke beech continuity check karein.
               - Agar multimeter beep kare, to circuit me SHORT CIRCUIT hai! Never turn ON power!
            2. Voltage Rail Check:
               - Board ko power dekar multimeter DC 20V range me set karein.
               - +24V, +5V, aur +3.3V rails ko GND probe se measure karein.
            3. Cold Solder Joint / Trace Break:
               - Suspect pin se microcontroller pin tak continuity check karein.
            """.trimIndent()
        }

        // 10. Grounding & Noise Suppression
        if (q.contains("star ground") || q.contains("ground loop") || q.contains("grounding") ||
            q.contains("noise") || q.contains("interference") || q.contains("shield")) {
            return """
            ⚡ [Industrial Star Grounding & Noise Suppression]
            
            ${getUserSalutation()}, electrical noise aur false triggers se bachne ke golden rules:
            
            • Single-Point Star Grounding:
              - Motor drivers ka heavy return ground, 24V SMPS ground, aur clean MCU digital ground ko ek single common point par jodiye.
              - Never daisy-chain high current motor ground through the microcontroller PCB!
            • Shielded Cables:
              - Proximity sensor aur encoder ke wires shielded twisted-pair hone chahiye.
              - Shield wire ko sirf CONTROL PANEL side ke Earth ground se jodein (Dono taraf mat jodiye taaki ground loop na bane).
            """.trimIndent()
        }

        // 11. Basic Electronics Overview
        if (q.contains("basic electronics") || q.contains("electronics kya") || q.contains("components")) {
            return """
            ⚡ [Fundamentals of Basic Electronics]
            
            ${getUserSalutation()}, electronics ke core building blocks:
            
            1. Passive Components:
               • Resistors: Current limiting & voltage division (Ohm's Law: V = I × R).
               • Capacitors: Energy storage, power smoothing & high-frequency noise filtering (100nF decoupling).
               • Inductors: Magnetic energy storage, choke coils & filtering.
            2. Active Components:
               • Diodes: One-way valve (1N4007, Schottky, Flyback diodes).
               • Transistors & MOSFETs: Electronic switches (BC547 NPN, IRFZ44N N-Channel).
               • Optocouplers: Optical isolation (PC817) between 24V industrial and 3.3V MCU.
            3. Microcontrollers:
               • STM32 (ARM Cortex-M3/M4): High speed, hardware timers, 3.3V logic.
            
            Aap kisi bhi specific component ya circuit ke baare me pooch sakte hain!
            """.trimIndent()
        }

        return null
    }

    private var replyCounter = 0

    private val greetingReplies = listOf(
        "Namaste! Main bilkul theek hoon. Aap bataiye, aaj programming ya factory floor par kya chal raha hai?",
        "Hello! JARVIS active aur ready hai. Bataiye, aaj kis board ya module par kaam karna hai?",
        "Hey! Sab systems normal hain. Firmware flash karni hai, wiring dekhni hai ya status check karna hai?",
        "Namaste! Main yahan hoon. Aaj STM32 ya CNC machine par kya testing karni hai?"
    )

    private val statusChatReplies = listOf(
        "Yahan sab first class chal raha hai! USB bus ready hai, hardware connect hote hi bataiyega.",
        "Sab badhiya! Flasher module, wiring schematics aur telemetry engines stand-by par hain. Aap sunaiye, kya plan hai?",
        "All systems running smoothly! STM32 SWD routines aur CNC calculations ready hain. Kis cheez par kaam shuru karein?"
    )

    private val gratitudeReplies = listOf(
        "Aapka swagat hai! Anytime, main hamesha yahan available hoon.",
        "Shukriya! Aapke sath kaam karke hamesha achha lagta hai. Agla step kya karein?",
        "Most welcome! Kisi bhi technical problem ya circuit me doubt ho, bas mujhe bataiyega.",
        "Glad to help! Machine ya code me aur kuch check karna ho to bataiye."
    )

    private val affirmationReplies = listOf(
        "Theek hai, done! Jab bhi ready ho, agla command de dena.",
        "Samajh gaya! System active hai aur aapke agle instruction ka wait kar raha hai.",
        "Bilkul! Main stand-by par hoon.",
        "Great! Let me know jaise hi flash ya testing shuru karni ho."
    )

    private val helpReplies = listOf(
        "Main aapka personal industrial embedded assistant hoon! Main ye sab kar sakta hoon:\n" +
        "• ⚡ Firmware Flashing (STM32 Blue Pill, ESP32, Arduino)\n" +
        "• 🔍 Real-time Hardware Connection Check (ST-Link USB / OTG)\n" +
        "• 📐 Wiring Schematics (PC817 Optocouplers, NPN Proximity Sensors)\n" +
        "• 📊 CNC Stepper Pulse Calculations (Target Pitch & Microstepping)\n" +
        "• ⚙️ App Settings & GitHub Token Setup\n\n" +
        "Aap normal bolkar ya type karke mujhse pooch sakte hain!"
    )

    private val identityReplies = listOf(
        "Mera naam JARVIS hai! Main aapka autonomous industrial embedded assistant hoon. STM32 firmware programming, CNC operations, aur hardware diagnostics me aapki madad karna mera kaam hai.",
        "Main JARVIS hoon — aapka personal AI assistant! STM32 flashing, circuit wiring, aur factory floor automation me hamesha aapke sath hoon."
    )

    private val generalConversationalReplies = listOf(
        "Ji bilkul! Chaliye shuru karte hain. Aapko firmware flashing karni hai, wiring diagram dekhna hai, ya connection check karna hai?",
        "Main samajh gaya! Agar aapko hardware status dekhna hai ya Blue Pill ke pinouts samajhne hain, to bas mujhe bataiye.",
        "Haanji, main sun raha hoon! Kis board ya setting me help chahiye aapko?",
        "Bilkul! Main ready hoon. Command dijiye ya jo poochhna ho poochiye."
    )

    private fun resolveIndustrialOffline(q: String, originalPrompt: String): String {
        replyCounter++

        // 1. Identity & Name
        if (q.contains("kaun ho") || q.contains("who are you") || q.contains("naam kya") ||
            q.contains("kya naam") || q.contains("what is your name") || q.contains("intro") || q.contains("apna naam")) {
            return identityReplies[replyCounter % identityReplies.size]
        }

        // 2. Help & Capabilities
        if (q.contains("kya kar sakte") || q.contains("help") || q.contains("madad") ||
            q.contains("what can you do") || q.contains("features") || q.contains("commands")) {
            return helpReplies[replyCounter % helpReplies.size]
        }

        // 3. Status Chat / Casual Check-in
        if (q.contains("kya chal raha") || q.contains("kya ho raha") || q.contains("sab theek") ||
            q.contains("sab thik") || q.contains("all good") || q.contains("kya news") ||
            q.contains("sab kaisa") || q.contains("haal chaal")) {
            return statusChatReplies[replyCounter % statusChatReplies.size]
        }

        // 4. Gratitude & Praise
        if (q.contains("thank") || q.contains("thanks") || q.contains("dhanyawad") ||
            q.contains("shukriya") || q.contains("bahut badiya") || q.contains("badiya") ||
            q.contains("shabaash") || q.contains("shabash") || q.contains("great") ||
            q.contains("nice") || q.contains("good job") || q.contains("mast") ||
            q.contains("waah") || q.contains("zabardast")) {
            return gratitudeReplies[replyCounter % gratitudeReplies.size]
        }

        // 5. Greetings & Pleasantries
        if (q.contains("hello") || q.contains("hi") || q.contains("hey") ||
            q.contains("namaste") || q.contains("pranam") || q.contains("kaise ho") ||
            q.contains("kya haal") || q.contains("kem cho") || q.contains("good morning") ||
            q.contains("good evening") || q.contains("shubh prabhat") || q == "start" || q == "shuru") {
            return greetingReplies[replyCounter % greetingReplies.size]
        }

        // 6. Affirmations & Acknowledgments
        if (q == "ok" || q == "theek hai" || q == "thik hai" || q == "accha" ||
            q == "acha" || q == "samajh gaya" || q == "haan" || q == "yes" ||
            q == "sahi hai" || q == "done" || q == "alright" || q == "bilkul") {
            return affirmationReplies[replyCounter % affirmationReplies.size]
        }

        // 7. Technical: Pitch & Stepper Pulses
        if (q.contains("pitch") || q.contains("pulse") || q.contains("step") || q.contains("formula")) {
            return """
            📐 [CNC Stepper Pulse & Pitch Calculation]
            
            • Formula: Pulses = (Target Pitch mm × Stepper Pulses/Rev) / (π × Roller Diameter mm)
            • Standard Size #5 (2.50 mm Pitch):
              - Roller Dia = 45.0 mm (Circumference = 141.37 mm)
              - Stepper Resolution = 6400 pulses/rev (1/32 Microstepping)
              - Pulses per Tooth = (2.50 × 6400) / 141.37 = 113.18 Pulses
            • Hardware Guarantee: TIM2 CH2 hardware timer output on PA1 delivers 0% CPU jitter.
            """.trimIndent()
        }

        // 8. Technical: Optocoupler & Sensor Wiring
        if (q.contains("optocoupler") || q.contains("pc817") || q.contains("sensor") || q.contains("npn")) {
            return """
            ⚡ [PC817 Optocoupler & Sensor Galvanic Isolation]
            
            Wiring protocol for 15V-24V NPN Sensor to STM32 3.3V GPIO:
            1. Sensor Brown: +15V / +24V Industrial SMPS Rail.
            2. Sensor Blue: Industrial Power Supply Negative (0V).
            3. PC817 Pin 1 (Anode): +15V via 2.2kΩ (1/2W) current limiting resistor.
            4. PC817 Pin 2 (Cathode): NPN Sensor Black (Open Collector Output).
            5. PC817 Pin 3 (Emitter): STM32 Clean Digital GND.
            6. PC817 Pin 4 (Collector): STM32 GPIO (PA0 Cam / PA3 Tape / PB0 Coil).
            7. Pull-Up: 3.3kΩ resistor between STM32 GPIO and +3.3V rail.
            """.trimIndent()
        }

        // 9. Technical: STM32 Blue Pill Pinouts
        if (q.contains("pinout") || q.contains("pin") || q.contains("blue pill")) {
            return """
            📐 [STM32F103C8T6 Blue Pill Hardware Pinout]
            
            • SWD Programming Header:
              - SWDIO: Pin PA13 (Pin 34)
              - SWCLK: Pin PA14 (Pin 37)
              - GND: Ground | 3.3V: VDD (Caution: NEVER apply 5V to 3.3V pin!)
            • Zipper CNC Critical GPIO:
              - PA0: Cam Proximity Sensor (PC817 Opto Isolated)
              - PA1: TIM2_CH2 Stepper Pulse Train (Hardware Timer)
              - PA2: Stepper Direction (DIR)
              - PA3: Tape Runout Sensor (PC817 Opto Isolated)
              - PB0: Coil Sensor (PC817 Opto Isolated)
              - PB1: Emergency Stop / Safety Relay (Active LOW)
            """.trimIndent()
        }

        // 10. Technical: Settings & Configuration
        if (q.contains("setting") || q.contains("seting") || q.contains("config") || q.contains("setup")) {
            return """
            ⚙️ [System Settings & Configuration]
            
            • Engineer Profile: Rajesh Shah
            • GitHub CI/CD: Automated APK builds & Release downloads
            • Baud Rate: 115200 (Default ST-Link V2 & USB-Serial)
            • Firmware: V16.5.1 Production (Autonomous TIM2 Edition)
            • Quick Action: Tap the 'Settings' tab on the top menu to edit token and profiles.
            """.trimIndent()
        }

        // 11. Technical: Flashing Window
        if (q.contains("flash") || q.contains("flsah") || q.contains("burn")) {
            return """
            ⚡ [Firmware Flashing Pipeline]
            
            • Active Release: V16.5.1 Autonomous Timer 2 Edition
            • How to open: Type "flashing window dikhao" to open programming panel.
            • Pre-flight: Connect ST-Link V2 via USB OTG and tap CONNECT before programming.
            """.trimIndent()
        }

        // 12. Interactive Clarification Fallback (When query is unclear, asks targeted questions)
        val clarificationQuestions = listOf(
            "${getUserSalutation()}, main aapka point poori tarah samajh nahi paaya. Kya aap thoda aur detail me bata sakte hain:\n• Kya aap firmware flash karna chahte hain?\n• Hardware connection check karna chahte hain?\n• Ya kisi electronic component (resistor, diode, sensor, mosfet) ke baare me pooch rahe hain?",
            "Sawal poori tarah clear nahi hua sir. Kripya batayein:\n1. Kya koi hardware ya wiring issue solve karna hai?\n2. Ya CNC machine ke pitch/rpm parameters check karne hain?\nAap thoda detail denge to main accurate guide kar paunga!",
            "Main samajhne ki koshish kar raha hoon ${getUserSalutation()}. Kya aap specific task ya error message bata sakte hain taaki main confirm karke exact step bata sakoon?"
        )
        return clarificationQuestions[replyCounter % clarificationQuestions.size]
    }

    private fun resolveCodeWizardOffline(q: String, originalPrompt: String): String {
        return """
        💻 [STM32 Embedded Firmware Guidelines]
        
        ${getUserSalutation()}, quick technical reference:
        • Vector Table Base: 0x08000000
        • Always use volatile qualifiers for hardware registers and ISR flags.
        • Hardware TIM2 output on PA1 guarantees clock-synchronized stepping with 0% CPU jitter.
        """.trimIndent()
    }

    private fun resolveTranslatorOffline(q: String, originalPrompt: String): String {
        return """
        🌐 [JARVIS: FACTORY OPERATING PROTOCOLS (SOP)]
        
        ${getUserSalutation()}, here are standard production protocols in English and Hindi:
        1. [EN] Verify ST-Link cable connection and check 15V sensor power supply before power-on.
           [HI] मशीन चालू करने से पहले, ST-Link केबल और 15V सेंसर पावर सप्लाई की जांच करें।
        2. [EN] In Auto-Pilot mode, plugging in the USB cable automatically programs and verifies firmware.
           [HI] ऑटो-पायलट मोड में, USB केबल लगाते ही फर्मवेयर अपने आप फ्लैश और वेरीफाई हो जाएगा।
        3. [EN] Normal operating main shaft speed is 2,850 RPM with Size #5 2.50mm pitch.
           [HI] सामान्य ऑपरेटिंग स्पीड 2850 RPM है, साइज #5 (2.50mm पिच) के साथ।
        4. [EN] If tape breaks or coil jams, the E-Stop relay disconnects immediately.
           [HI] टेप टूटने या कॉइल अटकने पर, मोटर E-Stop रिले तुरंत बंद हो जाता है।
        """.trimIndent()
    }

    private fun resolveGeneralAssistantOffline(q: String, originalPrompt: String): String {
        val s = getUserSalutation()
        val replies = listOf(
            """
            $s, main 100% offline operational hoon!
            
            Sabhi core industrial modules standby par hain:
            • ⚡ Firmware Flasher: 1-Click STM32 mass-erase, write & verify.
            • 📊 Live Telemetry: 2,850 RPM spindle, optical tape/coil status.
            • 📐 Precision Math: Size #3, #5, #8, #10 pitch & optocoupler resistor solver.
            • 🛡️ Safety Blackbox: Microsecond fault logger & incident audit.
            
            Aap batayein, kis task ko execute ya verify karein?
            """.trimIndent(),
            """
            JARVIS active aur ready hai, $s!
            
            Aap mujhse koi bhi technical sawal pooch sakte hain ya command de sakte hain:
            • 'flash' ➔ Flashing pipeline open karein
            • 'status' ➔ Real-time telemetry check karein
            • 'wiring' ➔ STM32 pinouts aur PC817 diagrams dekhein
            • Pitch calculation ya electronics resistor sizing solve karwayein.
            """.trimIndent(),
            """
            System status: Green. At your service, $s!
            Industrial offline engine me ST-Link SWD protocols, stepper kinematics, aur hardware interlocks fully active hain. Kripya apna command batayein.
            """.trimIndent()
        )
        return replies.random()
    }

    private suspend fun callCloudAssistantApi(prompt: String, mode: AiMode, apiKey: String): String = withContext(Dispatchers.IO) {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
        val url = URL(endpoint)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.doOutput = true

        val requestBody = JSONObject()
        val contentsArray = JSONArray()
        val contentObj = JSONObject()
        val partsArray = JSONArray()

        val sysPart = JSONObject()
        sysPart.put("text", "System Instruction: ${mode.systemPrompt}\nUser Query: $prompt")
        partsArray.put(sysPart)

        contentObj.put("parts", partsArray)
        contentsArray.put(contentObj)
        requestBody.put("contents", contentsArray)

        OutputStreamWriter(conn.outputStream).use { writer ->
            writer.write(requestBody.toString())
            writer.flush()
        }

        val code = conn.responseCode
        if (code in 200..299) {
            val responseText = conn.inputStream.bufferedReader().use { it.readText() }
            val respJson = JSONObject(responseText)
            val candidates = respJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val first = candidates.getJSONObject(0)
                val content = first.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                val text = parts.getJSONObject(0).getString("text")
                return@withContext text.trim()
            }
            return@withContext "Response received, but format was unexpected, ${getUserSalutation()}."
        } else {
            val errorText = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
            throw RuntimeException("Cloud Error ($code): $errorText")
        }
    }

    suspend fun syncPendingOfflinePrompts(apiKey: String, onProgress: (String) -> Unit = {}): Int = withContext(Dispatchers.IO) {
        if (!isOnline() || apiKey.isBlank()) return@withContext 0

        var syncedCount = 0
        val pendingList = synchronized(this@UniversalAiEngine) {
            memoryList.filter { it.syncStatus == SyncStatus.PENDING_CLOUD_SYNC && it.role == "assistant" }
        }

        for (msg in pendingList) {
            try {
                onProgress("Syncing message ${msg.id} with cloud...")
                val idx = memoryList.indexOf(msg)
                val userPrompt = if (idx > 0 && memoryList[idx - 1].role == "user") {
                    memoryList[idx - 1].content
                } else {
                    "Provide comprehensive update on: ${msg.content.take(50)}"
                }

                val cloudRes = callCloudAssistantApi(userPrompt, msg.mode, apiKey)
                synchronized(this@UniversalAiEngine) {
                    val updated = msg.copy(
                        content = "[CLOUD SYNCED]\n\n$cloudRes",
                        syncStatus = SyncStatus.SYNCED_ONLINE
                    )
                    val currentIdx = memoryList.indexOfFirst { it.id == msg.id }
                    if (currentIdx != -1) {
                        memoryList[currentIdx] = updated
                    }
                }
                syncedCount++
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (syncedCount > 0) {
            synchronized(this@UniversalAiEngine) {
                saveHistoryToDisk()
            }
        }
        return@withContext syncedCount
    }

    companion object {
        @Volatile
        private var instance: UniversalAiEngine? = null

        fun getInstance(context: Context): UniversalAiEngine {
            return instance ?: synchronized(this) {
                instance ?: UniversalAiEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
