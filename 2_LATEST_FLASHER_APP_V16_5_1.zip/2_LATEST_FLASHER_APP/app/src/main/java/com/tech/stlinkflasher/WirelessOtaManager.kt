package com.tech.stlinkflasher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * WirelessOtaManager
 * Industrial Wireless Over-The-Air (OTA) Firmware Flashing Engine.
 * Transmits compiled .bin firmware images over Wi-Fi / LAN to target MCU Wi-Fi modules
 * via HTTP multipart/form-data or raw stream upload with progress callbacks.
 */
class WirelessOtaManager {

    data class OtaResult(
        val success: Boolean,
        val responseCode: Int,
        val message: String,
        val bytesTransferred: Int
    )

    suspend fun uploadFirmwareOta(
        targetUrlOrIp: String,
        binaryData: ByteArray,
        filename: String = "firmware.bin",
        onProgress: (Int) -> Unit
    ): OtaResult = withContext(Dispatchers.IO) {
        var urlString = targetUrlOrIp.trim()
        if (!urlString.startsWith("http://") && !urlString.startsWith("https://")) {
            urlString = "http://$urlString"
        }
        val slashIndex = urlString.indexOf('/', 8)
        if (slashIndex == -1) {
            urlString = "$urlString/update"
        }

        var connection: HttpURLConnection? = null
        try {
            val url = URL(urlString)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 60000
                doOutput = true
                doInput = true
                useCaches = false
            }

            val boundary = "==OTA_FLASHER_BOUNDARY_${System.currentTimeMillis()}=="
            connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

            val header = ("--$boundary\r\n" +
                    "Content-Disposition: form-data; name=\"update\"; filename=\"$filename\"\r\n" +
                    "Content-Type: application/octet-stream\r\n\r\n").toByteArray(Charsets.UTF_8)
            val footer = ("\r\n--$boundary--\r\n").toByteArray(Charsets.UTF_8)

            val totalSize = header.size + binaryData.size + footer.size
            connection.setFixedLengthStreamingMode(totalSize)

            val os: OutputStream = connection.outputStream
            os.write(header)

            val chunkSize = 2048
            var bytesSent = 0
            while (bytesSent < binaryData.size) {
                val toWrite = minOf(chunkSize, binaryData.size - bytesSent)
                os.write(binaryData, bytesSent, toWrite)
                bytesSent += toWrite
                val percent = ((bytesSent.toLong() * 100) / binaryData.size).toInt()
                withContext(Dispatchers.Main) {
                    onProgress(percent)
                }
            }

            os.write(footer)
            os.flush()

            val responseCode = connection.responseCode
            val responseStream: InputStream = if (responseCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream ?: connection.inputStream
            }

            val responseText = responseStream.bufferedReader().use { it.readText() }
            val isSuccess = responseCode in 200..299

            OtaResult(
                success = isSuccess,
                responseCode = responseCode,
                message = if (isSuccess) "OTA Flash Successful: $responseText" else "OTA Error (HTTP $responseCode): $responseText",
                bytesTransferred = bytesSent
            )
        } catch (e: Exception) {
            OtaResult(
                success = false,
                responseCode = -1,
                message = "OTA Network Failed: ${e.message}",
                bytesTransferred = 0
            )
        } finally {
            connection?.disconnect()
        }
    }
}
