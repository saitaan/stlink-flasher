package com.tech.stlinkflasher

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

class SettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    enum class OperationMode {
        MANUAL,
        AUTOMATED_AUTO_PILOT
    }

    enum class SwdSpeed(val displayName: String, val khz: Int) {
        HIGH_4MHZ("4.0 MHz (High Speed)", 4000),
        NORMAL_1_8MHZ("1.8 MHz (Recommended)", 1800),
        SAFE_500KHZ("500 kHz (Safe / Long Wires)", 500)
    }

    enum class TargetMcu(val displayName: String, val flashSizeKb: Int, val sramSizeKb: Int) {
        STM32F103C8T6("STM32F103C8T6 (64KB Flash, 20KB SRAM)", 64, 20),
        STM32F103CBT6("STM32F103CBT6 (128KB Flash, 20KB SRAM)", 128, 20),
        STM32F401CCU6("STM32F401CCU6 (256KB Flash, 64KB SRAM)", 256, 64),
        STM32F411CEU6("STM32F411CEU6 (512KB Flash, 128KB SRAM)", 512, 128),
        ESP32_GENERIC("ESP32 (4MB Flash, USB-UART)", 4096, 520)
    }

    // --- Hardware & Flash Settings ---
    var operationMode: OperationMode
        get() {
            val modeStr = prefs.getString(KEY_OPERATION_MODE, OperationMode.MANUAL.name)
            return try {
                OperationMode.valueOf(modeStr ?: OperationMode.MANUAL.name)
            } catch (e: Exception) {
                OperationMode.MANUAL
            }
        }
        set(value) = prefs.edit().putString(KEY_OPERATION_MODE, value.name).apply()

    var swdSpeed: SwdSpeed
        get() {
            val speedStr = prefs.getString(KEY_SWD_SPEED, SwdSpeed.NORMAL_1_8MHZ.name)
            return try {
                SwdSpeed.valueOf(speedStr ?: SwdSpeed.NORMAL_1_8MHZ.name)
            } catch (e: Exception) {
                SwdSpeed.NORMAL_1_8MHZ
            }
        }
        set(value) = prefs.edit().putString(KEY_SWD_SPEED, value.name).apply()

    var targetMcu: TargetMcu
        get() {
            val mcuStr = prefs.getString(KEY_TARGET_MCU, TargetMcu.STM32F103C8T6.name)
            return try {
                TargetMcu.valueOf(mcuStr ?: TargetMcu.STM32F103C8T6.name)
            } catch (e: Exception) {
                TargetMcu.STM32F103C8T6
            }
        }
        set(value) = prefs.edit().putString(KEY_TARGET_MCU, value.name).apply()

    var autoVerifyAfterFlash: Boolean
        get() = prefs.getBoolean(KEY_AUTO_VERIFY, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_VERIFY, value).apply()

    var autoResetAfterFlash: Boolean
        get() = prefs.getBoolean(KEY_AUTO_RESET, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_RESET, value).apply()

    var rdpProtectionLevel1: Boolean
        get() = prefs.getBoolean(KEY_RDP_LOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_RDP_LOCK, value).apply()

    var hapticFeedback: Boolean
        get() = prefs.getBoolean(KEY_HAPTIC, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTIC, value).apply()

    var soundNotifications: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    // --- CNC Calibration Presets ---
    var rollerDiameterMm: Float
        get() = prefs.getFloat(KEY_ROLLER_DIA, 45.0f)
        set(value) = prefs.edit().putFloat(KEY_ROLLER_DIA, value).apply()

    var stepperPulsesPerRev: Int
        get() = prefs.getInt(KEY_STEPPER_PULSES, 6400)
        set(value) = prefs.edit().putInt(KEY_STEPPER_PULSES, value).apply()

    var targetPitchMm: Float
        get() = prefs.getFloat(KEY_TARGET_PITCH, 2.50f)
        set(value) = prefs.edit().putFloat(KEY_TARGET_PITCH, value).apply()

    var maxShaftRpm: Int
        get() = prefs.getInt(KEY_MAX_RPM, 3000)
        set(value) = prefs.edit().putInt(KEY_MAX_RPM, value).apply()

    var feedAngleDegrees: Int
        get() = prefs.getInt(KEY_FEED_ANGLE, 160)
        set(value) = prefs.edit().putInt(KEY_FEED_ANGLE, value).apply()

    // --- Engineer Identity & Cloud Sync ---
    var engineerName: String
        get() = prefs.getString(KEY_ENG_NAME, "Rajesh Shah") ?: "Rajesh Shah"
        set(value) = prefs.edit().putString(KEY_ENG_NAME, value).apply()

    var organizationName: String
        get() = prefs.getString(KEY_ORG_NAME, "")?.takeIf { !it.contains("Nipon", ignoreCase = true) } ?: ""
        set(value) = prefs.edit().putString(KEY_ORG_NAME, value).apply()

    var githubUsername: String
        get() = prefs.getString(KEY_GH_USER, "saitaan") ?: "saitaan"
        set(value) = prefs.edit().putString(KEY_GH_USER, value).apply()

    var githubRepo: String
        get() = prefs.getString(KEY_GH_REPO, "STM32_Zipper_CNC_V16_5_0_Master") ?: "STM32_Zipper_CNC_V16_5_0_Master"
        set(value) = prefs.edit().putString(KEY_GH_REPO, value).apply()

    var githubToken: String
        get() = prefs.getString(KEY_GH_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GH_TOKEN, value).apply()

    var geminiApiKey: String
        get() = prefs.getString(KEY_GEMINI_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GEMINI_KEY, value).apply()

    var cloudAutoSyncEnabled: Boolean
        get() = prefs.getBoolean(KEY_CLOUD_SYNC, true)
        set(value) = prefs.edit().putBoolean(KEY_CLOUD_SYNC, value).apply()

    // --- Production Counters ---
    var totalShiftCuts: Long
        get() = prefs.getLong(KEY_SHIFT_CUTS, 45210L)
        set(value) = prefs.edit().putLong(KEY_SHIFT_CUTS, value).apply()

    var totalShiftMeters: Float
        get() = prefs.getFloat(KEY_SHIFT_METERS, 113.02f)
        set(value) = prefs.edit().putFloat(KEY_SHIFT_METERS, value).apply()

    var shiftTargetTeeth: Long
        get() = prefs.getLong(KEY_SHIFT_TARGET, 60000L)
        set(value) = prefs.edit().putLong(KEY_SHIFT_TARGET, value).apply()

    fun exportToJson(): String {
        val root = JSONObject()
        root.put("version", "4.5.0")
        root.put("engineer", engineerName)
        root.put("organization", organizationName)
        root.put("operation_mode", operationMode.name)
        root.put("swd_speed", swdSpeed.name)
        root.put("target_mcu", targetMcu.name)
        root.put("auto_verify", autoVerifyAfterFlash)
        root.put("auto_reset", autoResetAfterFlash)
        root.put("rdp_lock", rdpProtectionLevel1)
        root.put("roller_dia_mm", rollerDiameterMm.toDouble())
        root.put("stepper_pulses", stepperPulsesPerRev)
        root.put("target_pitch_mm", targetPitchMm.toDouble())
        root.put("max_rpm", maxShaftRpm)
        root.put("feed_angle", feedAngleDegrees)
        root.put("github_user", githubUsername)
        root.put("github_repo", githubRepo)
        root.put("cloud_auto_sync", cloudAutoSyncEnabled)
        return root.toString(4)
    }

    fun importFromJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)
            if (root.has("operation_mode")) {
                operationMode = OperationMode.valueOf(root.getString("operation_mode"))
            }
            if (root.has("swd_speed")) {
                swdSpeed = SwdSpeed.valueOf(root.getString("swd_speed"))
            }
            if (root.has("target_mcu")) {
                targetMcu = TargetMcu.valueOf(root.getString("target_mcu"))
            }
            if (root.has("auto_verify")) autoVerifyAfterFlash = root.getBoolean("auto_verify")
            if (root.has("auto_reset")) autoResetAfterFlash = root.getBoolean("auto_reset")
            if (root.has("rdp_lock")) rdpProtectionLevel1 = root.getBoolean("rdp_lock")
            if (root.has("roller_dia_mm")) rollerDiameterMm = root.getDouble("roller_dia_mm").toFloat()
            if (root.has("stepper_pulses")) stepperPulsesPerRev = root.getInt("stepper_pulses")
            if (root.has("target_pitch_mm")) targetPitchMm = root.getDouble("target_pitch_mm").toFloat()
            if (root.has("max_rpm")) maxShaftRpm = root.getInt("max_rpm")
            if (root.has("feed_angle")) feedAngleDegrees = root.getInt("feed_angle")
            if (root.has("github_user")) githubUsername = root.getString("github_user")
            if (root.has("github_repo")) githubRepo = root.getString("github_repo")
            if (root.has("cloud_auto_sync")) cloudAutoSyncEnabled = root.getBoolean("cloud_auto_sync")
            true
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        private const val PREF_NAME = "stlink_flasher_v450_master_prefs"

        private const val KEY_OPERATION_MODE = "key_operation_mode"
        private const val KEY_SWD_SPEED = "key_swd_speed"
        private const val KEY_TARGET_MCU = "key_target_mcu"
        private const val KEY_AUTO_VERIFY = "key_auto_verify"
        private const val KEY_AUTO_RESET = "key_auto_reset"
        private const val KEY_RDP_LOCK = "key_rdp_lock"
        private const val KEY_HAPTIC = "key_haptic"
        private const val KEY_SOUND = "key_sound"

        private const val KEY_ROLLER_DIA = "key_roller_dia"
        private const val KEY_STEPPER_PULSES = "key_stepper_pulses"
        private const val KEY_TARGET_PITCH = "key_target_pitch"
        private const val KEY_MAX_RPM = "key_max_rpm"
        private const val KEY_FEED_ANGLE = "key_feed_angle"

        private const val KEY_ENG_NAME = "key_eng_name"
        private const val KEY_ORG_NAME = "key_org_name"
        private const val KEY_GH_USER = "key_gh_user"
        private const val KEY_GH_REPO = "key_gh_repo"
        private const val KEY_GH_TOKEN = "key_gh_token"
        private const val KEY_GEMINI_KEY = "key_gemini_key"
        private const val KEY_CLOUD_SYNC = "key_cloud_sync"

        private const val KEY_SHIFT_CUTS = "key_shift_cuts"
        private const val KEY_SHIFT_METERS = "key_shift_meters"
        private const val KEY_SHIFT_TARGET = "key_shift_target"

        @Volatile
        private var instance: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
