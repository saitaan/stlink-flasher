package com.tech.stlinkflasher

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * BatchProgrammingManager
 * Production Line Continuous Multi-Board Flasher Engine for STM32 Blue Pill & Black Pill.
 * Managed by JARVIS Autonomous Industrial OS.
 */
class BatchProgrammingManager private constructor(private val context: Context) {

    private val prefs = context.getSharedPreferences("jarvis_batch_programming_prefs", Context.MODE_PRIVATE)

    var isBatchModeEnabled: Boolean
        get() = prefs.getBoolean("batch_mode_enabled", false)
        set(value) = prefs.edit().putBoolean("batch_mode_enabled", value).apply()

    var autoApplyRdpLevel1: Boolean
        get() = prefs.getBoolean("auto_apply_rdp_level1", false)
        set(value) = prefs.edit().putBoolean("auto_apply_rdp_level1", value).apply()

    var boardsProgrammedTotal: Int
        get() = prefs.getInt("boards_programmed_total", 0)
        private set(value) = prefs.edit().putInt("boards_programmed_total", value).apply()

    var boardsPassed: Int
        get() = prefs.getInt("boards_passed", 0)
        private set(value) = prefs.edit().putInt("boards_passed", value).apply()

    var boardsFailed: Int
        get() = prefs.getInt("boards_failed", 0)
        private set(value) = prefs.edit().putInt("boards_failed", value).apply()

    companion object {
        @Volatile
        private var instance: BatchProgrammingManager? = null

        fun getInstance(context: Context): BatchProgrammingManager {
            return instance ?: synchronized(this) {
                instance ?: BatchProgrammingManager(context.applicationContext).also { instance = it }
            }
        }
    }

    @Synchronized
    fun recordSuccess() {
        boardsProgrammedTotal++
        boardsPassed++
        triggerHapticFeedback(success = true)
    }

    @Synchronized
    fun recordFailure() {
        boardsProgrammedTotal++
        boardsFailed++
        triggerHapticFeedback(success = false)
    }

    @Synchronized
    fun resetBatchCounters() {
        boardsProgrammedTotal = 0
        boardsPassed = 0
        boardsFailed = 0
    }

    private fun triggerHapticFeedback(success: Boolean) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (success) {
                    // Double short click for success
                    val timings = longArrayOf(0, 100, 80, 150)
                    val amplitudes = intArrayOf(0, 200, 0, 255)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    // Long harsh buzz for failure
                    vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            } else {
                @Suppress("DEPRECATION")
                if (success) {
                    vibrator.vibrate(longArrayOf(0, 100, 80, 150), -1)
                } else {
                    vibrator.vibrate(500)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
