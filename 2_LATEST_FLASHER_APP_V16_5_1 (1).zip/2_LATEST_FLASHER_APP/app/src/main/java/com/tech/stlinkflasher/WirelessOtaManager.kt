package com.tech.stlinkflasher

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * WirelessOtaManager
 * Industrial Local-Network Wi-Fi OTA Firmware Flashing Client.
 * Transmits production .bin binaries over HTTP multipart/form-data to field Wi-Fi gateways.
 * Managed by JARVIS Autonomous Industrial OS.
 */
class WirelessOtaManager private constructor(private val context: Context) {

    private val prefs = context.getSharedPreferences("jarvis_wireless_ota_prefs", Context.MODE_PRIVATE)

    var targetIpAddress: String
        get() = prefs.getString("ota_target_ip", "192.168.4.1") ?: "192.168.4.1"
        set(value) = prefs.edit().putString("ota_target_ip", value).apply()

    var targetPort: Int
        get() = prefs.getInt("ota_target_port", 80)
        set(value) = prefs.edit().putInt("ota_target_port", value).apply()

    var targetEndpoint: String
        get() = prefs.getString("ota_target_endpoint", "/update") ?: "/update"
        set(value) = prefs.edit().putString("ota_target_endpoint", value).apply()

    companion object {
        @Volatile
        private var instance: WirelessOtaManager? = null

        fun getInstance(context: Context): WirelessOtaManager {
            return instance ?: synchronized(this) {
                instance ?: WirelessOtaManager(context.applicationContext).also { instance = it }
            }
        }
    }

    suspend fun uploadFirmwareBinary(
        binaryBytes: ByteArray,
        filename: String = "firmware.bin",
        onProgress: (Int) -> Unit,
        onLog: (String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val boundary = "==JARVIS_OTA_BOUNDARY_${System.currentTimeMillis()}=="
        val lineEnd = "\r\n"
        val twoHyphens = "--"

        val targetUrl = "http://${targetIpAddress}:${targetPort}${targetEndpoint}"
        onLog("🌐 [OTA] Connecting to field Wi-Fi gateway: $targetUrl")

        var connection: HttpURLConnection? = null
        try {
            val url = URL(targetUrl)
            connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 7000
                readTimeout = 25000
                doInput = true
                doOutput = true
                useCaches = false
                requestMethod = "POST"
                setRequestProperty("Connection", "Keep-Alive")
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            val outputStream = DataOutputStream(connection.outputStream)

            // Header for file part
            outputStream.writeBytes(twoHyphens + boundary + lineEnd)
            outputStream.writeBytes("Content-Disposition: form-data; name=\"update\"; filename=\"$filename\"$lineEnd")
            outputStream.writeBytes("Content-Type: application/octet-stream$lineEnd")
            outputStream.writeBytes(lineEnd)

            // Stream binary data in 1KB chunks with live progress callbacks
            val totalBytes = binaryBytes.size
            var bytesWritten = 0
            val chunkSize = 1024
            var offset = 0

            while (offset < totalBytes) {
                val len = Math.min(chunkSize, totalBytes - offset)
                outputStream.write(binaryBytes, offset, len)
                offset += len
                bytesWritten += len
                val pct = ((bytesWritten.toDouble() / totalBytes.toDouble()) * 100).toInt()
                onProgress(pct)
            }

            outputStream.writeBytes(lineEnd)
            outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd)
            outputStream.flush()
            outputStream.close()

            val responseCode = connection.responseCode
            onLog("🌐 [OTA] Response Code from Gateway: $responseCode")

            if (responseCode in 200..299) {
                val responseBody = connection.inputStream.bufferedReader().use { it.readText() }
                onLog("✅ [OTA] Firmware successfully received by MCU gateway: $responseBody")
                return@withContext true
            } else {
                val errorBody = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $responseCode"
                onLog("❌ [OTA] Flash failed on gateway: $errorBody")
                return@withContext false
            }
        } catch (e: Exception) {
            onLog("❌ [OTA Error] ${e.message}")
            return@withContext false
        } finally {
            connection?.disconnect()
        }
    }
}
