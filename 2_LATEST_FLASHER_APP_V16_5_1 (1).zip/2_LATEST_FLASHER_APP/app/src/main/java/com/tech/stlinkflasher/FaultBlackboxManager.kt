package com.tech.stlinkflasher

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * FaultBlackboxManager
 * Industrial Incident & Fault Blackbox Recorder for Nipon Zipper CNC & STM32 Controller.
 * Managed by JARVIS Autonomous Industrial OS.
 */
class FaultBlackboxManager private constructor(private val context: Context) {

    data class FaultRecord(
        val timestamp: Long,
        val faultType: String,
        val details: String,
        val shaftRpm: Int,
        val tapeSensorStatus: String,
        val coilSensorStatus: String,
        val swdCoreStatus: String
    )

    private val blackboxFile = File(context.filesDir, "jarvis_fault_blackbox.json")
    private val records = ArrayList<FaultRecord>()

    init {
        loadRecords()
    }

    companion object {
        @Volatile
        private var instance: FaultBlackboxManager? = null

        fun getInstance(context: Context): FaultBlackboxManager {
            return instance ?: synchronized(this) {
                instance ?: FaultBlackboxManager(context.applicationContext).also { instance = it }
            }
        }
    }

    @Synchronized
    fun recordFault(
        faultType: String,
        details: String,
        rpm: Int = 0,
        tapeStatus: String = "OK",
        coilStatus: String = "OK",
        swdStatus: String = "CONNECTED"
    ) {
        val record = FaultRecord(
            timestamp = System.currentTimeMillis(),
            faultType = faultType,
            details = details,
            shaftRpm = rpm,
            tapeSensorStatus = tapeStatus,
            coilSensorStatus = coilStatus,
            swdCoreStatus = swdStatus
        )
        records.add(record)
        saveRecords()
    }

    @Synchronized
    fun getRecords(): List<FaultRecord> = ArrayList(records)

    @Synchronized
    fun clearRecords() {
        records.clear()
        if (blackboxFile.exists()) {
            blackboxFile.delete()
        }
    }

    @Synchronized
    fun exportAuditReport(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)
        val timeLabel = sdf.format(Date())
        val fileName = "Blackbox_Fault_Audit_${timeLabel}.txt"

        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val exportFile = File(downloadsDir, fileName)

        val sb = StringBuilder()
        sb.append("=================================================================\n")
        sb.append("🏭 NIPON ZIPPER CNC - INDUSTRIAL FAULT BLACKBOX AUDIT REPORT\n")
        sb.append("Managed by: JARVIS Industrial System | Rajesh Shah\n")
        sb.append("Export Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
        sb.append("Total Incidents Recorded: ${records.size}\n")
        sb.append("=================================================================\n\n")

        if (records.isEmpty()) {
            sb.append("Status: 100% HEALTHY. Zero faults, trips, or stalls recorded.\n")
        } else {
            val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
            for ((index, r) in records.withIndex()) {
                sb.append("INCIDENT #${index + 1}:\n")
                sb.append("  Timestamp:       ${dateFmt.format(Date(r.timestamp))}\n")
                sb.append("  Fault Type:      ${r.faultType}\n")
                sb.append("  Details:         ${r.details}\n")
                sb.append("  Main Shaft RPM:  ${r.shaftRpm}\n")
                sb.append("  Tape Sensor:     ${r.tapeSensorStatus}\n")
                sb.append("  Coil Sensor:     ${r.coilSensorStatus}\n")
                sb.append("  SWD Core Status: ${r.swdCoreStatus}\n")
                sb.append("-----------------------------------------------------------------\n")
            }
        }

        try {
            FileWriter(exportFile).use { it.write(sb.toString()) }
            return exportFile.absolutePath
        } catch (e: Exception) {
            val fallback = File(context.filesDir, fileName)
            FileWriter(fallback).use { it.write(sb.toString()) }
            return fallback.absolutePath
        }
    }

    private fun saveRecords() {
        try {
            val arr = JSONArray()
            for (r in records.takeLast(100)) { // Keep last 100 incidents
                val obj = JSONObject()
                obj.put("timestamp", r.timestamp)
                obj.put("faultType", r.faultType)
                obj.put("details", r.details)
                obj.put("shaftRpm", r.shaftRpm)
                obj.put("tapeSensorStatus", r.tapeSensorStatus)
                obj.put("coilSensorStatus", r.coilSensorStatus)
                obj.put("swdCoreStatus", r.swdCoreStatus)
                arr.put(obj)
            }
            FileWriter(blackboxFile).use { it.write(arr.toString(2)) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadRecords() {
        if (!blackboxFile.exists()) return
        try {
            val content = blackboxFile.readText()
            val arr = JSONArray(content)
            records.clear()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                records.add(
                    FaultRecord(
                        timestamp = obj.optLong("timestamp"),
                        faultType = obj.optString("faultType"),
                        details = obj.optString("details"),
                        shaftRpm = obj.optInt("shaftRpm", 0),
                        tapeSensorStatus = obj.optString("tapeSensorStatus", "OK"),
                        coilSensorStatus = obj.optString("coilSensorStatus", "OK"),
                        swdCoreStatus = obj.optString("swdCoreStatus", "CONNECTED")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
