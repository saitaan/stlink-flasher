package com.tech.stlinkflasher

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * BatchProgrammingManager
 * Production Multi-Board Continuous Flashing Pipeline.
 * Enables factory technicians to program dozens or hundreds of boards sequentially
 * with instant hotplug detection, auto-verify, optional RDP-lock, and audio/haptic feedback.
 */
class BatchProgrammingManager private constructor(private val context: Context) {

    interface BatchCallback {
        fun onBatchStatusChanged(isActive: Boolean)
        fun onBoardStarted(boardIndex: Int)
        fun onBoardCompleted(boardIndex: Int, success: Boolean, message: String)
        fun onBatchProgress(percent: Int)
    }

    var isBatchActive: Boolean = false
        private set

    var totalBoardsTarget: Int = 50
    var boardsProgrammed: Int = 0
        private set
    var boardsPassed: Int = 0
        private set
    var boardsFailed: Int = 0
        private set

    var autoApplyRdpLock: Boolean = false

    private val callbacks = mutableListOf<BatchCallback>()

    fun addCallback(cb: BatchCallback) {
        synchronized(callbacks) {
            if (!callbacks.contains(cb)) callbacks.add(cb)
        }
    }

    fun removeCallback(cb: BatchCallback) {
        synchronized(callbacks) { callbacks.remove(cb) }
    }

    fun startBatch(targetCount: Int = 50, autoLock: Boolean = false) {
        isBatchActive = true
        totalBoardsTarget = targetCount
        autoApplyRdpLock = autoLock
        boardsProgrammed = 0
        boardsPassed = 0
        boardsFailed = 0
        notifyStatus(true)
    }

    fun stopBatch() {
        isBatchActive = false
        notifyStatus(false)
    }

    fun resetCounters() {
        boardsProgrammed = 0
        boardsPassed = 0
        boardsFailed = 0
    }

    fun recordBoardResult(success: Boolean, message: String) {
        boardsProgrammed++
        if (success) {
            boardsPassed++
            vibrateSuccess()
        } else {
            boardsFailed++
            vibrateFailure()
        }
        notifyBoardCompleted(boardsProgrammed, success, message)
    }

    private fun notifyStatus(active: Boolean) {
        synchronized(callbacks) {
            for (cb in callbacks) cb.onBatchStatusChanged(active)
        }
    }

    fun notifyBoardStarted(boardIndex: Int) {
        synchronized(callbacks) {
            for (cb in callbacks) cb.onBoardStarted(boardIndex)
        }
    }

    private fun notifyBoardCompleted(boardIndex: Int, success: Boolean, msg: String) {
        synchronized(callbacks) {
            for (cb in callbacks) cb.onBoardCompleted(boardIndex, success, msg)
        }
    }

    fun notifyProgress(percent: Int) {
        synchronized(callbacks) {
            for (cb in callbacks) cb.onBatchProgress(percent)
        }
    }

    private fun vibrateSuccess() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 60, 120), -1))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.vibrate(longArrayOf(0, 80, 60, 120), -1)
            }
        } catch (_: Exception) {}
    }

    private fun vibrateFailure() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.vibrate(400)
            }
        } catch (_: Exception) {}
    }

    companion object {
        @Volatile
        private var instance: BatchProgrammingManager? = null

        fun getInstance(context: Context): BatchProgrammingManager {
            return instance ?: synchronized(this) {
                instance ?: BatchProgrammingManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
