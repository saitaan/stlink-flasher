package com.tech.stlinkflasher

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * Hardware Memory Map and Flash Specifications for MCU Targets.
 */
data class McuMemoryMap(
    val mcuId: String,
    val displayName: String,
    val flashBase: Long,
    val flashSize: Long,
    val ramBase: Long,
    val ramSize: Long,
    val programmingGranularity: Int, // 2 for 16-bit halfword (F1), 4 for 32-bit word (F4)
    val pageSizeBytes: Int,
    val isArmCortex: Boolean = true
)

object McuCatalog {
    val STM32F103_64KB = McuMemoryMap(
        mcuId = "stm32f103_64k",
        displayName = "STM32F103C8T6 (64KB Blue Pill)",
        flashBase = 0x08000000L,
        flashSize = 64 * 1024L,
        ramBase = 0x20000000L,
        ramSize = 20 * 1024L,
        programmingGranularity = 2, // 16-bit half-word
        pageSizeBytes = 1024
    )

    val STM32F103_128KB = McuMemoryMap(
        mcuId = "stm32f103_128k",
        displayName = "STM32F103CBT6 (128KB)",
        flashBase = 0x08000000L,
        flashSize = 128 * 1024L,
        ramBase = 0x20000000L,
        ramSize = 20 * 1024L,
        programmingGranularity = 2, // 16-bit half-word
        pageSizeBytes = 1024
    )

    val STM32F401_512KB = McuMemoryMap(
        mcuId = "stm32f401_512k",
        displayName = "STM32F401CCU6 (512KB Black Pill)",
        flashBase = 0x08000000L,
        flashSize = 512 * 1024L,
        ramBase = 0x20000000L,
        ramSize = 64 * 1024L,
        programmingGranularity = 4, // 32-bit word
        pageSizeBytes = 16 * 1024 // Sector-based
    )

    val STM32F411_512KB = McuMemoryMap(
        mcuId = "stm32f411_512k",
        displayName = "STM32F411CEU6 (512KB Black Pill)",
        flashBase = 0x08000000L,
        flashSize = 512 * 1024L,
        ramBase = 0x20000000L,
        ramSize = 128 * 1024L,
        programmingGranularity = 4, // 32-bit word
        pageSizeBytes = 16 * 1024
    )

    val ESP32_GENERIC = McuMemoryMap(
        mcuId = "esp32",
        displayName = "ESP32 (4MB Flash, USB-UART)",
        flashBase = 0x00010000L,
        flashSize = 4 * 1024 * 1024L,
        ramBase = 0x3FFAE000L,
        ramSize = 320 * 1024L,
        programmingGranularity = 1,
        pageSizeBytes = 4096,
        isArmCortex = false
    )

    val ARDUINO_ATMEGA328P = McuMemoryMap(
        mcuId = "arduino_atmega328p",
        displayName = "Arduino AVR (ATmega328P, Optiboot)",
        flashBase = 0x00000000L,
        flashSize = 32 * 1024L,
        ramBase = 0x00000100L,
        ramSize = 2048L,
        programmingGranularity = 1,
        pageSizeBytes = 128,
        isArmCortex = false
    )

    fun getMapForMcu(mcu: String): McuMemoryMap {
        return when {
            mcu.contains("F411", ignoreCase = true) -> STM32F411_512KB
            mcu.contains("F401", ignoreCase = true) || mcu.contains("F4", ignoreCase = true) -> STM32F401_512KB
            mcu.contains("128", ignoreCase = true) || mcu.contains("CBT6", ignoreCase = true) -> STM32F103_128KB
            mcu.contains("ESP32", ignoreCase = true) -> ESP32_GENERIC
            mcu.contains("Arduino", ignoreCase = true) || mcu.contains("ATmega", ignoreCase = true) -> ARDUINO_ATMEGA328P
            else -> STM32F103_64KB
        }
    }
}

/**
 * Firmware Image Pre-Flight Validation Engine.
 */
object FirmwareValidator {
    data class ValidationResult(
        val isValid: Boolean,
        val errorMessage: String = "",
        val initialSp: Long = 0L,
        val resetHandlerPc: Long = 0L,
        val sha256Hex: String = ""
    )

    fun computeSha256(data: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(data)
        val sb = StringBuilder()
        for (b in hash) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun validateFirmware(
        data: ByteArray,
        targetMap: McuMemoryMap,
        expectedSha256: String? = null
    ): ValidationResult {
        if (data.isEmpty()) {
            return ValidationResult(false, "Binary is completely empty (0 bytes).")
        }

        if (data.size > targetMap.flashSize) {
            return ValidationResult(
                false,
                "Binary size (${data.size} bytes) exceeds target Flash capacity (${targetMap.flashSize} bytes)."
            )
        }

        val sha256 = computeSha256(data)
        if (expectedSha256 != null && !expectedSha256.equals(sha256, ignoreCase = true)) {
            return ValidationResult(
                false,
                "SHA-256 Checksum mismatch! Expected: $expectedSha256, Got: $sha256",
                sha256Hex = sha256
            )
        }

        if (targetMap.isArmCortex) {
            if (data.size < 8) {
                return ValidationResult(false, "Binary too small for ARM Cortex vector table (${data.size} bytes).")
            }

            val buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            val sp = buf.int.toLong() and 0xFFFFFFFFL
            val pc = buf.int.toLong() and 0xFFFFFFFFL

            // Stack Pointer Check: must be within target MCU SRAM boundary and 4-byte aligned
            val ramEnd = targetMap.ramBase + targetMap.ramSize
            val isSpValid = (sp >= targetMap.ramBase && sp <= ramEnd && (sp % 4L == 0L))
            if (!isSpValid) {
                return ValidationResult(
                    false,
                    "CORRUPT ARM BINARY: Initial SP (0x%08X) outside target SRAM range [0x%08X..0x%08X].".format(
                        sp, targetMap.ramBase, ramEnd
                    ),
                    sp, pc, sha256
                )
            }

            // Reset Vector Check: must point inside target Flash ROM range and have Thumb bit (bit 0 = 1)
            val flashEnd = targetMap.flashBase + targetMap.flashSize
            val isPcValid = (pc >= targetMap.flashBase && pc < flashEnd && (pc and 1L != 0L))
            if (!isPcValid) {
                return ValidationResult(
                    false,
                    "CORRUPT ARM BINARY: Reset PC (0x%08X) outside target Flash range [0x%08X..0x%08X] or missing Thumb bit.".format(
                        pc, targetMap.flashBase, flashEnd
                    ),
                    sp, pc, sha256
                )
            }

            return ValidationResult(true, "ARM Vector Table Verified: SP=0x%08X, PC=0x%08X".format(sp, pc), sp, pc, sha256)
        }

        return ValidationResult(true, "Firmware image validated for ${targetMap.displayName}.", sha256Hex = sha256)
    }
}

/**
 * Formal Flashing State Machine.
 */
enum class FlashingState {
    IDLE,
    CONNECTING,
    VALIDATING,
    UNLOCKING,
    ERASING,
    PROGRAMMING,
    VERIFYING,
    LOCKING,
    SUCCESS,
    FAILED,
    CANCELLED
}

class FlashingStateMachine {
    @Volatile
    var currentState: FlashingState = FlashingState.IDLE
        private set

    @Volatile
    var lastError: String = ""
        private set

    @Synchronized
    fun startFlashing(): Boolean {
        if (currentState != FlashingState.IDLE &&
            currentState != FlashingState.SUCCESS &&
            currentState != FlashingState.FAILED &&
            currentState != FlashingState.CANCELLED) {
            return false // Flashing already in progress!
        }
        currentState = FlashingState.CONNECTING
        lastError = ""
        return true
    }

    @Synchronized
    fun transitionTo(newState: FlashingState) {
        currentState = newState
    }

    @Synchronized
    fun fail(error: String) {
        lastError = error
        currentState = FlashingState.FAILED
    }

    @Synchronized
    fun cancel() {
        currentState = FlashingState.CANCELLED
    }

    @Synchronized
    fun reset() {
        currentState = FlashingState.IDLE
        lastError = ""
    }

    val isActive: Boolean
        get() = currentState != FlashingState.IDLE &&
                currentState != FlashingState.SUCCESS &&
                currentState != FlashingState.FAILED &&
                currentState != FlashingState.CANCELLED
}

/**
 * Fail-Safe Hardware Interlock Engine.
 */
object SafetyInterlockEngine {
    enum class MachineStatus {
        STOPPED,
        RUNNING,
        DISCONNECTED,
        UNKNOWN
    }

    fun evaluateFlashingSafety(
        machineStatus: MachineStatus,
        measuredRpm: Int
    ): Pair<Boolean, String> {
        if (machineStatus == MachineStatus.RUNNING || measuredRpm > 0) {
            return Pair(false, "SAFETY INTERLOCK ENGAGED: Machine spindle is actively rotating ($measuredRpm RPM). Flashing strictly blocked to prevent mechanical and driver damage.")
        }
        if (machineStatus == MachineStatus.UNKNOWN) {
            return Pair(false, "SAFETY INTERLOCK ENGAGED: Machine telemetry status is UNKNOWN. Flashing blocked until state is verified.")
        }
        if (machineStatus == MachineStatus.DISCONNECTED) {
            return Pair(false, "SAFETY INTERLOCK ENGAGED: Machine sensor telemetry is DISCONNECTED. Flashing blocked.")
        }
        return Pair(true, "Machine stationary (0 RPM) & telemetry verified safe.")
    }
}
