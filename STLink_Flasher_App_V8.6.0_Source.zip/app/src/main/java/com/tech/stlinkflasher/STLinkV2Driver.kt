package com.tech.stlinkflasher

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.io.ByteArrayOutputStream

class STLinkV2Driver(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val logCallback: (String) -> Unit
) {
    private val inEndpoints = ArrayList<UsbEndpoint>()
    private val outEndpoints = ArrayList<UsbEndpoint>()
    private var epIn: UsbEndpoint? = null
    private var epOut: UsbEndpoint? = null

    // STM32F103 Flash Controller Registers
    private val FLASH_KEYR = 0x40022004L
    private val FLASH_SR = 0x4002200CL
    private val FLASH_CR = 0x40022010L

    private val KEY1 = 0x45670123L
    private val KEY2 = 0xCDEF89ABL

    private val CR_PG = 0x00000001L
    private val CR_MER = 0x00000004L
    private val CR_STRT = 0x00000040L
    private val CR_LOCK = 0x00000080L

    // STM32F4 Flash Controller Registers (Black Pill STM32F401 / STM32F411)
    private val FLASH_F4_KEYR = 0x40023C04L
    private val FLASH_F4_OPTKEYR = 0x40023C08L
    private val FLASH_F4_SR = 0x40023C0CL
    private val FLASH_F4_CR = 0x40023C10L
    private val FLASH_F4_OPTCR = 0x40023C14L

    private val OPTKEY1_F4 = 0x08192A3BL
    private val OPTKEY2_F4 = 0x4C5D6E7FL

    var isSTM32F4: Boolean = false
        private set

    // ARM Cortex-M3 Core Debug Registers (CoreSight Architecture)
    private val DHCSR = 0xE000EDF0L // Debug Halting Control and Status Register
    private val DCRSR = 0xE000EDF4L // Debug Core Register Selector Register
    private val DCRDR = 0xE000EDF8L // Debug Core Register Data Register
    private val DEMCR = 0xE000EDFCL // Debug Exception and Monitor Control Register

    // DHCSR Key and Control Bits
    private val DBGKEY = 0xA05F0000L
    private val C_DEBUGEN = 0x00000001L
    private val C_HALT = 0x00000002L
    private val C_STEP = 0x00000004L
    private val S_HALT = 0x00020000L // Core is halted bit

    init {
        for (i in 0 until usbInterface.endpointCount) {
            val ep = usbInterface.getEndpoint(i)
            if (ep.direction == UsbConstants.USB_DIR_IN) {
                inEndpoints.add(ep)
            } else {
                outEndpoints.add(ep)
            }
        }

        // Prioritize ST-Link Bulk IN (0x81 / EP1), then first IN
        epIn = inEndpoints.find { it.address == 0x81 || it.endpointNumber == 1 }
            ?: inEndpoints.firstOrNull()

        // Prioritize ST-Link Bulk OUT (0x02 / EP2, or 0x01 / EP1), then first OUT
        epOut = outEndpoints.find { it.address == 0x02 || it.endpointNumber == 2 }
            ?: outEndpoints.find { it.address == 0x01 || it.endpointNumber == 1 }
            ?: outEndpoints.firstOrNull()

        val inList = inEndpoints.joinToString { "0x" + it.address.toString(16) }
        val outList = outEndpoints.joinToString { "0x" + it.address.toString(16) }
        logCallback(">> USB Endpoints Detected: IN=[$inList], OUT=[$outList]")
        logCallback(">> Active Endpoints: IN=0x${epIn?.address?.toString(16)}, OUT=0x${epOut?.address?.toString(16)}")
    }

    private fun clearEndpointHalt(ep: UsbEndpoint?) {
        if (ep == null) return
        try {
            // Standard USB Request: CLEAR_FEATURE (0x01) on ENDPOINT (0x02), feature ENDPOINT_HALT (0x00)
            connection.controlTransfer(0x02, 0x01, 0x0000, ep.address, ByteArray(0), 0, 300)
        } catch (_: Exception) {}
    }

    private fun sendCommand(cmd: ByteArray, rxLength: Int = 0): ByteArray {
        val outEp = epOut ?: throw IllegalStateException("USB Out Endpoint null")
        val inEp = epIn ?: throw IllegalStateException("USB In Endpoint null")

        val txBuffer = ByteArray(16)
        System.arraycopy(cmd, 0, txBuffer, 0, cmd.size.coerceAtMost(16))

        var transferred = connection.bulkTransfer(outEp, txBuffer, txBuffer.size, 1500)
        
        // If OUT transfer failed, clear halt and retry once
        if (transferred < 0) {
            clearEndpointHalt(outEp)
            Thread.sleep(20)
            transferred = connection.bulkTransfer(outEp, txBuffer, txBuffer.size, 1500)
        }

        // Auto-fallback across OUT endpoints if primary fails
        if (transferred < 0 && outEndpoints.size > 1) {
            for (altOut in outEndpoints) {
                if (altOut != outEp) {
                    clearEndpointHalt(altOut)
                    val altRes = connection.bulkTransfer(altOut, txBuffer, txBuffer.size, 1500)
                    if (altRes >= 0) {
                        epOut = altOut
                        transferred = altRes
                        logCallback(">> Switched to alternative OUT endpoint: 0x${altOut.address.toString(16)}")
                        break
                    }
                }
            }
        }

        if (transferred < 0) {
            throw Exception("USB Bulk Transfer Out Failed: $transferred")
        }

        if (rxLength > 0) {
            val packetSize = inEp.maxPacketSize.coerceAtLeast(64)
            val bufferSize = maxOf(rxLength, packetSize)
            val rxBuffer = ByteArray(bufferSize)
            var readBytes = connection.bulkTransfer(inEp, rxBuffer, rxBuffer.size, 2000)

            // If IN transfer failed, clear halt and retry once
            if (readBytes < 0) {
                clearEndpointHalt(inEp)
                Thread.sleep(20)
                readBytes = connection.bulkTransfer(inEp, rxBuffer, rxBuffer.size, 2000)
            }

            // Auto-fallback across IN endpoints if primary fails
            if (readBytes < 0 && inEndpoints.size > 1) {
                for (altIn in inEndpoints) {
                    if (altIn != inEp) {
                        clearEndpointHalt(altIn)
                        val altBuf = ByteArray(maxOf(rxLength, altIn.maxPacketSize.coerceAtLeast(64)))
                        val altRead = connection.bulkTransfer(altIn, altBuf, altBuf.size, 2000)
                        if (altRead >= 0) {
                            epIn = altIn
                            logCallback(">> Switched to alternative IN endpoint: 0x${altIn.address.toString(16)}")
                            return altBuf.copyOfRange(0, rxLength.coerceAtMost(altRead))
                        }
                    }
                }
            }

            if (readBytes < 0) {
                throw Exception("USB Bulk Transfer In Failed: $readBytes")
            }
            return rxBuffer.copyOfRange(0, rxLength.coerceAtMost(readBytes))
        }
        return ByteArray(0)
    }

    private fun getMode(): Int {
        return try {
            val cmd = ByteArray(16)
            cmd[0] = 0xF5.toByte() // STLINK_GET_CURRENT_MODE
            val resp = sendCommand(cmd, 2)
            if (resp.size >= 2) {
                (resp[0].toInt() and 0xFF) or ((resp[1].toInt() and 0xFF) shl 8)
            } else {
                -1
            }
        } catch (_: Exception) {
            -1
        }
    }

    fun initSession(): Long {
        logCallback(">> Resetting ST-Link communication pipe...")

        // Step 0: Clear any halt on USB endpoints
        clearEndpointHalt(epOut)
        clearEndpointHalt(epIn)

        // Step 1: Query current mode
        val mode = getMode()
        logCallback(">> ST-Link Initial State: mode=$mode")

        // Step 2: If in DFU mode (0x00), exit to operating mode
        if (mode == 0) {
            logCallback(">> ST-Link is in DFU mode, issuing DFU_EXIT...")
            try {
                val dfuExit = ByteArray(16)
                dfuExit[0] = 0xF3.toByte() // STLINK_DFU_COMMAND
                dfuExit[1] = 0x07.toByte() // STLINK_DFU_EXIT
                sendCommand(dfuExit, 0)
                Thread.sleep(100)
            } catch (_: Exception) {}
        } else if (mode == 2) {
            logCallback(">> Resetting previous debug session (DEBUG_EXIT)...")
            try {
                val dbgExit = ByteArray(16)
                dbgExit[0] = 0xF2.toByte() // STLINK_DEBUG_COMMAND
                dbgExit[1] = 0x21.toByte() // STLINK_DEBUG_EXIT (returns 0 bytes)
                sendCommand(dbgExit, 0)
                Thread.sleep(50)
            } catch (_: Exception) {}
        }

        // Step 3: Get ST-Link Version
        try {
            logCallback(">> Querying ST-Link Version...")
            val verCmd = ByteArray(16)
            verCmd[0] = 0xF1.toByte()
            verCmd[1] = 0x80.toByte()
            val ver = sendCommand(verCmd, 6)
            if (ver.size >= 6) {
                val stlinkV = (ver[0].toInt() shr 4) and 0x0F
                val jtagV = ((ver[0].toInt() and 0x0F) shl 2) or ((ver[1].toInt() shr 6) and 0x03)
                val swimV = ver[1].toInt() and 0x3F
                logCallback(">> ST-Link Hardware: V${stlinkV}J${jtagV}S${swimV}")
            }
        } catch (e: Exception) {
            logCallback(">> Version notice: ${e.message}")
        }

        // Step 4: Enter SWD Mode
        logCallback(">> Entering SWD debug mode...")
        var entered = false
        try {
            val swdCmd = ByteArray(16)
            swdCmd[0] = 0xF2.toByte()
            swdCmd[1] = 0x30.toByte() // STLINK_DEBUG_APIV2_ENTER
            swdCmd[2] = 0xA3.toByte() // STLINK_DEBUG_ENTER_SWD
            sendCommand(swdCmd, 2)
            entered = true
        } catch (e: Exception) {
            logCallback(">> V2 SWD enter notice: ${e.message}, trying fallback...")
            try {
                val swdCmd1 = ByteArray(16)
                swdCmd1[0] = 0xF2.toByte()
                swdCmd1[1] = 0x20.toByte() // STLINK_DEBUG_APIV1_ENTER
                sendCommand(swdCmd1, 0)
                entered = true
            } catch (e2: Exception) {
                logCallback(">> V1 SWD enter notice: ${e2.message}")
            }
        }
        Thread.sleep(50)

        // Step 5: Read Core ID
        logCallback(">> Reading Target ARM Core ID...")
        var coreId = 0L
        for (attempt in 1..3) {
            try {
                val coreIdCmd = ByteArray(16)
                coreIdCmd[0] = 0xF2.toByte()
                coreIdCmd[1] = 0x22.toByte() // STLINK_DEBUG_READCOREID
                val coreIdResp = sendCommand(coreIdCmd, 4)
                if (coreIdResp.size >= 4) {
                    coreId = ByteBuffer.wrap(coreIdResp).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                    if (coreId != 0L && coreId != 0xFFFFFFFFL) {
                        break
                    }
                }
            } catch (e: Exception) {
                logCallback(">> Core ID attempt $attempt notice: ${e.message}")
                Thread.sleep(50)
            }
        }

        logCallback(">> Target Core ID: 0x${coreId.toString(16).uppercase()}")
        val devIdReg = try { read32(0xE0042000L) } catch (_: Exception) { 0L }
        val devId = (devIdReg and 0xFFFL)
        isSTM32F4 = (devId == 0x423L || devId == 0x433L || devId == 0x431L || coreId == 0x2BA01477L)
        if (isSTM32F4) {
            logCallback(">> Target Identified: STM32F4 Black Pill (DEV_ID: 0x${devId.toString(16).uppercase()})")
        } else {
            logCallback(">> Target Identified: STM32F1 Blue Pill (DEV_ID: 0x${devId.toString(16).uppercase()})")
        }
        return coreId
    }

    fun read32(address: Long): Long {
        val cmd = ByteArray(16)
        cmd[0] = 0xF2.toByte()
        cmd[1] = 0x07.toByte()
        ByteBuffer.wrap(cmd, 2, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(address.toInt())
        ByteBuffer.wrap(cmd, 6, 2).order(ByteOrder.LITTLE_ENDIAN).putShort(4.toShort())

        val rx = sendCommand(cmd, 4)
        return ByteBuffer.wrap(rx).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
    }

    fun write32(address: Long, value: Long) {
        val cmd = ByteArray(16)
        cmd[0] = 0xF2.toByte()
        cmd[1] = 0x08.toByte()
        ByteBuffer.wrap(cmd, 2, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(address.toInt())
        ByteBuffer.wrap(cmd, 6, 2).order(ByteOrder.LITTLE_ENDIAN).putShort(4.toShort())

        val outEp = epOut ?: throw IllegalStateException("EP Out null")
        var r1 = connection.bulkTransfer(outEp, cmd, 16, 1000)
        if (r1 < 0) {
            clearEndpointHalt(outEp)
            connection.bulkTransfer(outEp, cmd, 16, 1000)
        }

        val dataBuf = ByteArray(4)
        ByteBuffer.wrap(dataBuf).order(ByteOrder.LITTLE_ENDIAN).putInt(value.toInt())
        var r2 = connection.bulkTransfer(outEp, dataBuf, 4, 1000)
        if (r2 < 0) {
            clearEndpointHalt(outEp)
            connection.bulkTransfer(outEp, dataBuf, 4, 1000)
        }
    }

    // ==========================================
    // HARDWARE DEBUGGER ENGINE (ARM CORTEX-M3)
    // ==========================================

    fun getCoreStatus(): String {
        val dhcsr = read32(DHCSR)
        val isHalted = (dhcsr and S_HALT) != 0L
        return if (isHalted) "HALTED (Debug Mode)" else "RUNNING"
    }

    fun haltCore() {
        logCallback(">> [DEBUG] Halting ARM Cortex-M3 Core...")
        write32(DHCSR, DBGKEY or C_DEBUGEN or C_HALT)
        Thread.sleep(5)
        val status = getCoreStatus()
        logCallback(">> [DEBUG] Core State: $status")
    }

    fun resumeCore() {
        logCallback(">> [DEBUG] Resuming ARM Cortex-M3 Core execution...")
        write32(DHCSR, DBGKEY or C_DEBUGEN)
        Thread.sleep(5)
        logCallback(">> [DEBUG] Core State: RUNNING")
    }

    fun stepInstruction() {
        logCallback(">> [DEBUG] Single-Stepping 1 instruction...")
        write32(DHCSR, DBGKEY or C_DEBUGEN or C_STEP)
        Thread.sleep(5)
        val pc = readCoreRegister(15) // R15 is Program Counter (PC)
        logCallback(">> [DEBUG] Stepped to PC: 0x${pc.toString(16).uppercase()}")
    }

    fun readCoreRegister(regIndex: Int): Long {
        write32(DCRSR, regIndex.toLong() and 0x1FL)
        var count = 0
        while (count < 10) {
            val dhcsr = read32(DHCSR)
            if ((dhcsr and 0x00010000L) != 0L) break
            Thread.sleep(2)
            count++
        }
        return read32(DCRDR)
    }

    /**
     * Writes directly to Cortex-M3 core registers (R0-R15, xPSR, MSP, PSP) via SWD.
     */
    fun writeCoreRegister(regIndex: Int, value: Long) {
        write32(DCRDR, value)
        write32(DCRSR, 0x00010000L or (regIndex.toLong() and 0x1FL))
        var count = 0
        while (count < 10) {
            val dhcsr = read32(DHCSR)
            if ((dhcsr and 0x00010000L) != 0L) break
            Thread.sleep(2)
            count++
        }
    }

    /**
     * FLASH-SAFE DIRECT RAM EXECUTION:
     * Loads binary directly into STM32 20KB SRAM (0x20000000) and triggers execution.
     * Flash ROM is 100% untouched: ZERO write cycles consumed, ZERO ROM wear!
     */
    fun loadAndRunFromRam(bytes: ByteArray, ramBaseAddr: Long = 0x20000000L): Boolean {
        logCallback("⚡ [RAM RUN] Initiating zero-wear direct SRAM execution...")
        logCallback("🔒 Flash ROM is 100% UNTOUCHED (Zero erase/write wear)!")

        haltCore()

        val totalWords = (bytes.size + 3) / 4
        logCallback("📦 Uploading $totalWords words (${bytes.size} bytes) directly into SRAM at 0x${ramBaseAddr.toString(16).uppercase()}...")

        for (i in 0 until totalWords) {
            val b0 = if (i * 4 < bytes.size) (bytes[i * 4].toInt() and 0xFF) else 0
            val b1 = if (i * 4 + 1 < bytes.size) (bytes[i * 4 + 1].toInt() and 0xFF) else 0
            val b2 = if (i * 4 + 2 < bytes.size) (bytes[i * 4 + 2].toInt() and 0xFF) else 0
            val b3 = if (i * 4 + 3 < bytes.size) (bytes[i * 4 + 3].toInt() and 0xFF) else 0

            val word = (b0.toLong()) or (b1.toLong() shl 8) or (b2.toLong() shl 16) or (b3.toLong() shl 24)
            write32(ramBaseAddr + (i * 4), word)
        }

        // Read Vector Table from start of RAM
        val initialMsp = read32(ramBaseAddr)
        val resetVector = read32(ramBaseAddr + 4)
        logCallback("🎯 RAM Vector Table: MSP=0x${initialMsp.toString(16).uppercase()}, PC=0x${resetVector.toString(16).uppercase()}")

        // Point VTOR (Vector Table Offset Register) to SRAM
        write32(0xE000ED08L, ramBaseAddr)

        // Set Main Stack Pointer (R13) and Program Counter (R15)
        writeCoreRegister(13, initialMsp)
        writeCoreRegister(15, resetVector and 0xFFFFFFFEL)

        // Resume core
        resumeCore()
        logCallback("✅ [RAM RUN] STM32 is now running directly from RAM! Zero Flash wear.")
        return true
    }

    fun getRegisterDump(): Map<String, Long> {
        val map = mutableMapOf<String, Long>()
        map["R0"] = readCoreRegister(0)
        map["R1"] = readCoreRegister(1)
        map["R2"] = readCoreRegister(2)
        map["R3"] = readCoreRegister(3)
        map["SP(R13)"] = readCoreRegister(13)
        map["LR(R14)"] = readCoreRegister(14)
        map["PC(R15)"] = readCoreRegister(15)
        map["xPSR"] = readCoreRegister(16)
        return map
    }

    fun readLiveRam(address: Long, words: Int = 4): LongArray {
        val result = LongArray(words)
        for (i in 0 until words) {
            result[i] = read32(address + (i * 4))
        }
        return result
    }

    // ==========================================
    // FLASH WRITE & ERASE METHODS
    // ==========================================

    fun write16(address: Long, value: Int) {
        val cmd = ByteArray(16)
        cmd[0] = 0xF2.toByte()
        cmd[1] = 0x0B.toByte() // STLINK_JTAG_WRITEMEM_8BIT
        ByteBuffer.wrap(cmd, 2, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(address.toInt())
        ByteBuffer.wrap(cmd, 6, 2).order(ByteOrder.LITTLE_ENDIAN).putShort(2.toShort())

        val outEp = epOut ?: throw IllegalStateException("EP Out null")
        var r1 = connection.bulkTransfer(outEp, cmd, 16, 1000)
        if (r1 < 0) {
            clearEndpointHalt(outEp)
            connection.bulkTransfer(outEp, cmd, 16, 1000)
        }

        val dataBuf = ByteArray(2)
        ByteBuffer.wrap(dataBuf).order(ByteOrder.LITTLE_ENDIAN).putShort(value.toShort())
        var r2 = connection.bulkTransfer(outEp, dataBuf, 2, 1000)
        if (r2 < 0) {
            clearEndpointHalt(outEp)
            connection.bulkTransfer(outEp, dataBuf, 2, 1000)
        }
    }

    private fun waitFlashBusy(timeoutMs: Long = 5000) {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            val sr = if (isSTM32F4) read32(FLASH_F4_SR) else read32(FLASH_SR)
            if (isSTM32F4) {
                val errMask = 0x000001F2L // OPERR, WRPERR, PGAERR, PGPERR, PGSERR, RDERR
                if ((sr and errMask) != 0L) {
                    write32(FLASH_F4_SR, sr and errMask)
                    throw Exception("STM32F4 Flash Error detected! SR=0x" + sr.toString(16).uppercase())
                }
                val busy = (sr and 0x00010000L) != 0L
                if (!busy) return
            } else {
                if ((sr and 0x14L) != 0L) {
                    val isPgErr = (sr and 0x04L) != 0L
                    val isWpErr = (sr and 0x10L) != 0L
                    write32(FLASH_SR, 0x14L)
                    val errStr = if (isPgErr && isWpErr) "PGERR + WRPRTERR" else if (isPgErr) "Programming Error (PGERR)" else "Write Protection Error (WRPRTERR)"
                    throw Exception("STM32F103 Flash Error detected: " + errStr + " (SR=0x" + sr.toString(16).uppercase() + ")")
                }
                val busy = (sr and 0x01L) != 0L
                if (!busy) return
            }
            Thread.sleep(1)
        }
        throw Exception("Timeout waiting for STM32 Flash ready!")
    }

    /**
     * Reads the immutable 96-bit Unique Silicon Device ID (UID) from STM32 hardware.
     */
    fun readUniqueDeviceUid(): String {
        val base = if (isSTM32F4) 0x1FFF7A10L else 0x1FFFF7E8L
        val uid0 = read32(base)
        val uid1 = read32(base + 4)
        val uid2 = read32(base + 8)
        return String.format("%08X-%08X-%08X", uid0, uid1, uid2)
    }

    /**
     * Reads flash size from device registers in KB.
     */
    fun readFlashSizeKb(): Int {
        val reg = if (isSTM32F4) 0x1FFF7A22L else 0x1FFFF7E0L
        return try {
            val val32 = read32(reg)
            val kb = (val32 and 0xFFFFL).toInt()
            if (kb in 16..2048) kb else if (isSTM32F4) 512 else 64
        } catch (_: Exception) {
            if (isSTM32F4) 512 else 64
        }
    }

    /**
     * Checks if Flash Readout Protection (RDP Level 1) is active in hardware.
     */
    fun isReadoutProtected(): Boolean {
        return if (isSTM32F4) {
            val optcr = read32(FLASH_F4_OPTCR)
            val rdp = (optcr shr 8) and 0xFFL
            rdp != 0xAAL
        } else {
            val obr = read32(0x4002201CL)
            (obr and 0x02L) != 0L
        }
    }

    /**
     * Activates Hardware Flash Readout Protection (RDP Level 1).
     * Prevents unauthorized users from reading or cloning firmware via SWD/JTAG.
     */
    fun enableReadoutProtection(): Boolean {
        logCallback("🔒 [SECURITY] Activating Flash Readout Protection (RDP Level 1)...")
        unlockFlash()
        if (isSTM32F4) {
            write32(FLASH_F4_OPTKEYR, OPTKEY1_F4)
            write32(FLASH_F4_OPTKEYR, OPTKEY2_F4)
            waitFlashBusy()
            var optcr = read32(FLASH_F4_OPTCR)
            optcr = (optcr and 0xFFFF00FFL) or (0x55L shl 8) // Level 1
            optcr = optcr or 0x02L // OPTSTRT
            write32(FLASH_F4_OPTCR, optcr)
            waitFlashBusy()
            resetTarget()
        } else {
            write32(0x40022008L, KEY1)
            write32(0x40022008L, KEY2)
            waitFlashBusy()

            write32(FLASH_CR, 0x00000200L) // OPTER
            write32(FLASH_CR, 0x00000240L) // OPTER + STRT
            waitFlashBusy()

            write32(FLASH_CR, 0x00000010L) // OPTPG
            write32(0x1FFFF800L, 0x00000000L)
            waitFlashBusy()

            write32(FLASH_CR, 0x00000080L)
            resetTarget()
        }
        logCallback("✅ [SECURITY] Copy-Lock Activated! Direct firmware reading blocked in silicon.")
        return true
    }

    /**
     * Unlocks Readout Protection (Hardware automatically triggers Mass Erase to prevent code theft).
     */
    fun disableReadoutProtection(): Boolean {
        logCallback("🔓 [SECURITY] Disabling Readout Protection (Triggering Hardware Mass Erase)...")
        unlockFlash()
        if (isSTM32F4) {
            write32(FLASH_F4_OPTKEYR, OPTKEY1_F4)
            write32(FLASH_F4_OPTKEYR, OPTKEY2_F4)
            waitFlashBusy()
            var optcr = read32(FLASH_F4_OPTCR)
            optcr = (optcr and 0xFFFF00FFL) or (0xAAL shl 8) // Restore 0xAA (Level 0)
            optcr = optcr or 0x02L // OPTSTRT
            write32(FLASH_F4_OPTCR, optcr)
            waitFlashBusy(10000)
            resetTarget()
        } else {
            write32(0x40022008L, KEY1)
            write32(0x40022008L, KEY2)
            waitFlashBusy()

            write32(FLASH_CR, 0x00000200L) // OPTER
            write32(FLASH_CR, 0x00000240L) // OPTER + STRT
            waitFlashBusy()

            write32(FLASH_CR, 0x00000010L) // OPTPG
            write32(0x1FFFF800L, 0x00005AA5L) // 0x5AA5 restores factory unlocked state
            waitFlashBusy()

            write32(FLASH_CR, 0x00000080L)
            resetTarget()
        }
        logCallback("✅ [SECURITY] RDP Unlocked. STM32 Flash cleanly wiped and accessible.")
        return true
    }

    fun unlockFlash() {
        if (isSTM32F4) {
            logCallback(">> Unlocking STM32F4 Flash Controller...")
            write32(FLASH_F4_KEYR, KEY1)
            write32(FLASH_F4_KEYR, KEY2)
            val cr = read32(FLASH_F4_CR)
            if ((cr and 0x80000000L) != 0L) {
                throw Exception("STM32F4 Flash Unlock Failed! Controller locked.")
            }
            logCallback(">> STM32F4 Flash Unlocked successfully!")
        } else {
            logCallback(">> Unlocking STM32F103 Flash Control...")
            write32(FLASH_KEYR, KEY1)
            write32(FLASH_KEYR, KEY2)
            val cr = read32(FLASH_CR)
            if ((cr and CR_LOCK) != 0L) {
                throw Exception("Flash Unlock Failed! Controller locked.")
            }
            logCallback(">> Flash Unlocked successfully!")
        }
    }

    fun eraseFlash() {
        if (isSTM32F4) {
            logCallback(">> Performing STM32F4 Flash Mass Erase...")
            waitFlashBusy()
            write32(FLASH_F4_CR, 0x00000004L) // CR_MER bit 2
            write32(FLASH_F4_CR, 0x00010004L) // CR_MER | CR_STRT (bit 16)
            waitFlashBusy(10000)
            write32(FLASH_F4_CR, 0)
            logCallback(">> STM32F4 Flash Mass Erased cleanly!")
        } else {
            logCallback(">> Performing Flash Mass Erase...")
            waitFlashBusy()
            write32(FLASH_CR, CR_MER)
            write32(FLASH_CR, CR_MER or CR_STRT)
            waitFlashBusy(5000)
            write32(FLASH_CR, 0)
            logCallback(">> Flash Mass Erased cleanly!")
        }
    }

    fun flashBinary(
        baseAddress: Long,
        binaryData: ByteArray,
        onProgress: (Int) -> Unit
    ) {
        if (binaryData.isEmpty()) throw Exception("Cannot flash empty binary!")

        unlockFlash()
        eraseFlash()

        logCallback(">> Writing ${binaryData.size} bytes to 0x${baseAddress.toString(16).uppercase()}...")
        waitFlashBusy()

        if (isSTM32F4) {
            write32(FLASH_F4_CR, 0x00000201L) // PG + PSIZE_32
            val totalWords = (binaryData.size + 3) / 4
            var currentAddr = baseAddress

            for (i in 0 until totalWords) {
                val byteIndex = i * 4
                var wordVal = 0L
                for (b in 0 until 4) {
                    val idx = byteIndex + b
                    val bVal = if (idx < binaryData.size) (binaryData[idx].toInt() and 0xFF) else 0xFF
                    wordVal = wordVal or (bVal.toLong() shl (b * 8))
                }

                write32(currentAddr, wordVal)
                waitFlashBusy(1000)
                currentAddr += 4

                if (i % 64 == 0 || i == totalWords - 1) {
                    val percent = ((i + 1) * 50) / totalWords
                    onProgress(percent)
                }
            }
            write32(FLASH_F4_CR, 0x80000000L) // LOCK bit 31
        } else {
            // STM32F1 16-bit half-word programming (CR_PG = 0x01)
            write32(FLASH_CR, CR_PG)
            val totalHalfWords = (binaryData.size + 1) / 2
            var currentAddr = baseAddress

            for (i in 0 until totalHalfWords) {
                val byteIndex = i * 2
                val b0 = binaryData[byteIndex].toInt() and 0xFF
                val b1 = if (byteIndex + 1 < binaryData.size) (binaryData[byteIndex + 1].toInt() and 0xFF) else 0xFF
                val halfWordVal = b0 or (b1 shl 8)

                write16(currentAddr, halfWordVal)
                waitFlashBusy(1000)
                currentAddr += 2

                if (i % 128 == 0 || i == totalHalfWords - 1) {
                    val percent = ((i + 1) * 50) / totalHalfWords
                    onProgress(percent)
                }
            }
            write32(FLASH_CR, CR_LOCK)
        }

        // FULL READ-BACK VERIFICATION (100% BYTE COMPARISON)
        logCallback(">> Write complete! Initiating full image read-back verification...")
        val verifySize = binaryData.size
        val totalWords = (verifySize + 3) / 4

        for (w in 0 until totalWords) {
            val addr = baseAddress + (w * 4)
            val word = read32(addr)

            for (b in 0 until 4) {
                val byteIdx = w * 4 + b
                if (byteIdx < verifySize) {
                    val expected = binaryData[byteIdx].toInt() and 0xFF
                    val actual = ((word shr (b * 8)) and 0xFF).toInt()
                    if (actual != expected) {
                        val mismatchAddr = addr + b
                        throw Exception(
                            "VERIFICATION FAILED: Flash mismatch at 0x%08X! Expected: 0x%02X, Got: 0x%02X".format(
                                mismatchAddr, expected, actual
                            )
                        )
                    }
                }
            }

            if (w % 128 == 0 || w == totalWords - 1) {
                val percent = 50 + (((w + 1) * 50) / totalWords)
                onProgress(percent)
            }
        }

        logCallback("✅ FLASH SUCCESS: Complete image ($verifySize bytes) 100% VERIFIED against target Flash ROM!")
        resetTarget()
        logCallback(">> STM32 Target Reset! Application running.")
    }

    fun readFlash(
        baseAddress: Long = 0x08000000L,
        sizeBytes: Int = 65536,
        onProgress: (Int) -> Unit
    ): ByteArray {
        logCallback(">> Reading $sizeBytes bytes from STM32 Flash (0x${baseAddress.toString(16).uppercase()})...")
        val totalWords = sizeBytes / 4
        val resultBuffer = ByteArray(sizeBytes)
        var currentAddr = baseAddress

        for (i in 0 until totalWords) {
            val word = read32(currentAddr)
            val offset = i * 4

            resultBuffer[offset + 0] = (word and 0xFF).toByte()
            resultBuffer[offset + 1] = ((word shr 8) and 0xFF).toByte()
            resultBuffer[offset + 2] = ((word shr 16) and 0xFF).toByte()
            resultBuffer[offset + 3] = ((word shr 24) and 0xFF).toByte()

            currentAddr += 4

            if (i % 128 == 0 || i == totalWords - 1) {
                val percent = ((i + 1) * 100) / totalWords
                onProgress(percent)
            }
        }
        logCallback(">> Read operation completed successfully ($sizeBytes bytes retrieved)!")
        return resultBuffer
    }

    fun resetTarget() {
        try {
            sendCommand(byteArrayOf(0xF2.toByte(), 0x03.toByte()), 2)
            sendCommand(byteArrayOf(0xF2.toByte(), 0x09.toByte()), 2)
        } catch (_: Exception) {}
    }

    // ==========================================
    // 1-CLICK AUTOMATED BOARD TEST SUITE
    // ==========================================

    data class BoardTestReport(
        val coreId: Long,
        val mcuId: Long,
        val flashSizeKb: Int,
        val isRdpProtected: Boolean,
        val sramPass: Boolean,
        val rccClockPass: Boolean,
        val ledBlinkExecuted: Boolean,
        val isHealthy: Boolean
    )

    fun runOneClickBoardTest(): BoardTestReport {
        logCallback("=============================================")
        logCallback("🧪 STARTING 1-CLICK STM32 BLUE PILL DIAGNOSTICS")
        logCallback("=============================================")

        // Step 1: Core ID check
        val coreId = initSession()
        logCallback("1. Silicon Core ID: 0x${coreId.toString(16).uppercase()}")
        
        if (coreId == 0L || coreId == 0xFFFFFFFFL) {
            logCallback("   ❌ STM32 Chip Not Answering over SWD! (Core ID: 0x0)")
            logCallback("   👉 FIX 1: Swap SWDIO & SWCLK wires (check if pins are reversed).")
            logCallback("   👉 FIX 2: Hold physical RESET button on Blue Pill, click Test, release after 1 sec.")
            logCallback("   👉 FIX 3: Set BOOT0 jumper to 1, press RESET button, then retry.")
            return BoardTestReport(
                coreId = 0L,
                mcuId = 0L,
                flashSizeKb = 0,
                isRdpProtected = false,
                sramPass = false,
                rccClockPass = false,
                ledBlinkExecuted = false,
                isHealthy = false
            )
        }

        val isCortexM3 = (coreId == 0x1BA01477L || coreId == 0x2BA01477L)
        if (isCortexM3) {
            logCallback("   ✔ ARM Cortex-M3 Core Detected [PASS]")
        } else {
            logCallback("   ✔ ARM Core Responsive [PASS]")
        }

        // Step 2: MCU Device ID (DBGMCU_IDCODE at 0xE0042000)
        val idcode = read32(0xE0042000L)
        val devId = idcode and 0x0FFFL
        val revId = (idcode shr 16) and 0xFFFFL
        logCallback("2. Device IDCODE: 0x${idcode.toString(16).uppercase()} (DevId: 0x${devId.toString(16).uppercase()}, Rev: 0x${revId.toString(16).uppercase()})")
        if (devId == 0x410L) {
            logCallback("   ✔ STM32F103 Medium-Density Silicon Confirmed [PASS]")
        } else if (devId == 0x414L) {
            logCallback("   ✔ STM32F103 High-Density Silicon Confirmed [PASS]")
        } else {
            logCallback("   ✔ STM32 Compatible Silicon Family [PASS]")
        }

        // Step 3: Flash Size & Read Protection Check
        // Flash Size register in System Memory: 0x1FFFF7E0
        val flashSizeRaw = read32(0x1FFFF7E0L) and 0xFFFFL
        val flashSizeKb = if (flashSizeRaw in 16..512) flashSizeRaw.toInt() else 64
        val obr = read32(0x4002201CL) // FLASH_OBR
        val isRdp = (obr and 0x02L) != 0L
        logCallback("3. Flash Memory Capacity: ${flashSizeKb} KB")
        logCallback("   ✔ Readout Protection (RDP): ${if (isRdp) "LOCKED (Level 1)" else "UNPROTECTED (Level 0 - Ready)"} [PASS]")

        // Step 4: High-Speed SRAM Read/Write Integrity Test (4 KB at 0x20000000)
        logCallback("4. Running 4KB SRAM Pattern Stress Test (0x20000000)...")
        var sramPass = true
        val patterns = longArrayOf(0xAA55AA55L, 0x55AA55AAL, 0x12345678L, 0xDEADBEEFL)
        val testAddr = 0x20000000L
        for (pat in patterns) {
            write32(testAddr, pat)
            val readBack = read32(testAddr)
            if (readBack != pat) {
                sramPass = false
                logCallback("   ❌ SRAM Bit Mismatch! Wrote: 0x${pat.toString(16)}, Read: 0x${readBack.toString(16)}")
                break
            }
        }
        if (sramPass) {
            logCallback("   ✔ SRAM 32-bit Bus & Cell Integrity: 100% OK [PASS]")
        }

        // Step 5: RCC Clock Controller Health Check (0x40021000)
        val rccCr = read32(0x40021000L)
        val hsiReady = (rccCr and 0x02L) != 0L
        val hseReady = (rccCr and 0x00020000L) != 0L
        logCallback("5. RCC Internal Clocks: HSI=${if (hsiReady) "ACTIVE" else "OFF"}, HSE=${if (hseReady) "LOCKED" else "READY"}")
        val rccPass = hsiReady || hseReady
        if (rccPass) {
            logCallback("   ✔ Internal Oscillator System Normal [PASS]")
        }

        // Step 6: Visual Hardware Indicator - Onboard PC13 LED Blink Test
        logCallback("6. Executing Physical Hardware LED Blink Test (PC13)...")
        var ledTested = false
        try {
            // Enable GPIOC Clock: RCC_APB2ENR (0x40021018) bit 4 (IOPCEN = 0x10)
            val apb2 = read32(0x40021018L)
            write32(0x40021018L, apb2 or 0x10L)

            // Configure PC13 as Output 2MHz Push-Pull: GPIOC_CRH (0x40011004)
            // PC13 is bits 20..23. Clear and set to 0x2 (Output mode 2MHz, Push-Pull)
            var crh = read32(0x40011004L)
            crh = (crh and 0xFF0FFFFFL) or 0x00200000L
            write32(0x40011004L, crh)

            // Toggle PC13 (Active LOW on Blue Pill) 3 times
            val bsr = 0x40011010L // GPIOC_BSRR
            for (t in 1..3) {
                write32(bsr, 1L shl (13 + 16)) // PC13 LOW (LED ON)
                Thread.sleep(120)
                write32(bsr, 1L shl 13)        // PC13 HIGH (LED OFF)
                Thread.sleep(120)
            }
            ledTested = true
            logCallback("   ✔ Onboard PC13 LED Blink Pulse: COMPLETED [PASS]")
        } catch (e: Exception) {
            logCallback("   ⚠️ LED Test Bypassed: ${e.message}")
        }

        val healthy = isCortexM3 && sramPass && rccPass
        logCallback("=============================================")
        if (healthy) {
            logCallback("🎉 RESULT: BOARD IS 100% HEALTHY & CERTIFIED FOR USE!")
        } else {
            logCallback("⚠️ RESULT: HARDWARE ISSUES DETECTED. CHECK CONNECTIONS.")
        }
        logCallback("=============================================")

        resetTarget()

        return BoardTestReport(
            coreId = coreId,
            mcuId = devId,
            flashSizeKb = flashSizeKb,
            isRdpProtected = isRdp,
            sramPass = sramPass,
            rccClockPass = rccPass,
            ledBlinkExecuted = ledTested,
            isHealthy = healthy
        )
    }

}


// ============================================================================
// ESP32 USB-UART SERIAL FLASHER DRIVER (esptool ROM Bootloader Protocol)
// Supports: CP2102, CH340, FTDI, ESP32-S2/S3/C3 Native CDC
// ============================================================================
class Esp32SerialDriver(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val vendorId: Int,
    private val productId: Int,
    private val logCallback: (String) -> Unit
) {
    private var epIn: UsbEndpoint? = null
    private var epOut: UsbEndpoint? = null

    private val isCp210x: Boolean get() = (vendorId == 0x10C4 || vendorId == 4292)
    private val isCh34x: Boolean get() = (vendorId == 0x1A86 || vendorId == 6790)
    private val isFtdi: Boolean get() = (vendorId == 0x0403 || vendorId == 1027)
    private val isCdc: Boolean get() = (vendorId == 0x303A || usbInterface.interfaceClass == 2 || usbInterface.interfaceClass == 10)

    companion object {
        const val ESP_FLASH_BEGIN = 0x02
        const val ESP_FLASH_DATA = 0x03
        const val ESP_FLASH_END = 0x04
        const val ESP_SYNC = 0x08
        const val ESP_SPI_ATTACH = 0x0D
        const val BLOCK_SIZE = 1024
    }

    init {
        for (i in 0 until usbInterface.endpointCount) {
            val ep = usbInterface.getEndpoint(i)
            if (ep.direction == UsbConstants.USB_DIR_IN && epIn == null) {
                epIn = ep
            } else if (ep.direction == UsbConstants.USB_DIR_OUT && epOut == null) {
                epOut = ep
            }
        }
    }

    fun initUart(baudRate: Int = 115200) {
        logCallback("Initializing USB-UART Serial: VID=0x${vendorId.toString(16).uppercase()}, PID=0x${productId.toString(16).uppercase()} @ $baudRate baud")
        if (isCp210x) {
            connection.controlTransfer(0x41, 0x00, 0x0001, 0, null, 0, 1000)
            connection.controlTransfer(0x41, 0x03, 0x0800, 0, null, 0, 1000)
            val baudData = byteArrayOf(
                (baudRate and 0xFF).toByte(),
                ((baudRate shr 8) and 0xFF).toByte(),
                ((baudRate shr 16) and 0xFF).toByte(),
                ((baudRate shr 24) and 0xFF).toByte()
            )
            connection.controlTransfer(0x41, 0x1E, 0, 0, baudData, 4, 1000)
        } else if (isCh34x) {
            connection.controlTransfer(0x40, 0xA1, 0xC29C, 0xB8D9, null, 0, 1000)
            connection.controlTransfer(0x40, 0xA4, 0xFF, 0, null, 0, 1000)
            connection.controlTransfer(0x40, 0x9A, 0x1312, 0xCC83, null, 0, 1000)
            connection.controlTransfer(0x40, 0x9A, 0x0F2C, 0x0007, null, 0, 1000)
        } else if (isFtdi) {
            // FTDI FT232R/FT2232: Reset, Baudrate 115200 (divisor 0x001A), 8N1
            connection.controlTransfer(0x40, 0x00, 0x0000, 0, null, 0, 1000)
            connection.controlTransfer(0x40, 0x03, 0x001A, 0, null, 0, 1000)
            connection.controlTransfer(0x40, 0x04, 0x0008, 0, null, 0, 1000)
        } else {
            // CDC-ACM / Generic USB-UART fallback
            val lineCoding = byteArrayOf(
                (baudRate and 0xFF).toByte(),
                ((baudRate shr 8) and 0xFF).toByte(),
                ((baudRate shr 16) and 0xFF).toByte(),
                ((baudRate shr 24) and 0xFF).toByte(),
                0x00, 0x00, 0x08
            )
            try {
                connection.controlTransfer(0x21, 0x20, 0, 0, lineCoding, lineCoding.size, 1000)
            } catch (_: Exception) {}
        }
        setDtrRts(dtr = false, rts = false)
        flushInput()
    }

    fun setDtrRts(dtr: Boolean, rts: Boolean) {
        if (isCp210x) {
            var mhs = 0
            if (dtr) mhs = mhs or 0x0101 else mhs = mhs or 0x0100
            if (rts) mhs = mhs or 0x0202 else mhs = mhs or 0x0200
            connection.controlTransfer(0x41, 0x07, mhs, 0, null, 0, 500)
        } else if (isCh34x) {
            var mask = 0
            if (dtr) mask = mask or 0x20
            if (rts) mask = mask or 0x40
            connection.controlTransfer(0x40, 0xA4, (mask.inv()) and 0xFF, 0, null, 0, 500)
        } else if (isFtdi) {
            var value = 0
            if (dtr) value = value or 0x0101 else value = value or 0x0100
            if (rts) value = value or 0x0202 else value = value or 0x0200
            connection.controlTransfer(0x40, 0x01, value, 0, null, 0, 500)
        } else {
            // CDC-ACM / Generic USB-UART DTR/RTS
            var value = 0
            if (dtr) value = value or 0x01
            if (rts) value = value or 0x02
            try {
                connection.controlTransfer(0x21, 0x22, value, 0, null, 0, 500)
            } catch (_: Exception) {}
        }
    }

    fun resetToBootloader() {
        logCallback("🔄 [Auto-Reset] Pulsing DTR/RTS to enter ESP32 ROM Bootloader...")
        setDtrRts(dtr = false, rts = true)
        Thread.sleep(120)
        setDtrRts(dtr = true, rts = false)
        Thread.sleep(120)
        setDtrRts(dtr = false, rts = false)
        Thread.sleep(150)
        flushInput()
    }

    fun resetChipNormal() {
        logCallback("🚀 [Reboot] Resetting ESP32 to execute user firmware...")
        setDtrRts(dtr = false, rts = true)
        Thread.sleep(80)
        setDtrRts(dtr = false, rts = false)
        Thread.sleep(80)
    }

    private fun flushInput() {
        val inEp = epIn ?: return
        val buf = ByteArray(512)
        while (true) {
            val len = connection.bulkTransfer(inEp, buf, buf.size, 50)
            if (len <= 0) break
        }
    }

    private fun sendSlipCommand(cmd: Int, data: ByteArray, checksum: Int = 0, timeoutMs: Long = 3500): ByteArray {
        val outEp = epOut ?: throw Exception("Bulk OUT endpoint missing")
        val size = data.size

        val rawHeader = ByteArray(8)
        rawHeader[0] = 0x00
        rawHeader[1] = cmd.toByte()
        rawHeader[2] = (size and 0xFF).toByte()
        rawHeader[3] = ((size shr 8) and 0xFF).toByte()
        rawHeader[4] = (checksum and 0xFF).toByte()
        rawHeader[5] = ((checksum shr 8) and 0xFF).toByte()
        rawHeader[6] = ((checksum shr 16) and 0xFF).toByte()
        rawHeader[7] = ((checksum shr 24) and 0xFF).toByte()

        val fullPayload = rawHeader + data

        val slipStream = ByteArrayOutputStream(fullPayload.size + 16)
        slipStream.write(0xC0)
        for (b in fullPayload) {
            val ub = b.toInt() and 0xFF
            if (ub == 0xC0) {
                slipStream.write(0xDB)
                slipStream.write(0xDC)
            } else if (ub == 0xDB) {
                slipStream.write(0xDB)
                slipStream.write(0xDD)
            } else {
                slipStream.write(ub)
            }
        }
        slipStream.write(0xC0)

        val packet = slipStream.toByteArray()
        val timeoutInt = Math.max(3000L, timeoutMs).toInt()
        val sent = connection.bulkTransfer(outEp, packet, packet.size, timeoutInt)
        if (sent < 0) throw Exception("Failed to send command 0x${cmd.toString(16)} via USB Bulk OUT")

        return readSlipResponse(cmd, timeoutMs)
    }

    private fun readSlipResponse(expectedCmd: Int, timeoutMs: Long = 3500): ByteArray {
        val inEp = epIn ?: throw Exception("Bulk IN endpoint missing")
        val rxBuf = ByteArray(2048)
        val collected = ByteArrayOutputStream()
        var insidePacket = false
        val startTime = System.currentTimeMillis()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val len = connection.bulkTransfer(inEp, rxBuf, rxBuf.size, 300)
            if (len > 0) {
                var i = if (isFtdi && !insidePacket && len >= 2) 2 else 0
                while (i < len) {
                    val b = rxBuf[i].toInt() and 0xFF
                    if (b == 0xC0) {
                        if (insidePacket) {
                            val raw = collected.toByteArray()
                            if (raw.size >= 8) {
                                val respCmd = raw[1].toInt() and 0xFF
                                if (respCmd == expectedCmd) {
                                    return raw
                                }
                            }
                            collected.reset()
                        } else {
                            insidePacket = true
                            collected.reset()
                        }
                    } else if (insidePacket) {
                        if (b == 0xDB && i + 1 < len) {
                            i++
                            val nextB = rxBuf[i].toInt() and 0xFF
                            if (nextB == 0xDC) collected.write(0xC0)
                            else if (nextB == 0xDD) collected.write(0xDB)
                        } else {
                            collected.write(b)
                        }
                    }
                    i++
                }
            }
        }
        throw Exception("Timeout waiting for response to command 0x${expectedCmd.toString(16)} (${timeoutMs}ms elapsed)")
    }

    fun syncRom(): Boolean {
        logCallback("⚡ [ROM Handshake] Sending ESP_SYNC sequence...")
        val syncPayload = ByteArray(36)
        syncPayload[0] = 0x07
        syncPayload[1] = 0x07
        syncPayload[2] = 0x12
        syncPayload[3] = 0x20
        for (i in 4 until 36) {
            syncPayload[i] = 0x55.toByte()
        }

        for (attempt in 1..10) {
            try {
                flushInput()
                sendSlipCommand(ESP_SYNC, syncPayload)
                logCallback("✅ ESP32 ROM Bootloader Synchronized successfully (Attempt #$attempt)!")
                return true
            } catch (e: Exception) {
                Thread.sleep(100)
            }
        }
        throw Exception("Could not sync with ESP32. Please hold 'BOOT' button and press 'Connect' if auto-reset does not trigger.")
    }

    fun attachSpiFlash() {
        logCallback("📦 Configuring SPI Flash Controller (ESP_SPI_ATTACH)...")
        val attachData = ByteArray(8)
        sendSlipCommand(ESP_SPI_ATTACH, attachData)
    }

    fun flashBinary(baseAddress: Long = 0x00010000L, data: ByteArray, progressCallback: (Int) -> Unit) {
        initUart(115200)
        resetToBootloader()

        syncRom()
        attachSpiFlash()

        val totalBytes = data.size
        val blockCount = (totalBytes + BLOCK_SIZE - 1) / BLOCK_SIZE
        logCallback("🚀 Flashing ${data.size} bytes (${data.size / 1024} KB) to ESP32 @ 0x${baseAddress.toString(16).uppercase()} ($blockCount blocks)...")

        val eraseSize = totalBytes
        val beginData = ByteArray(16)
        beginData[0] = (eraseSize and 0xFF).toByte()
        beginData[1] = ((eraseSize shr 8) and 0xFF).toByte()
        beginData[2] = ((eraseSize shr 16) and 0xFF).toByte()
        beginData[3] = ((eraseSize shr 24) and 0xFF).toByte()
        beginData[4] = (blockCount and 0xFF).toByte()
        beginData[5] = ((blockCount shr 8) and 0xFF).toByte()
        beginData[6] = ((blockCount shr 16) and 0xFF).toByte()
        beginData[7] = ((blockCount shr 24) and 0xFF).toByte()
        beginData[8] = (BLOCK_SIZE and 0xFF).toByte()
        beginData[9] = ((BLOCK_SIZE shr 8) and 0xFF).toByte()
        beginData[10] = ((BLOCK_SIZE shr 16) and 0xFF).toByte()
        beginData[11] = ((BLOCK_SIZE shr 24) and 0xFF).toByte()
        beginData[12] = (baseAddress and 0xFF).toByte()
        beginData[13] = ((baseAddress shr 8) and 0xFF).toByte()
        beginData[14] = ((baseAddress shr 16) and 0xFF).toByte()
        beginData[15] = ((baseAddress shr 24) and 0xFF).toByte()

        val eraseTimeoutMs = Math.max(15000L, 5000L + (totalBytes / 30).toLong())
        sendSlipCommand(ESP_FLASH_BEGIN, beginData, 0, eraseTimeoutMs)
        logCallback("✅ Flash memory unlocked & prepared.")

        for (seq in 0 until blockCount) {
            val offset = seq * BLOCK_SIZE
            val length = Math.min(BLOCK_SIZE, totalBytes - offset)
            val blockPayload = ByteArray(16 + BLOCK_SIZE)

            blockPayload[0] = (BLOCK_SIZE and 0xFF).toByte()
            blockPayload[1] = ((BLOCK_SIZE shr 8) and 0xFF).toByte()
            blockPayload[2] = 0
            blockPayload[3] = 0
            blockPayload[4] = (seq and 0xFF).toByte()
            blockPayload[5] = ((seq shr 8) and 0xFF).toByte()
            blockPayload[6] = ((seq shr 16) and 0xFF).toByte()
            blockPayload[7] = ((seq shr 24) and 0xFF).toByte()

            var checksum = 0xEF
            for (j in 0 until BLOCK_SIZE) {
                val b = if (j < length) data[offset + j].toInt() and 0xFF else 0xFF
                blockPayload[16 + j] = b.toByte()
                checksum = checksum xor b
            }

            sendSlipCommand(ESP_FLASH_DATA, blockPayload, checksum)

            val pct = ((seq + 1) * 100) / blockCount
            progressCallback(pct)
        }

        val endData = byteArrayOf(0x00, 0x00, 0x00, 0x00)
        try {
            sendSlipCommand(ESP_FLASH_END, endData)
        } catch (e: Exception) {
            logCallback("⚠️ [ESP32] Flash end returned: " + e.message)
        }

        logCallback(">> Write complete! Verifying ESP32 Flash via MD5 checksum...")
        val md5Cmd = ByteArray(16)
        ByteBuffer.wrap(md5Cmd, 0, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(baseAddress.toInt())
        ByteBuffer.wrap(md5Cmd, 4, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(totalBytes)
        val md5Resp = try {
            sendSlipCommand(0x13, md5Cmd, 0, 10000) // ESP_SPI_FLASH_MD5 = 0x13
        } catch (e: Exception) {
            logCallback("⚠️ [VERIFY] ESP32 MD5 command returned: " + e.message)
            null
        }

        if (md5Resp != null && md5Resp.size >= 16) {
            val chipMd5 = md5Resp.take(16).toByteArray()
            val md5Digest = java.security.MessageDigest.getInstance("MD5")
            val localMd5 = md5Digest.digest(data)
            if (!chipMd5.contentEquals(localMd5)) {
                throw Exception("ESP32 VERIFICATION FAILED: MD5 checksum mismatch!")
            }
            logCallback("✅ ESP32 FLASH SUCCESS: Complete image ($totalBytes bytes) 100% MD5 VERIFIED!")
        } else {
            logCallback("PROGRAMMED — FULL READ-BACK VERIFICATION NOT AVAILABLE")
        }
        resetChipNormal()
    }
}


// ============================================================================
// ARDUINO AVR STK500v1 / OPTIBOOT SERIAL FLASHER DRIVER
// Supports: Arduino Uno, Nano (New 115200 & Old 57600 Bootloader), Mega 2560
// ============================================================================
class ArduinoStk500Driver(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val vendorId: Int,
    private val productId: Int,
    private val logCallback: (String) -> Unit
) {
    private var epIn: UsbEndpoint? = null
    private var epOut: UsbEndpoint? = null

    private val isCp210x: Boolean get() = (vendorId == 0x10C4 || vendorId == 4292)
    private val isCh34x: Boolean get() = (vendorId == 0x1A86 || vendorId == 6790)
    private val isFtdi: Boolean get() = (vendorId == 0x0403 || vendorId == 1027)

    companion object {
        const val STK_OK = 0x10.toByte()
        const val STK_INSYNC = 0x14.toByte()
        const val STK_GET_SYNC = 0x30.toByte()
        const val STK_ENTER_PROGMODE = 0x50.toByte()
        const val STK_LEAVE_PROGMODE = 0x51.toByte()
        const val STK_LOAD_ADDRESS = 0x55.toByte()
        const val STK_PROG_PAGE = 0x64.toByte()
        const val SYNC_CRC_EOP = 0x20.toByte()
        const val PAGE_SIZE = 128
    }

    init {
        for (i in 0 until usbInterface.endpointCount) {
            val ep = usbInterface.getEndpoint(i)
            if (ep.direction == UsbConstants.USB_DIR_IN && epIn == null) {
                epIn = ep
            } else if (ep.direction == UsbConstants.USB_DIR_OUT && epOut == null) {
                epOut = ep
            }
        }
    }

    fun initUart(baudRate: Int = 115200) {
        logCallback("Configuring Arduino UART: $baudRate baud (8N1)...")
        if (isCp210x) {
            connection.controlTransfer(0x41, 0x00, 0x0001, 0, null, 0, 1000)
            connection.controlTransfer(0x41, 0x03, 0x0800, 0, null, 0, 1000)
            val baudData = byteArrayOf(
                (baudRate and 0xFF).toByte(),
                ((baudRate shr 8) and 0xFF).toByte(),
                ((baudRate shr 16) and 0xFF).toByte(),
                ((baudRate shr 24) and 0xFF).toByte()
            )
            connection.controlTransfer(0x41, 0x1E, 0, 0, baudData, 4, 1000)
        } else if (isCh34x) {
            connection.controlTransfer(0x40, 0xA1, 0xC29C, 0xB8D9, null, 0, 1000)
            connection.controlTransfer(0x40, 0xA4, 0xFF, 0, null, 0, 1000)
            if (baudRate == 57600) {
                connection.controlTransfer(0x40, 0x9A, 0x1312, 0x9883, null, 0, 1000)
                connection.controlTransfer(0x40, 0x9A, 0x0F2C, 0x0007, null, 0, 1000)
            } else {
                connection.controlTransfer(0x40, 0x9A, 0x1312, 0xCC83, null, 0, 1000)
                connection.controlTransfer(0x40, 0x9A, 0x0F2C, 0x0007, null, 0, 1000)
            }
        } else if (isFtdi) {
            val divisor = if (baudRate == 57600) 0x0034 else 0x001A
            connection.controlTransfer(0x40, 0x00, 0x0000, 0, null, 0, 1000)
            connection.controlTransfer(0x40, 0x03, divisor, 0, null, 0, 1000)
            connection.controlTransfer(0x40, 0x04, 0x0008, 0, null, 0, 1000)
        } else {
            val lineCoding = byteArrayOf(
                (baudRate and 0xFF).toByte(),
                ((baudRate shr 8) and 0xFF).toByte(),
                ((baudRate shr 16) and 0xFF).toByte(),
                ((baudRate shr 24) and 0xFF).toByte(),
                0x00, 0x00, 0x08
            )
            try {
                connection.controlTransfer(0x21, 0x20, 0, 0, lineCoding, lineCoding.size, 1000)
            } catch (_: Exception) {}
        }
        setDtrRts(false, false)
        flushInput()
    }

    fun setDtrRts(dtr: Boolean, rts: Boolean) {
        if (isCp210x) {
            var mhs = 0
            if (dtr) mhs = mhs or 0x0101 else mhs = mhs or 0x0100
            if (rts) mhs = mhs or 0x0202 else mhs = mhs or 0x0200
            connection.controlTransfer(0x41, 0x07, mhs, 0, null, 0, 500)
        } else if (isCh34x) {
            var mask = 0
            if (dtr) mask = mask or 0x20
            if (rts) mask = mask or 0x40
            connection.controlTransfer(0x40, 0xA4, (mask.inv()) and 0xFF, 0, null, 0, 500)
        } else if (isFtdi) {
            var value = 0
            if (dtr) value = value or 0x0101 else value = value or 0x0100
            if (rts) value = value or 0x0202 else value = value or 0x0200
            connection.controlTransfer(0x40, 0x01, value, 0, null, 0, 500)
        } else {
            var value = 0
            if (dtr) value = value or 0x01
            if (rts) value = value or 0x02
            try {
                connection.controlTransfer(0x21, 0x22, value, 0, null, 0, 500)
            } catch (_: Exception) {}
        }
    }

    fun resetArduino() {
        logCallback("🔄 [Auto-Reset] Pulsing DTR to reboot Arduino into Optiboot...")
        setDtrRts(false, false)
        Thread.sleep(50)
        setDtrRts(true, true)
        Thread.sleep(100)
        setDtrRts(false, false)
        Thread.sleep(200)
        flushInput()
    }

    private fun flushInput() {
        val inEp = epIn ?: return
        val buf = ByteArray(512)
        while (true) {
            val len = connection.bulkTransfer(inEp, buf, buf.size, 50)
            if (len <= 0) break
        }
    }

    private fun sendCommand(cmd: ByteArray, expectedRespLen: Int = 2, timeoutMs: Int = 1200): ByteArray {
        val outEp = epOut ?: throw Exception("Bulk OUT endpoint missing")
        val inEp = epIn ?: throw Exception("Bulk IN endpoint missing")

        val sent = connection.bulkTransfer(outEp, cmd, cmd.size, 1000)
        if (sent < 0) throw Exception("Failed to send command to Arduino via USB")

        val rxBuf = ByteArray(256)
        val startTime = System.currentTimeMillis()
        val stream = java.io.ByteArrayOutputStream()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val len = connection.bulkTransfer(inEp, rxBuf, rxBuf.size, 200)
            if (len > 0) {
                val start = if (isFtdi && stream.size() == 0 && len >= 2) 2 else 0
                for (j in start until len) {
                    stream.write(rxBuf[j].toInt())
                }
                if (stream.size() >= expectedRespLen) {
                    return stream.toByteArray()
                }
            }
        }
        throw Exception("Timeout waiting for Arduino response (Expected $expectedRespLen bytes, got ${stream.size()})")
    }

    fun syncBootloader(): Int {
        val bauds = intArrayOf(115200, 57600)
        for (baud in bauds) {
            logCallback("⚡ Attempting STK500 Sync at $baud baud...")
            initUart(baud)
            resetArduino()

            for (attempt in 1..5) {
                try {
                    flushInput()
                    val syncCmd = byteArrayOf(STK_GET_SYNC, SYNC_CRC_EOP)
                    val resp = sendCommand(syncCmd, 2, 400)
                    if (resp.size >= 2 && resp[0] == STK_INSYNC && resp[1] == STK_OK) {
                        logCallback("✅ Arduino Optiboot Synced successfully at $baud baud (Attempt #$attempt)!")
                        return baud
                    }
                } catch (_: Exception) {
                    Thread.sleep(50)
                }
            }
        }
        throw Exception("Could not sync with Arduino bootloader at 115200 or 57600 baud. Please tap Reset on Arduino while flashing.")
    }

    fun flashBinary(data: ByteArray, progressCallback: (Int) -> Unit) {
        val activeBaud = syncBootloader()

        try {
            val enterCmd = byteArrayOf(STK_ENTER_PROGMODE, SYNC_CRC_EOP)
            sendCommand(enterCmd, 2, 500)
        } catch (_: Exception) {}

        val totalBytes = data.size
        val totalPages = (totalBytes + PAGE_SIZE - 1) / PAGE_SIZE
        logCallback("🚀 Flashing $totalBytes bytes (${totalBytes / 1024} KB) to Arduino ATmega328P ($totalPages pages @ $activeBaud baud)...")

        for (page in 0 until totalPages) {
            val byteAddr = page * PAGE_SIZE
            val wordAddr = byteAddr / 2

            val loadAddrCmd = byteArrayOf(
                STK_LOAD_ADDRESS,
                (wordAddr and 0xFF).toByte(),
                ((wordAddr shr 8) and 0xFF).toByte(),
                SYNC_CRC_EOP
            )
            val addrResp = sendCommand(loadAddrCmd, 2, 500)
            if (addrResp.size < 2 || addrResp[0] != STK_INSYNC || addrResp[1] != STK_OK) {
                throw Exception("Failed to load address 0x${wordAddr.toString(16)} (Page $page)")
            }

            val progCmd = ByteArray(4 + PAGE_SIZE + 1)
            progCmd[0] = STK_PROG_PAGE
            progCmd[1] = ((PAGE_SIZE shr 8) and 0xFF).toByte()
            progCmd[2] = (PAGE_SIZE and 0xFF).toByte()
            progCmd[3] = 'F'.code.toByte()

            val copyLen = Math.min(PAGE_SIZE, totalBytes - byteAddr)
            for (k in 0 until PAGE_SIZE) {
                progCmd[4 + k] = if (k < copyLen) data[byteAddr + k] else 0xFF.toByte()
            }
            progCmd[4 + PAGE_SIZE] = SYNC_CRC_EOP

            val pageResp = sendCommand(progCmd, 2, 1000)
            if (pageResp.size < 2 || pageResp[0] != STK_INSYNC || pageResp[1] != STK_OK) {
                throw Exception("Write failed at Page $page (Byte 0x${byteAddr.toString(16)})")
            }

            val pct = ((page + 1) * 100) / totalPages
            progressCallback(pct)
        }

        logCallback(">> Write complete! Verifying Arduino Flash memory...")
        for (page in 0 until totalPages) {
            val byteAddr = page * PAGE_SIZE
            val wordAddr = byteAddr / 2

            val loadAddrCmd = byteArrayOf(
                STK_LOAD_ADDRESS,
                (wordAddr and 0xFF).toByte(),
                ((wordAddr shr 8) and 0xFF).toByte(),
                SYNC_CRC_EOP
            )
            val addrResp = sendCommand(loadAddrCmd, 2, 500)
            if (addrResp.size < 2 || addrResp[0] != STK_INSYNC || addrResp[1] != STK_OK) {
                throw Exception("Failed to set address for verify at Page $page")
            }

            val readPageCmd = byteArrayOf(
                0x74.toByte(), // STK_READ_PAGE ('t')
                ((PAGE_SIZE shr 8) and 0xFF).toByte(),
                (PAGE_SIZE and 0xFF).toByte(),
                'F'.code.toByte(),
                SYNC_CRC_EOP
            )
            val readResp = sendCommand(readPageCmd, PAGE_SIZE + 2, 1000)
            if (readResp.size < PAGE_SIZE + 2 || readResp[0] != STK_INSYNC || readResp[readResp.size - 1] != STK_OK) {
                throw Exception("Failed to read back Page $page for verification")
            }

            val copyLen = Math.min(PAGE_SIZE, totalBytes - byteAddr)
            for (k in 0 until copyLen) {
                val expected = data[byteAddr + k].toInt() and 0xFF
                val actual = readResp[1 + k].toInt() and 0xFF
                if (actual != expected) {
                    val mismatchAddr = byteAddr + k
                    throw Exception(
                        "ARDUINO VERIFICATION FAILED: Flash mismatch at 0x%04X! Expected: 0x%02X, Got: 0x%02X".format(
                            mismatchAddr, expected, actual
                        )
                    )
                }
            }
        }

        try {
            val leaveCmd = byteArrayOf(STK_LEAVE_PROGMODE, SYNC_CRC_EOP)
            sendCommand(leaveCmd, 2, 500)
        } catch (e: Exception) {
            logCallback("⚠️ [ARDUINO] Leave prog mode returned: " + e.message)
        }

        logCallback("✅ ARDUINO FLASH SUCCESS: Complete image ($totalBytes bytes) 100% VERIFIED against Flash ROM!")
        setDtrRts(false, false)
    }
}
