# ⚡ Flasher Pro (V3.5.0 HyperOS 3 & Android 16 Industrial Edition)
## Universal Multi-MCU Flasher • Nipon Zipper CNC Hardware Suite • Anti-Stop Zero-Bricking Shield

An industrial-grade, 100% offline-ready Android firmware flashing and real-time machine diagnostic suite engineered specifically for **Nipon Zipper Industries Pvt Ltd (Sarigam GIDC, Gujarat)** and multi-platform microcontrollers (**STM32 ARM Cortex-M**, **ESP32 Xtensa/RISC-V**, and **Arduino AVR**).

---

### 🌟 Key Advancements in Version 3.5.0

1. **Android 16 (Baklava) & HyperOS 3 Compatibility:**
   - Targets `compileSdk 35` and `targetSdk 35` (Android 15 / 16 ready).
   - Mandatory **Edge-to-Edge WindowInsets** accounting for display cutouts, punch-holes, and gesture navigation across curved OLED displays (Poco C85X, Motorola Edge 60 Fusion, Realme UI, ColorOS, Funtouch OS).
   - Android 12–16 compliant USB `PendingIntent` with `FLAG_MUTABLE`.

2. **Strict Anti-Stop & Anti-Corruption Shield (`HardwareFlasherService`):**
   - Unkillable Foreground Service running with `foregroundServiceType="connectedDevice|dataSync"`.
   - Continuous `PowerManager.PARTIAL_WAKE_LOCK` prevents CPU deep sleep during flash writes even when the phone screen turns off or the phone is in a pocket.
   - **UI Interlock:** Back-button and swipe-to-back gestures are locked during active flashing to prevent accidental process cancellation and flash corruption.
   - **Battery Optimization Bypass:** 1-tap shortcut to grant "Unrestricted" battery usage (`ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`).

3. **Zero-Click 300ms Auto-Reconnect Engine (Vibration Filter):**
   - Debounces USB disconnect/connect events within 300ms.
   - If machine floor vibration causes the OTG cable to momentarily jiggle, the app suppresses false disconnect alerts, buffers the active session in memory, and instantly re-establishes the hardware session within 300ms without requiring user intervention.

4. **OTG 5V Auto-Off Keep-Alive Heartbeat:**
   - Sends a periodic ping (every 45s) across active USB endpoints to prevent ColorOS (Oppo), Realme UI, and Funtouch OS (Vivo) from triggering their aggressive 10-minute OTG auto-power-off timer, ensuring continuous 24x7 5V VBUS power to the ST-Link, ESP32, and Arduino.

5. **Dual Firmware Acquisition Architecture (Online + Offline):**
   - **1-Click Offline Embedded Firmware Switcher:** Pre-bundled with `V16.3.3 Production`, `V16.4.0 Optical Safety`, and `V16.5.0 Hardware Timer` binaries for instant shop-floor flashing without a file picker or internet connection.
   - **Direct GitHub Auto-Download & Save:** Fetches latest compiled `.bin` artifacts directly from GitHub API and permanently caches them in phone storage.
   - **Manual Local File Picker (SAF):** Allows selecting custom `.bin` / `.hex` binaries from internal storage, SD Card, or WhatsApp with ARM Vector Table sanity checks.

6. **In-App Realistic Wiring Diagram & DIY Pinout Visualizer (`tabWiring`):**
   - Color-coded wiring netlist for technicians (Red, Black, Yellow, Orange, Blue, Brown, Violet, White).
   - Interactive schematics for STM32 Blue Pill, 4-Channel BSS138 Level Shifter, Leadshine DM542 Stepper Driver, NEMA 23 Motor, 24V Cam Proximity Sensor, PC817 Optocouplers, and 4-Branch Star Grounding.
   - 1-Click Version Toggle: Switch between `V16.3.3 Standard` and `V16.4.0 / V16.5.0 Optical Safety (PA3/PB0/PB1)`.
   - Built-in **5-Point Field Troubleshooter** (Motor Stall, Pitch Error, Sensor Noise, Motor Heat, Teeth Drift).

7. **Default Password & App Name Synchronized:**
   - Application Name: **`Flasher`**
   - Default Master Password: **`Flasher`** (also accepts `flasher`, `stm32flasher`, `stm32`, case-insensitive).

---

### 🔌 Physical Wiring Quick Reference

| STM32 Blue Pill Pin | Wire Color | Destination Component | Function |
| :--- | :--- | :--- | :--- |
| **Pin 18 (3.3V)** | 🔴 Red (24 AWG) | Level Shifter LV / 3V3 Pin | 3.3V Logic Reference |
| **Pins 19/20 (GND)** | 🟢/⚫ Green/Black (22 AWG)| Central Star Ground (Branch 3) | Clean MCU Ground |
| **PA0** | 🟡 Yellow | PC817 Pin 4 (Cam Proximity) | Falling Edge ISR Trigger |
| **PA1** | 🟠 Orange | Level Shifter CH3 LV ➔ Driver PUL- | Stepper Step Pulse (TIM2_CH2) |
| **PA2** | 🔵 Blue | Level Shifter CH4 LV ➔ Driver DIR- | Stepper Direction Signal |
| **PA3 (V16.4/V16.5)** | 🟤 Brown | PC817 Ch 1 Pin 4 (Tape Guard) | Fabric Tape Run-Out Sensor |
| **PB0 (V16.4/V16.5)** | 🟣 Violet | PC817 Ch 2 Pin 4 (Coil Guard) | Nylon Coil Jam/Break Sensor |
| **PB1 (V16.4/V16.5)** | ⚪ White | 5V Opto-Relay Module IN | Main Motor E-Stop Trip Relay |
| **PB6 / PB7** | 🟢 Green / ⚪ White | Level Shifter CH1/CH2 ➔ LCD SCL/SDA | Fast 400kHz I2C Display Bus |
| **PB12 / PB13 / PB14**| ⚪ Gray | UP, DOWN, MODE Tactile Buttons | Operator Menu & Pulse Tuning |
| **Driver PUL+ / DIR+**| 🔴 Red (22 AWG) | +5V Regulated Rail (L7805 OUT) | Common Anode (12.9mA sink) |
| **Driver VCC / GND** | 🔴 Red / ⚫ Black (18 AWG) | +24V Main Power Bus / Branch 1 | Motor Power Supply |
